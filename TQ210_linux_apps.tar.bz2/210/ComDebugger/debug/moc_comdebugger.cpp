/****************************************************************************
** Meta object code from reading C++ file 'comdebugger.h'
**
** Created: Wed Jun 8 11:46:51 2011
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../comdebugger.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'comdebugger.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ComDebugger[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x0a,
      26,   12,   12,   12, 0x0a,
      42,   12,   12,   12, 0x0a,
      57,   12,   12,   12, 0x0a,
      73,   12,   12,   12, 0x0a,
     103,   12,   12,   12, 0x0a,
     124,   12,   12,   12, 0x0a,
     145,   12,   12,   12, 0x0a,
     167,   12,   12,   12, 0x0a,
     191,   12,   12,   12, 0x0a,
     209,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_ComDebugger[] = {
    "ComDebugger\0\0ShowComMsg()\0pbSendClicked()\0"
    "pbSetClicked()\0teTextChanged()\0"
    "teDisplayTextChanged(QString)\0"
    "pbClearRecvClicked()\0pbClearSendClicked()\0"
    "pbClearCountClicked()\0cbDisplayStateChanged()\0"
    "pbSelectClicked()\0cbAutoSendClicked()\0"
};

const QMetaObject ComDebugger::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ComDebugger,
      qt_meta_data_ComDebugger, 0 }
};

const QMetaObject *ComDebugger::metaObject() const
{
    return &staticMetaObject;
}

void *ComDebugger::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ComDebugger))
        return static_cast<void*>(const_cast< ComDebugger*>(this));
    return QWidget::qt_metacast(_clname);
}

int ComDebugger::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: ShowComMsg(); break;
        case 1: pbSendClicked(); break;
        case 2: pbSetClicked(); break;
        case 3: teTextChanged(); break;
        case 4: teDisplayTextChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: pbClearRecvClicked(); break;
        case 6: pbClearSendClicked(); break;
        case 7: pbClearCountClicked(); break;
        case 8: cbDisplayStateChanged(); break;
        case 9: pbSelectClicked(); break;
        case 10: cbAutoSendClicked(); break;
        default: ;
        }
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
