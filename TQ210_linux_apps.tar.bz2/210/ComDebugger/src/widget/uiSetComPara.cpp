#include "uiSetComPara.h"
#include <QVBoxLayout>
#include "comdebugger.h"
#include <QMessageBox>
#include <QApplication>
#include <QDesktopWidget>
#include <QWindowsXPStyle>

#define WIDTH screen_size.width()/480
#define HEIGHT screen_size.height()/270
//#include <iostream>
//using namespace std;
uiSetComPara::uiSetComPara(QWidget *parent) :
	QDialog(parent, Qt::FramelessWindowHint)
{
	QRect screen_size = QApplication::desktop()->screenGeometry();

	this->setWindowTitle(trUtf8("天嵌科技串口工具V1.0"));
	this->setAutoFillBackground(true);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	QPixmap pix;

	pbConfirm = new QPushButton();
	pbConfirm->setFixedSize(62*WIDTH, 25*HEIGHT);
	pbConfirm->setIconSize(QSize(62*WIDTH, 25*HEIGHT));
	pix.load("/opt/PDA/app/images/confirm.png", 0, Qt::AutoColor);
	pix = pix.scaled(62*WIDTH, 25*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	pbConfirm->setIcon(QIcon(pix));

	pbCancel = new QPushButton();
	pbCancel->setFixedSize(62*WIDTH, 25*HEIGHT);
	pbCancel->setIconSize(QSize(62*WIDTH, 25*HEIGHT));
	pix.load("/opt/PDA/app/images/cancel.png", 0, Qt::AutoColor);
	pix = pix.scaled(62*WIDTH, 25*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	pbCancel->setIcon(QIcon(pix));

	QStringList list;
	list.append("ttySAC0");
	list.append("ttySAC1");
	list.append("ttySAC2");
	list.append("ttySAC3");
	list.append("ttySAC4");
	list.append("ttySAC5");
	list.append("ttySAC6");
	list.append("ttyUSB0");
	list.append("ttyUSB1");

	cbCom = new QComboBox();
	cbCom->addItems(list);
	cbCom->setCurrentIndex(1);
	//波特率
	list.clear();
	list = (QStringList() << "110" << "300" << "600" << "1200" << "2400"
			<< "4800" << "9600");
	list += (QStringList() << "14400" << "19200" << "38400" << "56000"
			<< "57600" << "115200" << "256000");

	cbRate = new QComboBox();
	cbRate->addItems(list);
	cbRate->setCurrentIndex(12);
	//数据位
	list.clear();
	list = (QStringList() << "5" << "6" << "7" << "8");

	cbDataBit  = new QComboBox();
	cbDataBit->addItems(list);
	cbDataBit->setCurrentIndex(3);
	//停止位
	list.clear();
	list = (QStringList() << "1" << "1.5" << "2");

	cbStopBit  = new QComboBox();
	cbStopBit->addItems(list);
	cbStopBit->setCurrentIndex(0);
	//校验位
	list.clear();
	list = (QStringList() << "None" << "Odd" << "Even" << "Mark" << "Space");

	cbCheckBit  = new QComboBox();
	cbCheckBit->addItems(list);
	cbCheckBit->setCurrentIndex(0);
	//流控制
	list.clear();
	list = (QStringList() << "HardWare" << "SoftWare" << "None");

	cbFlowControl  = new QComboBox();
	cbFlowControl->addItems(list);
	cbFlowControl->setCurrentIndex(2);

	cbCom->setMinimumWidth(108*WIDTH);
	cbRate->setMinimumWidth(108*WIDTH);
	cbDataBit->setMinimumWidth(108*WIDTH);
	cbStopBit->setMinimumWidth(108*WIDTH);
	cbCheckBit->setMinimumWidth(108*WIDTH);
	cbFlowControl->setMinimumWidth(108*WIDTH);

	lbCom = new QLabel(trUtf8("串口名："));
	lbRate = new QLabel(trUtf8("波特率："));;
	lbDataBit = new QLabel(trUtf8("数据位："));;
	lbStopBit = new QLabel(trUtf8("停止位："));;
	lbCheckBit = new QLabel(trUtf8("校验位："));;
	lbFlowControl = new QLabel(trUtf8("流控制："));;

	QHBoxLayout *comLayOut = new QHBoxLayout;
	comLayOut->addSpacing(144*WIDTH);
	comLayOut->addWidget(lbCom);
	comLayOut->addWidget(cbCom);
	comLayOut->addSpacing(140*WIDTH);

	QHBoxLayout *rateLayOut = new QHBoxLayout;
	rateLayOut->addSpacing(140*WIDTH);
	rateLayOut->addWidget(lbRate);
	rateLayOut->addWidget(cbRate);
	rateLayOut->addSpacing(140*WIDTH);

	QHBoxLayout *dataLayOut = new QHBoxLayout;
	dataLayOut->addSpacing(140*WIDTH);
	dataLayOut->addWidget(lbDataBit);
	dataLayOut->addWidget(cbDataBit);
	dataLayOut->addSpacing(140*WIDTH);

	QHBoxLayout *stopLayOut = new QHBoxLayout;
	stopLayOut->addSpacing(140*WIDTH);
	stopLayOut->addWidget(lbStopBit);
	stopLayOut->addWidget(cbStopBit);
	stopLayOut->addSpacing(140*WIDTH);

	QHBoxLayout *checkLayOut = new QHBoxLayout;
	checkLayOut->addSpacing(140*WIDTH);
	checkLayOut->addWidget(lbCheckBit);
	checkLayOut->addWidget(cbCheckBit);
	checkLayOut->addSpacing(140*WIDTH);

	QHBoxLayout *flowLayOut = new QHBoxLayout;
	flowLayOut->addSpacing(140*WIDTH);
	flowLayOut->addWidget(lbFlowControl);
	flowLayOut->addWidget(cbFlowControl);
	flowLayOut->addSpacing(140*WIDTH);

	QHBoxLayout *bottomLayOut = new QHBoxLayout;
	bottomLayOut->addSpacing(140*WIDTH);
	bottomLayOut->addWidget(pbCancel);
	bottomLayOut->addSpacing(30*WIDTH);
	bottomLayOut->addWidget(pbConfirm);
	bottomLayOut->addSpacing(140*WIDTH);

	QVBoxLayout *centralLayOut = new QVBoxLayout;
//	centralLayOut->addSpacing(20*HEIGHT);
	centralLayOut->addLayout(comLayOut);
	centralLayOut->addLayout(rateLayOut);
	centralLayOut->addLayout(dataLayOut);
	centralLayOut->addLayout(stopLayOut);
	centralLayOut->addLayout(checkLayOut);
	centralLayOut->addLayout(flowLayOut);
	centralLayOut->addLayout(bottomLayOut);
//	centralLayOut->addSpacing(20*HEIGHT);

	setLayout(centralLayOut);

	connect(pbCancel, SIGNAL(clicked()), this, SLOT(pbCancelClicked()));
	connect(pbConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));
}

uiSetComPara::~uiSetComPara()
{

}
void uiSetComPara::pbCancelClicked()
{
	QWidget::close();
}
//确定按钮
void uiSetComPara::pbConfirmClicked()
{
	g_pComDebugger->m_pCom->close();
	g_pComDebugger->m_pCom->setPort("/dev/" + cbCom->currentText());
	QFile f("/dev/" + cbCom->currentText());
	if (!f.exists())
	{
		QMessageBox::warning(this, trUtf8("提示"), trUtf8("串口不存在！"),
				QMessageBox::Ok);
		return;
	}
	if (g_pComDebugger->m_pCom->open(QIODevice::ReadWrite))
	{
		QString str = cbCom->currentText() + " 已打开";
		switch (cbRate->currentIndex())
		{
		case 0:
			g_pComDebugger->m_pCom->setBaudRate(BAUD110);
			str += " 110";
			break;
		case 1:
			g_pComDebugger->m_pCom->setBaudRate(BAUD300);
			str += " 300";
			break;
		case 2:
			g_pComDebugger->m_pCom->setBaudRate(BAUD600);
			str += " 600";
			break;
		case 3:
			g_pComDebugger->m_pCom->setBaudRate(BAUD1200);
			str += " 1200";
			break;
		case 4:
			g_pComDebugger->m_pCom->setBaudRate(BAUD2400);
			str += " 2400";
			break;
		case 5:
			g_pComDebugger->m_pCom->setBaudRate(BAUD4800);
			str += " 4800";
			break;
		case 6:
			g_pComDebugger->m_pCom->setBaudRate(BAUD9600);
			str += " 9600";
			break;
		case 7:
			g_pComDebugger->m_pCom->setBaudRate(BAUD14400);
			str += " 14400";
			break;
		case 8:
			g_pComDebugger->m_pCom->setBaudRate(BAUD19200);
			str += " 19200";
			break;
		case 9:
			g_pComDebugger->m_pCom->setBaudRate(BAUD38400);
			str += " 38400";
			break;
		case 10:
			g_pComDebugger->m_pCom->setBaudRate(BAUD56000);
			str += " 56000";
			break;
		case 11:
			g_pComDebugger->m_pCom->setBaudRate(BAUD57600);
			str += " 57600";
			break;
		case 12:
			g_pComDebugger->m_pCom->setBaudRate(BAUD115200);
			str += " 115200";
			break;
		case 13:
			g_pComDebugger->m_pCom->setBaudRate(BAUD256000);
			str += " 256000";
			break;
		default:
			break;
		}

		switch (cbDataBit->currentIndex())
		{
		case 0:
			g_pComDebugger->m_pCom->setDataBits(DATA_5);
			str += " 5";
			break;
		case 1:
			g_pComDebugger->m_pCom->setDataBits(DATA_6);
			str += " 6";
			break;
		case 2:
			g_pComDebugger->m_pCom->setDataBits(DATA_7);
			str += " 7";
			break;
		case 3:
			g_pComDebugger->m_pCom->setDataBits(DATA_8);
			str += " 8";
			break;
		default:
			break;
		}

		switch (cbStopBit->currentIndex())
		{
		case 0:
			g_pComDebugger->m_pCom->setStopBits(STOP_1);
			break;
		case 1:
			g_pComDebugger->m_pCom->setStopBits(STOP_1_5);
			break;
		case 2:
			g_pComDebugger->m_pCom->setStopBits(STOP_2);
			break;
		default:
			break;
		}

		switch (cbCheckBit->currentIndex())
		{
		case 0:
			g_pComDebugger->m_pCom->setParity(PAR_NONE);
			break;
		case 1:
			g_pComDebugger->m_pCom->setParity(PAR_ODD);
			break;
		case 2:
			g_pComDebugger->m_pCom->setParity(PAR_EVEN);
			break;
		case 3:
			g_pComDebugger->m_pCom->setParity(PAR_MARK);
			break;
		case 4:
			g_pComDebugger->m_pCom->setParity(PAR_SPACE);
			break;
		default:
			break;
		}

		switch (cbFlowControl->currentIndex())
		{
		case 0:
			g_pComDebugger->m_pCom->setFlowControl(FLOW_HARDWARE);
			break;
		case 1:
			g_pComDebugger->m_pCom->setFlowControl(FLOW_XONXOFF);
			break;
		case 2:
			g_pComDebugger->m_pCom->setFlowControl(FLOW_OFF);
			break;
		default:
			break;
		}
		g_pComDebugger->SetComStatus(str);
		pbCancelClicked();
	}
	else
	{
		QMessageBox::warning(this, trUtf8("提示"), trUtf8("串口打开失败！"),
				QMessageBox::Ok);
	}

}

