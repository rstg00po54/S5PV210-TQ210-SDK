#ifndef UISETCOMPARA_H
#define UISETCOMPARA_H

#include <QtGui/QDialog>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include<QComboBox>
//#include "ui_uiSetComPara.h"

class uiSetComPara : public QDialog
{
    Q_OBJECT

public:
    uiSetComPara(QWidget *parent = 0);
    ~uiSetComPara();
public slots:
	void pbCancelClicked();
	void pbConfirmClicked();

private:
	int m_iWidth;
	int m_iHeight;
	QPushButton *pbCancel;
	QPushButton *pbConfirm;

	QComboBox *cbCom;
	QComboBox *cbRate;
	QComboBox *cbDataBit;
	QComboBox *cbStopBit;
	QComboBox *cbCheckBit;
	QComboBox *cbFlowControl;

	QLabel *lbCom;
	QLabel *lbRate;
	QLabel *lbDataBit;
	QLabel *lbStopBit;
	QLabel *lbCheckBit;
	QLabel *lbFlowControl;
//    Ui::uiSetComParaClass ui;
};

#endif // UISETCOMPARA_H
