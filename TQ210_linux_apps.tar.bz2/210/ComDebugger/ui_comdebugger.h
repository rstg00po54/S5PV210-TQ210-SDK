/********************************************************************************
** Form generated from reading ui file 'comdebugger.ui'
**
** Created: Tue Sep 11 17:34:41 2012
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_COMDEBUGGER_H
#define UI_COMDEBUGGER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ComDebuggerClass
{
public:
    QPushButton *pbSend;
    QPushButton *pbSet;

    void setupUi(QWidget *ComDebuggerClass)
    {
        if (ComDebuggerClass->objectName().isEmpty())
            ComDebuggerClass->setObjectName(QString::fromUtf8("ComDebuggerClass"));
        ComDebuggerClass->resize(480, 272);
        ComDebuggerClass->setAutoFillBackground(true);
        ComDebuggerClass->setStyleSheet(QString::fromUtf8(""));
        pbSend = new QPushButton(ComDebuggerClass);
        pbSend->setObjectName(QString::fromUtf8("pbSend"));
        pbSend->setGeometry(QRect(412, 239, 61, 30));
        pbSend->setAutoFillBackground(true);
        pbSend->setStyleSheet(QString::fromUtf8(""));
        pbSet = new QPushButton(ComDebuggerClass);
        pbSet->setObjectName(QString::fromUtf8("pbSet"));
        pbSet->setGeometry(QRect(140, 200, 61, 27));

        retranslateUi(ComDebuggerClass);

        QMetaObject::connectSlotsByName(ComDebuggerClass);
    } // setupUi

    void retranslateUi(QWidget *ComDebuggerClass)
    {
        ComDebuggerClass->setWindowTitle(QApplication::translate("ComDebuggerClass", "ComDebugger", 0, QApplication::UnicodeUTF8));
        pbSend->setText(QString());
        pbSet->setText(QString());
        Q_UNUSED(ComDebuggerClass);
    } // retranslateUi

};

namespace Ui {
    class ComDebuggerClass: public Ui_ComDebuggerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COMDEBUGGER_H
