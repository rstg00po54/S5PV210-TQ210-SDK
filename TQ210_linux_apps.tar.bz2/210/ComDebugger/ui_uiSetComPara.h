/********************************************************************************
** Form generated from reading ui file 'uiSetComPara.ui'
**
** Created: Tue Sep 11 17:34:41 2012
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_UISETCOMPARA_H
#define UI_UISETCOMPARA_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_uiSetComParaClass
{
public:
    QLabel *lbCom;
    QComboBox *cbCom;
    QLabel *lbRate;
    QComboBox *cbRate;
    QComboBox *cbStopBit;
    QLabel *lbStopBit;
    QComboBox *cbCheckBit;
    QLabel *lbCheckBit;
    QComboBox *cbFlowControl;
    QLabel *lbFlowControl;
    QLabel *lbDataBit;
    QComboBox *cbDataBit;
    QPushButton *pbConfirm;
    QPushButton *pbCancel;

    void setupUi(QDialog *uiSetComParaClass)
    {
        if (uiSetComParaClass->objectName().isEmpty())
            uiSetComParaClass->setObjectName(QString::fromUtf8("uiSetComParaClass"));
        uiSetComParaClass->resize(480, 272);
        QFont font;
        font.setFamily(QString::fromUtf8("\346\226\207\351\274\216\357\274\260\357\274\254\347\256\200\344\270\255\346\245\267"));
        font.setPointSize(11);
        uiSetComParaClass->setFont(font);
        lbCom = new QLabel(uiSetComParaClass);
        lbCom->setObjectName(QString::fromUtf8("lbCom"));
        lbCom->setGeometry(QRect(130, 60, 51, 20));
        cbCom = new QComboBox(uiSetComParaClass);
        cbCom->setObjectName(QString::fromUtf8("cbCom"));
        cbCom->setGeometry(QRect(190, 54, 111, 26));
        cbCom->setMaxVisibleItems(10);
        lbRate = new QLabel(uiSetComParaClass);
        lbRate->setObjectName(QString::fromUtf8("lbRate"));
        lbRate->setGeometry(QRect(130, 90, 60, 16));
        lbRate->setLayoutDirection(Qt::LeftToRight);
        lbRate->setAutoFillBackground(false);
        cbRate = new QComboBox(uiSetComParaClass);
        cbRate->setObjectName(QString::fromUtf8("cbRate"));
        cbRate->setGeometry(QRect(190, 84, 111, 26));
        cbStopBit = new QComboBox(uiSetComParaClass);
        cbStopBit->setObjectName(QString::fromUtf8("cbStopBit"));
        cbStopBit->setGeometry(QRect(190, 144, 111, 26));
        lbStopBit = new QLabel(uiSetComParaClass);
        lbStopBit->setObjectName(QString::fromUtf8("lbStopBit"));
        lbStopBit->setGeometry(QRect(130, 150, 60, 16));
        lbStopBit->setLayoutDirection(Qt::LeftToRight);
        lbStopBit->setAutoFillBackground(false);
        cbCheckBit = new QComboBox(uiSetComParaClass);
        cbCheckBit->setObjectName(QString::fromUtf8("cbCheckBit"));
        cbCheckBit->setGeometry(QRect(190, 172, 111, 26));
        lbCheckBit = new QLabel(uiSetComParaClass);
        lbCheckBit->setObjectName(QString::fromUtf8("lbCheckBit"));
        lbCheckBit->setGeometry(QRect(130, 181, 60, 16));
        lbCheckBit->setLayoutDirection(Qt::LeftToRight);
        lbCheckBit->setAutoFillBackground(false);
        cbFlowControl = new QComboBox(uiSetComParaClass);
        cbFlowControl->setObjectName(QString::fromUtf8("cbFlowControl"));
        cbFlowControl->setGeometry(QRect(190, 200, 111, 26));
        lbFlowControl = new QLabel(uiSetComParaClass);
        lbFlowControl->setObjectName(QString::fromUtf8("lbFlowControl"));
        lbFlowControl->setGeometry(QRect(130, 210, 60, 16));
        lbFlowControl->setLayoutDirection(Qt::LeftToRight);
        lbFlowControl->setAutoFillBackground(false);
        lbDataBit = new QLabel(uiSetComParaClass);
        lbDataBit->setObjectName(QString::fromUtf8("lbDataBit"));
        lbDataBit->setGeometry(QRect(130, 120, 60, 16));
        lbDataBit->setLayoutDirection(Qt::LeftToRight);
        lbDataBit->setAutoFillBackground(false);
        cbDataBit = new QComboBox(uiSetComParaClass);
        cbDataBit->setObjectName(QString::fromUtf8("cbDataBit"));
        cbDataBit->setGeometry(QRect(190, 114, 111, 26));
        pbConfirm = new QPushButton(uiSetComParaClass);
        pbConfirm->setObjectName(QString::fromUtf8("pbConfirm"));
        pbConfirm->setGeometry(QRect(260, 240, 61, 27));
        pbCancel = new QPushButton(uiSetComParaClass);
        pbCancel->setObjectName(QString::fromUtf8("pbCancel"));
        pbCancel->setGeometry(QRect(160, 240, 61, 27));

        retranslateUi(uiSetComParaClass);

        QMetaObject::connectSlotsByName(uiSetComParaClass);
    } // setupUi

    void retranslateUi(QDialog *uiSetComParaClass)
    {
        uiSetComParaClass->setWindowTitle(QApplication::translate("uiSetComParaClass", "uiSetComPara", 0, QApplication::UnicodeUTF8));
        lbCom->setText(QApplication::translate("uiSetComParaClass", "\344\270\262\345\217\243\345\220\215:", 0, QApplication::UnicodeUTF8));
        lbRate->setText(QApplication::translate("uiSetComParaClass", " \346\263\242\347\211\271\347\216\207:", 0, QApplication::UnicodeUTF8));
        lbStopBit->setText(QApplication::translate("uiSetComParaClass", " \345\201\234\346\255\242\344\275\215:", 0, QApplication::UnicodeUTF8));
        lbCheckBit->setText(QApplication::translate("uiSetComParaClass", " \346\240\241\351\252\214\344\275\215:", 0, QApplication::UnicodeUTF8));
        lbFlowControl->setText(QApplication::translate("uiSetComParaClass", " \346\265\201\346\216\247\345\210\266:", 0, QApplication::UnicodeUTF8));
        lbDataBit->setText(QApplication::translate("uiSetComParaClass", " \346\225\260\346\215\256\344\275\215:", 0, QApplication::UnicodeUTF8));
        pbConfirm->setText(QString());
        pbCancel->setText(QString());
        Q_UNUSED(uiSetComParaClass);
    } // retranslateUi

};

namespace Ui {
    class uiSetComParaClass: public Ui_uiSetComParaClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UISETCOMPARA_H
