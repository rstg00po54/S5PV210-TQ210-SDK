#include "rtc.h"

#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    RTC w;
    w.showFullScreen();
    return a.exec();
}
