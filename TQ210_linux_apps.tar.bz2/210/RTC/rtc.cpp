#include "rtc.h"
#include<QProcess>
#include<QHBoxLayout>
#include<QMessageBox>
//#include<iostream>
//using namespace std;
RTC::RTC(QWidget *parent) :
	QWidget(parent)
{
	ui.setupUi(this);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	ui.dateTimeEdit->setDisplayFormat("yyyy.MM.dd.hh:mm:ss");//设置时间的格式
	ui.dateTimeEdit->setMaximumWidth(200);//宽度
	ui.dateTimeEdit->setMinimumHeight(33);

	m_pbHelp = new QPushButton();
	m_pbHelp->setFixedSize(82, 32);
	m_pbHelp->setIconSize(QSize(82, 32));
	QPixmap pix("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	m_pbWriteRTC = new QPushButton(this);
	m_pbWriteRTC->setFixedSize(82, 32);
	m_pbWriteRTC->setIcon(QIcon("/opt/PDA/app/images/confirm.png"));//设置退出案件图标
	m_pbWriteRTC->setIconSize(QSize(82, 32));
	connect(m_pbWriteRTC, SIGNAL(clicked()), SLOT(changeTime()));//关联

	QLabel *labelTitle = new QLabel(trUtf8("天嵌科技RTC测试程序"), this);
	labelTitle->setAlignment(Qt::AlignCenter);

	m_pbExit = new QPushButton(this);
	m_pbExit->setFixedSize(82, 32);
	m_pbExit->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出案件图标
	m_pbExit->setIconSize(QSize(82, 32));

	connect(m_pbExit, SIGNAL(clicked()), this, SLOT(close()));

	time = QDateTime::currentDateTime();//当前时间
	ui.dateTimeEdit->setDateTime(time);//将当前时间赋给编辑时间器

	QHBoxLayout *hTimeEditLayout = new QHBoxLayout;
	hTimeEditLayout->addSpacing(22);
	hTimeEditLayout->addWidget(ui.dateTimeEdit);

	QHBoxLayout *hLayout = new QHBoxLayout;
	hLayout->addSpacing(111);
	hLayout->addWidget(m_pbHelp);
	hLayout->addWidget(m_pbWriteRTC);
	hLayout->addWidget(m_pbExit);
	hLayout->addSpacing(111);

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addSpacing(333);
	mainLayout->addWidget(labelTitle);
	mainLayout->addSpacing(111);
	mainLayout->addLayout(hTimeEditLayout);
	mainLayout->addSpacing(33);
	mainLayout->addLayout(hLayout);
	mainLayout->addSpacing(111);
	this->setLayout(mainLayout);
}

RTC::~RTC()
{
	delete m_pbWriteRTC;//设置时间按钮
	delete m_pbExit;//退出按钮
	delete m_pbHelp;
}
void RTC::changeTime()
{
	QString str_yyyy = ui.dateTimeEdit->sectionText(QDateTimeEdit::YearSection);//获取时间编辑器 年 的设置
	QString str_MM = ui.dateTimeEdit->sectionText(QDateTimeEdit::MonthSection);
	QString str_dd = ui.dateTimeEdit->sectionText(QDateTimeEdit::DaySection);
	QString str_hh = ui.dateTimeEdit->sectionText(QDateTimeEdit::HourSection);
	QString str_mm = ui.dateTimeEdit->sectionText(QDateTimeEdit::MinuteSection);
	QString str_ss = ui.dateTimeEdit->sectionText(QDateTimeEdit::SecondSection);

	if(str_yyyy.toInt()<1970){
		QMessageBox warn;
		warn.setWindowTitle(trUtf8("提示"));
		warn.setText(trUtf8("设置失败，设置年份应该为1970年以上！"));
		warn.setStandardButtons(QMessageBox::Ok);
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
		QIcon icon(pix);
		warn .setWindowIcon(icon);
		warn.exec();
		return;
	}

	QString str = "date " + str_MM + str_dd + str_hh + str_mm + str_yyyy;//写入系统时间格式

	QProcess::execute(str);//调用系统命令，写入把时间写入arm
	QProcess::execute("hwclock -w");//将系统时间写入RTC

	QMessageBox warn;
	warn.setWindowTitle(trUtf8("提示"));
	warn.setText(trUtf8("设置成功！"));
	warn.setStandardButtons(QMessageBox::Ok);
	QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
	QIcon icon(pix);
	warn .setWindowIcon(icon);
	warn.exec();

}
void RTC::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
