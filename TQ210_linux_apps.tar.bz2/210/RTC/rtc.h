#ifndef RTC_H
#define RTC_H

#include <QtGui/QWidget>
#include "ui_rtc.h"
#include<QDateTime>
#include<QPushButton>
#include<QLabel>
#include <qprocess.h>

class RTC: public QWidget
{
Q_OBJECT

public:
	RTC(QWidget *parent = 0);
	~RTC();
	QDateTime time;//时间
public slots:
	void changeTime();//设置时间
	void pbHelpClicked();

private:
	Ui::RTCClass ui;
	QPushButton *m_pbWriteRTC;//设置时间按钮
	QPushButton *m_pbExit;//退出按钮

	QProcess process;
	QPushButton *m_pbHelp;
};

#endif // RTC_H
