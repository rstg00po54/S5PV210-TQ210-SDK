#include "tqbutton.h"

#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	TQButton w;
	w.showFullScreen();
	return a.exec();
}
