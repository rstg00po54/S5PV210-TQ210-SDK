#include "tqbutton.h"
#include<QHBoxLayout>
#include<QApplication>
#include<stdio.h>
#include<QRect>
#include <QDesktopWidget>
#include<QPalette>
#include<QIcon>
#include<QMessageBox>
#include<QTimer>
#include<QIcon>
#include<QPixmap>
#include<iostream>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
using namespace std;


TQButton::TQButton(QWidget *parent) :
	QWidget(parent)
{

//	setupUi(this);
	QRect screen_size = QApplication::desktop()->screenGeometry();//取窗体大小尺寸
	button_x = screen_size.width() / 10 ;//100;
	botton_y = screen_size.height() / 10 ;

	QPixmap pix;
	//	setAttribute(Qt::WA_DeleteOnClose);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");//设置背景
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	setFocusPolicy(Qt::StrongFocus);

	title = new QLabel(this);
	title->setText(trUtf8("天嵌科技按键测试程序"));
	title->setAlignment(Qt::AlignCenter);
	title->setMaximumHeight(30);

	pb_left = new QPushButton(this);
	pb_left->setText("");
	pb_left->setFixedSize(button_x,botton_y);
	pb_left->setIconSize(QSize(button_x,botton_y));
	pix.load("/opt/PDA/app/images/button_left.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_left->setIcon(QIcon(pix));

	pb_up = new QPushButton(this);
	pb_up->setText("");
	pb_up->setFixedSize(button_x,botton_y);
	pb_up->setIconSize(QSize(button_x,botton_y));
	pix.load("/opt/PDA/app/images/button_up.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_up->setIcon(QIcon(pix));

	pb_down = new QPushButton(this);
	pb_down->setText("");
	pb_down->setFixedSize(button_x,botton_y);
	pb_down->setIconSize(QSize(button_x,botton_y));
	pix.load("/opt/PDA/app/images/button_down.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_down->setIcon(QIcon(pix));

	pb_right = new QPushButton(this);
	pb_right->setText("");
	pb_right->setFixedSize(button_x,botton_y);
	pb_right->setIconSize(QSize(button_x,botton_y));
	pix.load("/opt/PDA/app/images/button_right.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_right->setIcon(QIcon(pix));

	pb_esc = new QPushButton(this);
	pb_esc->setText("");
	pb_esc->setFixedSize(button_x,botton_y);
	pb_esc->setIconSize(QSize(button_x,botton_y));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_esc->setIcon(QIcon(pix));

	pb_help = new QPushButton(this);
	pb_help->setText("");
	pb_help->setFixedSize(button_x,botton_y);
	pb_help->setIconSize(QSize(button_x,botton_y));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_help->setIcon(QIcon(pix));

	connect(pb_esc, SIGNAL(clicked()), this, SLOT(close()));
	connect(pb_help, SIGNAL(clicked()), this, SLOT(pbClickHelp()));

	QGridLayout *gridLayout = new QGridLayout;
	gridLayout->addWidget(pb_up, 1, 1);
	gridLayout->addWidget(pb_left, 2, 0);
	gridLayout->addWidget(pb_right, 2, 2);
	gridLayout->addWidget(pb_down, 3, 1);
	gridLayout->addWidget(pb_help, 4, 0);
	gridLayout->addWidget(pb_esc, 4, 2);

	QVBoxLayout *forthLayout = new QVBoxLayout;
	forthLayout->addWidget(title);
	forthLayout->addLayout(gridLayout);

	setLayout(forthLayout);
}

TQButton::~TQButton()
{

}

void TQButton::pbClickHelp()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
void TQButton::keyPressEvent(QKeyEvent *event)
{

	QPixmap pix;
	switch (event->key())
	{
	case Qt::Key_Up:
	{
		//cout << "按键 Up 按下" << endl;
		reShowPic();
		pix.load("/opt/PDA/app/images/button_an_up.png", 0,
				Qt::AutoColor);
		pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
		pb_up->setIcon(QIcon(pix));
	}
		break;
	case Qt::Key_Down:
	{
		//cout << "按键 Down 按下" << endl;
		m_iKeyValue = 17;

		reShowPic();
		QPixmap pix("/opt/PDA/app/images/button_an_down.png", 0,
				Qt::AutoColor);
		pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
		pb_down->setIcon(QIcon(pix));
	}
		break;
	case Qt::Key_Left:
	{
		//cout << "按键 Left 按下" << endl;
		reShowPic();
		pix.load("/opt/PDA/app/images/button_an_left.png", 0,
				Qt::AutoColor);
		pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
		pb_left->setIcon(QIcon(pix));
	}
		break;
	case Qt::Key_Right:
	{
		//cout << "按键 Right 按下" << endl;
		reShowPic();
		pix.load("/opt/PDA/app/images/button_an_right.png", 0,
				Qt::AutoColor);
		pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
		pb_right->setIcon(QIcon(pix));
	}
		break;

	case Qt::Key_Escape:
	{
		//cout << "按键 Escape 按下" << endl;
		reShowPic();
		pix.load("/opt/PDA/app/images/button_an_esc.png", 0,
				Qt::AutoColor);
		pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
		pb_esc->setIcon(QIcon(pix));

		QMessageBox question;
		question.setWindowTitle(trUtf8("警告"));
		question.setText(trUtf8("是否关闭？"));
		question.setStandardButtons(
				QMessageBox::Yes | QMessageBox::Cancel);
		question.setDefaultButton(QMessageBox::Yes);
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0,
				Qt::AutoColor);
		QIcon icon(pix);
		question .setWindowIcon(icon);

		int ret = question.exec();
		switch (ret)
		{
		case QMessageBox::Yes:
		{
			close();
		}
			break;
		case QMessageBox::Cancel:
			return;
			break;
		default:
			break;
		}
	}
		break;

	default://
		break;
	}
}
void TQButton::reShowPic()
{
	QPixmap pix;

	pix.load("/opt/PDA/app/images/button_up.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_up->setIcon(QIcon(pix));

	pix.load("/opt/PDA/app/images/button_down.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_down->setIcon(QIcon(pix));

	pix.load("/opt/PDA/app/images/button_left.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_left->setIcon(QIcon(pix));

	pix.load("/opt/PDA/app/images/button_right.png", 0, Qt::AutoColor);
	pix = pix.scaled(button_x,botton_y, Qt::IgnoreAspectRatio);//图片大小
	pb_right->setIcon(QIcon(pix));

}
