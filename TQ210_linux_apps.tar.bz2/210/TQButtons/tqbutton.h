#ifndef TQBUTTON_H
#define TQBUTTON_H

#include <QtGui/QWidget>
#include "ui_tqbutton.h"
 #include <QKeyEvent>
#include<QPushButton>
//#include "ui_tqbutton.h"
#include<QTextEdit>
#include <QPushButton>
#include <QLabel>
#include <QLCDNumber>
#include <QProcess>

class TQButton : public QWidget
{
    Q_OBJECT

public:
    TQButton(QWidget *parent = 0);
    ~TQButton();
	void keyPressEvent(QKeyEvent *event);//
	void reShowPic();
	QRect screen_size;
public slots:
	void pbClickHelp();
private:
//	 Ui::buttonClass ui;
	int button_x;
	int botton_y;
	 int m_iKeyValue;
	 QProcess process;
	 QLabel *title;
	 QPushButton *pb_left;
	 QPushButton *pb_up;
	 QPushButton *pb_down;
	 QPushButton *pb_right;
	 QPushButton *pb_esc;
	 QPushButton *pb_help;

};

#endif // TQBUTTON_H
