/****************************************************************************
 **
 ** Copyright (C) 2009 Nokia Corporation and/or its subsidiary(-ies).
 ** Contact: Qt Software Information (qt-info@nokia.com)
 **
 ** This file is part of the example classes of the Qt Toolkit.
 **
 ** $QT_BEGIN_LICENSE:LGPL$
 ** Commercial Usage
 ** Licensees holding valid Qt Commercial licenses may use this file in
 ** accordance with the Qt Commercial License Agreement provided with the
 ** Software or, alternatively, in accordance with the terms contained in
 ** a written agreement between you and Nokia.
 **
 ** GNU Lesser General Public License Usage
 ** Alternatively, this file may be used under the terms of the GNU Lesser
 ** General Public License version 2.1 as published by the Free Software
 ** Foundation and appearing in the file LICENSE.LGPL included in the
 ** packaging of this file.  Please review the following information to
 ** ensure the GNU Lesser General Public License version 2.1 requirements
 ** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
 **
 ** In addition, as a special exception, Nokia gives you certain
 ** additional rights. These rights are described in the Nokia Qt LGPL
 ** Exception version 1.0, included in the file LGPL_EXCEPTION.txt in this
 ** package.
 **
 ** GNU General Public License Usage
 ** Alternatively, this file may be used under the terms of the GNU
 ** General Public License version 3.0 as published by the Free Software
 ** Foundation and appearing in the file LICENSE.GPL included in the
 ** packaging of this file.  Please review the following information to
 ** ensure the GNU General Public License version 3.0 requirements will be
 ** met: http://www.gnu.org/copyleft/gpl.html.
 **
 ** If you are unsure which license is appropriate for your use, please
 ** contact the sales department at qt-sales@nokia.com.
 ** $QT_END_LICENSE$
 **
 ****************************************************************************/

#include <QtGui>

#include <math.h>

#include "button.h"
#include "calculator.h"
//#include <iostream>
#include<QLabel>
//using namespace std;

Calculator::Calculator(QWidget *parent) :
	QWidget(parent)
{
	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	sumInMemory = 0.0;
	sumSoFar = 0.0;
	factorSoFar = 0.0;
	waitingForOperand = true;

	display = new QLineEdit("0");
	display->setReadOnly(true);
	display->setAlignment(Qt::AlignRight);
	display->setMaxLength(15);
	display->setMinimumHeight(25);

	QFont font = display->font();
	font.setPointSize(font.pointSize() + 8);
	display->setFont(font);
	//! [2]

	//! [4]
	for (int i = 0; i < NumDigitButtons; ++i)
	{
		digitButtons[i]
				= createButton(QString::number(i), SLOT(digitClicked()));
	}

	QLabel *labelTitle = new QLabel(trUtf8("天嵌科技计算器"), this);
	labelTitle->setAlignment(Qt::AlignCenter);

	Button *pointButton = createButton(tr("."), SLOT(pointClicked()));
	Button *changeSignButton = createButton(tr("\261"),
			SLOT(changeSignClicked()));

	Button *helpButton = createButton(trUtf8("帮助"), SLOT(helpClicked()));
	Button *backspaceButton = createButton(trUtf8("退格"),
			SLOT(backspaceClicked()));
	Button *clearButton = createButton(trUtf8("清除"), SLOT(clear()));
	clearButton->hide();
	Button *clearAllButton = createButton(trUtf8("清除"), SLOT(clearAll()));
	Button *exitButton = createButton(trUtf8("退出"), SLOT(close()));

	Button *clearMemoryButton = createButton(tr("MC"), SLOT(clearMemory()));
	Button *readMemoryButton = createButton(tr("MR"), SLOT(readMemory()));
	Button *setMemoryButton = createButton(tr("MS"), SLOT(setMemory()));
	Button *addToMemoryButton = createButton(tr("M+"), SLOT(addToMemory()));

	Button *divisionButton = createButton(tr("\367"),
			SLOT(multiplicativeOperatorClicked()));
	Button *timesButton = createButton(tr("\327"),
			SLOT(multiplicativeOperatorClicked()));
	Button *minusButton =
			createButton(tr("-"), SLOT(additiveOperatorClicked()));
	Button *plusButton = createButton(tr("+"), SLOT(additiveOperatorClicked()));

	Button *squareRootButton = createButton(tr("Sqrt"),
			SLOT(unaryOperatorClicked()));
	Button *powerButton = createButton(tr("x\262"),
			SLOT(unaryOperatorClicked()));
	Button *reciprocalButton = createButton(tr("1/x"),
			SLOT(unaryOperatorClicked()));
	Button *equalButton = createButton(tr("="), SLOT(equalClicked()));
	//! [4]

	//! [5]
	QGridLayout *mainLayout = new QGridLayout;
	//! [5] //! [6]
	mainLayout->setSizeConstraint(QLayout::SetFixedSize);

	mainLayout->addWidget(display, 0, 0, 1, 6);
	mainLayout->addWidget(helpButton, 1, 0, 1, 2);
	mainLayout->addWidget(backspaceButton, 1, 2, 1, 2);//clearButton
	mainLayout->addWidget(clearAllButton, 1, 4, 1, 1);
	mainLayout->addWidget(exitButton, 1, 5, 1, 1);

	mainLayout->addWidget(clearMemoryButton, 2, 0);
	mainLayout->addWidget(readMemoryButton, 3, 0);
	mainLayout->addWidget(setMemoryButton, 4, 0);
	mainLayout->addWidget(addToMemoryButton, 5, 0);

	for (int i = 1; i < NumDigitButtons; ++i)
	{
		int row = ((9 - i) / 3) + 2;
		int column = ((i - 1) % 3) + 1;
		mainLayout->addWidget(digitButtons[i], row, column);
	}

	mainLayout->addWidget(digitButtons[0], 5, 1);
	mainLayout->addWidget(pointButton, 5, 2);
	mainLayout->addWidget(changeSignButton, 5, 3);

	mainLayout->addWidget(divisionButton, 2, 4);
	mainLayout->addWidget(timesButton, 3, 4);
	mainLayout->addWidget(minusButton, 4, 4);
	mainLayout->addWidget(plusButton, 5, 4);

	mainLayout->addWidget(squareRootButton, 2, 5);
	mainLayout->addWidget(powerButton, 3, 5);
	mainLayout->addWidget(reciprocalButton, 4, 5);
	mainLayout->addWidget(equalButton, 5, 5);
	//	setLayout(mainLayout);


	QVBoxLayout *layout = new QVBoxLayout;
	layout->addWidget(labelTitle);
	layout->addLayout(mainLayout);
	setLayout(layout);

	setWindowTitle(trUtf8("天嵌科技计算器V1.0(www.EmbedSky.net)"));
}
Calculator::~Calculator()
{
	delete display;
}
QString Calculator::formateDouble(double db)
{
	char cData[50];
	sprintf(cData, "%.9f", db);

	QString str = QString(cData);
	while (str.endsWith('0'))
		str = str.mid(0, str.length() - 1);
	if (str.endsWith('.'))
		str = str.mid(0, str.length() - 1);
	return str;
}
void Calculator::digitClicked()
{
	Button *clickedButton = qobject_cast<Button *> (sender());
	int digitValue = clickedButton->text().toInt();
	if (display->text() == "0" && digitValue == 0.0)
		return;

	if (waitingForOperand)
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}

void Calculator::unaryOperatorClicked()
{
	Button *clickedButton = qobject_cast<Button *> (sender());
	QString clickedOperator = clickedButton->text();
	double operand = display->text().toDouble();
	double result = 0.0;

	if (clickedOperator == tr("Sqrt"))
	{
		if (operand < 0.0)
		{
			abortOperation();
			return;
		}
		result = sqrt(operand);
	}
	else if (clickedOperator == tr("x\262"))
	{
		result = pow(operand, 2.0);
	}
	else if (clickedOperator == tr("1/x"))
	{
		if (operand == 0.0)
		{
			abortOperation();
			return;
		}
		result = 1.0 / operand;
	}

	display->setText(formateDouble(result));

	//display->setText(QString::number(result, 'g'));
	waitingForOperand = true;
}

void Calculator::additiveOperatorClicked()
{
	Button *clickedButton = qobject_cast<Button *> (sender());
	QString clickedOperator = clickedButton->text();
	double operand = display->text().toDouble();
	//! [11] //! [12]
	if (!pendingMultiplicativeOperator.isEmpty())
	{
		if (!calculate(operand, pendingMultiplicativeOperator))
		{
			abortOperation();
			return;
		}

		display->setText(formateDouble(factorSoFar));

		//display->setText(QString::number(factorSoFar, 'g'));
		operand = factorSoFar;
		factorSoFar = 0.0;
		pendingMultiplicativeOperator.clear();
	}

	if (!pendingAdditiveOperator.isEmpty())
	{
		if (!calculate(operand, pendingAdditiveOperator))
		{
			abortOperation();
			return;
		}

		display->setText(formateDouble(sumSoFar));
	}
	else
	{
		sumSoFar = operand;
	}

	pendingAdditiveOperator = clickedOperator;

	waitingForOperand = true;
}
//! [17]

//! [18]
void Calculator::multiplicativeOperatorClicked()
{
	Button *clickedButton = qobject_cast<Button *> (sender());
	QString clickedOperator = clickedButton->text();
	double operand = display->text().toDouble();

	if (!pendingMultiplicativeOperator.isEmpty())
	{
		if (!calculate(operand, pendingMultiplicativeOperator))
		{
			abortOperation();
			return;
		}

		display->setText(formateDouble(factorSoFar));
		//		display->setText(QString::number(factorSoFar, 'g'));
	}
	else
	{
		factorSoFar = operand;
	}

	pendingMultiplicativeOperator = clickedOperator;
	waitingForOperand = true;
}
//! [18]

//! [20]
void Calculator::equalClicked()
{
	double operand = display->text().toDouble();

	if (!pendingMultiplicativeOperator.isEmpty())
	{
		if (!calculate(operand, pendingMultiplicativeOperator))
		{
			abortOperation();
			return;
		}
		operand = factorSoFar;
		factorSoFar = 0.0;
		pendingMultiplicativeOperator.clear();
	}
	if (!pendingAdditiveOperator.isEmpty())
	{
		if (!calculate(operand, pendingAdditiveOperator))
		{
			abortOperation();
			return;
		}
		pendingAdditiveOperator.clear();
	}
	else
	{
		sumSoFar = operand;
	}

	display->setText(formateDouble(sumSoFar));
	//display->setText(QString::number(sumSoFar, 'g'));
	sumSoFar = 0.0;
	waitingForOperand = true;
}
//! [20]

//! [22]
void Calculator::pointClicked()
{
	if (waitingForOperand)
		display->setText("0");
	if (!display->text().contains("."))
		display->setText(display->text() + tr("."));
	waitingForOperand = false;
}
//! [22]

//! [24]
void Calculator::changeSignClicked()
{
	QString text = display->text();
	double value = text.toDouble();

	if (value > 0.0)
	{
		text.prepend(tr("-"));
	}
	else if (value < 0.0)
	{
		text.remove(0, 1);
	}
	display->setText(text);
}

void Calculator::backspaceClicked()
{
	if (waitingForOperand)
		return;

	QString text = display->text();
	text.chop(1);
	if (text.isEmpty())
	{
		text = "0";
		waitingForOperand = true;
	}
	display->setText(text);
}

void Calculator::clear()
{
	if (waitingForOperand)
		return;

	display->setText("0");
	waitingForOperand = true;
}

void Calculator::clearAll()
{
	sumSoFar = 0.0;
	factorSoFar = 0.0;
	pendingAdditiveOperator.clear();
	pendingMultiplicativeOperator.clear();
	display->setText("0");
	waitingForOperand = true;
}

void Calculator::clearMemory()
{
	sumInMemory = 0.0;
}

void Calculator::readMemory()
{
	display->setText(formateDouble(sumInMemory));
	waitingForOperand = true;
}

void Calculator::setMemory()
{
	equalClicked();
	sumInMemory = display->text().toDouble();
}

void Calculator::addToMemory()
{
	equalClicked();
	sumInMemory += display->text().toDouble();
}
//! [32]
//! [34]
Button *Calculator::createButton(const QString &text, const char *member)
{
	Button *button = new Button(text, this);
	connect(button, SIGNAL(clicked()), this, member);
	return button;
}
//! [34]

//! [36]
void Calculator::abortOperation()
{
	clearAll();
	display->setText(tr("####"));
}

bool Calculator::calculate(double rightOperand, const QString &pendingOperator)
{
	if (pendingOperator == tr("+"))
	{
		sumSoFar += rightOperand;
	}
	else if (pendingOperator == tr("-"))
	{
		sumSoFar -= rightOperand;
	}
	else if (pendingOperator == tr("\327"))
	{
		factorSoFar *= rightOperand;
	}
	else if (pendingOperator == tr("\367"))
	{
		if (rightOperand == 0.0)
			return false;
		factorSoFar /= rightOperand;
	}
	return true;
}
void Calculator::helpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
