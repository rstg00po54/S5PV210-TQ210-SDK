/****************************************************************************
 **
 ** Copyright (C) 2009 Nokia Corporation and/or its subsidiary(-ies).
 ** Contact: Qt Software Information (qt-info@nokia.com)
 **
 ** This file is part of the example classes of the Qt Toolkit.
 **
 ** $QT_BEGIN_LICENSE:LGPL$
 ** Commercial Usage
 ** Licensees holding valid Qt Commercial licenses may use this file in
 ** accordance with the Qt Commercial License Agreement provided with the
 ** Software or, alternatively, in accordance with the terms contained in
 ** a written agreement between you and Nokia.
 **
 ** GNU Lesser General Public License Usage
 ** Alternatively, this file may be used under the terms of the GNU Lesser
 ** General Public License version 2.1 as published by the Free Software
 ** Foundation and appearing in the file LICENSE.LGPL included in the
 ** packaging of this file.  Please review the following information to
 ** ensure the GNU Lesser General Public License version 2.1 requirements
 ** will be met: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
 **
 ** In addition, as a special exception, Nokia gives you certain
 ** additional rights. These rights are described in the Nokia Qt LGPL
 ** Exception version 1.0, included in the file LGPL_EXCEPTION.txt in this
 ** package.
 **
 ** GNU General Public License Usage
 ** Alternatively, this file may be used under the terms of the GNU
 ** General Public License version 3.0 as published by the Free Software
 ** Foundation and appearing in the file LICENSE.GPL included in the
 ** packaging of this file.  Please review the following information to
 ** ensure the GNU General Public License version 3.0 requirements will be
 ** met: http://www.gnu.org/copyleft/gpl.html.
 **
 ** If you are unsure which license is appropriate for your use, please
 ** contact the sales department at qt-sales@nokia.com.
 ** $QT_END_LICENSE$
 **
 ****************************************************************************/

#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <QWidget>
#include <qprocess.h>

QT_BEGIN_NAMESPACE
class QLineEdit;
QT_END_NAMESPACE
class Button;

//! [0]
class Calculator: public QWidget
{
	Q_OBJECT

public:
	Calculator(QWidget *parent = 0);
	~Calculator();
	private slots:
	void digitClicked();
	void unaryOperatorClicked();
	void additiveOperatorClicked();
	void multiplicativeOperatorClicked();
	void equalClicked();
	void pointClicked();
	void changeSignClicked();
	void backspaceClicked();
	void clear();
	void clearAll();
	void clearMemory();
	void readMemory();
	void setMemory();
	void addToMemory();
	void helpClicked();
	//! [0]

	//! [1]
private:
	//! [1] //! [2]
	Button *createButton(const QString &text, const char *member);
	void abortOperation();
	bool calculate(double rightOperand, const QString &pendingOperator);
	//! [2]

	//! [3]
	double sumInMemory;
	//! [3] //! [4]
	double sumSoFar;
	//! [4] //! [5]
	double factorSoFar;
	//! [5] //! [6]
	QString pendingAdditiveOperator;
	//! [6] //! [7]
	QString pendingMultiplicativeOperator;
	//! [7] //! [8]
	bool waitingForOperand;
	//! [8]

	//! [9]
	QLineEdit *display;
	//! [9] //! [10]

	QProcess process;

	QString formateDouble(double);
	enum
	{
		NumDigitButtons = 10
	};
	Button *digitButtons[NumDigitButtons];
};
//! [10]

#endif
