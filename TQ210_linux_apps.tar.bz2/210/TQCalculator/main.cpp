#include "tqcalculator.h"

#include <QtGui>
#include <QApplication>
#include <calculator.h>
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	Calculator w;
	w.showFullScreen();
	return a.exec();
}
