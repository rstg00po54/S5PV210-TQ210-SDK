#include "tqcalculator.h"
#include <QFrame>
#include <QPushButton>
#include <QComboBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QApplication>
#include <QDesktopWidget>
#include <stdio.h>
#include <QRegExp>
//#include <iostream>
//using namespace std;
TQCalculator::TQCalculator(QWidget *parent) :
	QWidget(parent)
{
	this->setWindowTitle(trUtf8("天嵌科技计算器V1.0(www.EmbedSky.net)"));
	QRect screen_size = QApplication::desktop()->screenGeometry();

	//this->setGeometry(0, 25, screen_size.width(), screen_size.height() - 25);
	setGeometry(0, 25, 480, 247);

	m_bIsFunctionClicked = false;
	m_bEuqalClicked = false;
	m_strMemory = "0";

	QVBoxLayout *vLayout = new QVBoxLayout;
	m_pleInput = new QLineEdit(this);
	//	m_pleInput->setLayoutDirection(Qt::RightToLeft);
	m_pleInput->setAlignment(Qt::AlignRight);
	QRegExp exp("^-?\\d+[.]$");//正则表达式，整数或点号
	m_pleInput->setValidator(new QRegExpValidator(exp, this));
	m_pleInput->setMaxLength(12);
	m_pleInput->setText("0");
	vLayout->addWidget(m_pleInput);

	//	QStringList list;
	//	list << "aaa" << "bbb" << "ccc";
	//	QComboBox *cbType = new QComboBox(this);
	//	cbType->addItems(list);
	//	vLayout->addWidget(cbType);


	//QFrame *frameSimple = new QFrame(this);
	//frameSimple->hide();
	QHBoxLayout *buttonLayout = new QHBoxLayout;

	QVBoxLayout *numberLeftLayout = new QVBoxLayout;

	QPushButton *pbBackSpace = new QPushButton(tr("BackSapce"), this);
	QPushButton *pbNumber7 = new QPushButton(tr("7"), this);
	QPushButton *pbNumber4 = new QPushButton(tr("4"), this);
	QPushButton *pbNumber1 = new QPushButton(tr("1"), this);
	QPushButton *pbNumber0 = new QPushButton(tr("0"), this);
	numberLeftLayout->addWidget(pbBackSpace);
	numberLeftLayout->addWidget(pbNumber7);
	numberLeftLayout->addWidget(pbNumber4);
	numberLeftLayout->addWidget(pbNumber1);
	numberLeftLayout->addWidget(pbNumber0);

	QVBoxLayout *numberMidLayout = new QVBoxLayout;
	QPushButton *pbDivide = new QPushButton(tr("/"), this);
	QPushButton *pbNumber8 = new QPushButton(tr("8"), this);
	QPushButton *pbNumber5 = new QPushButton(tr("5"), this);
	QPushButton *pbNumber2 = new QPushButton(tr("2"), this);
	QPushButton *pbDot = new QPushButton(tr("."), this);
	numberMidLayout->addWidget(pbDivide);
	numberMidLayout->addWidget(pbNumber8);
	numberMidLayout->addWidget(pbNumber5);
	numberMidLayout->addWidget(pbNumber2);
	numberMidLayout->addWidget(pbDot);

	QVBoxLayout *numberRightLayout = new QVBoxLayout;
	QPushButton *pbMul = new QPushButton(tr("x"), this);
	QPushButton *pbNumber9 = new QPushButton(tr("9"), this);
	QPushButton *pbNumber6 = new QPushButton(tr("6"), this);
	QPushButton *pbNumber3 = new QPushButton(tr("3"), this);
	QPushButton *pbAddSub = new QPushButton(tr("+/-"), this);
	numberRightLayout->addWidget(pbMul);
	numberRightLayout->addWidget(pbNumber9);
	numberRightLayout->addWidget(pbNumber6);
	numberRightLayout->addWidget(pbNumber3);
	numberRightLayout->addWidget(pbAddSub);

	QVBoxLayout *functionLeftLayout = new QVBoxLayout;
	QPushButton *pbSub = new QPushButton(tr("-"), this);
	//pbSub->setMaximumHeight(30);
	QPushButton *pbAdd = new QPushButton(tr("+"), this);
	pbAdd->setMinimumHeight(60);
	QPushButton *pbEqual = new QPushButton(tr("="), this);
	pbEqual->setMinimumHeight(60);

	functionLeftLayout->addWidget(pbSub);
	functionLeftLayout->addWidget(pbAdd);
	functionLeftLayout->addWidget(pbEqual);

	QVBoxLayout *functionRightLayout = new QVBoxLayout;
	QPushButton *pbCE = new QPushButton(tr("CE/C"), this);
	pbCE->setMinimumHeight(35);
	QPushButton *pbMC = new QPushButton(tr("MC"), this);
	pbMC->setMinimumHeight(35);
	QPushButton *pbMR = new QPushButton(tr("MR"), this);
	pbMR->setMinimumHeight(35);
	QPushButton *pbMA = new QPushButton(tr("M+"), this);
	pbMA->setMinimumHeight(35);

	functionRightLayout->addWidget(pbCE);
	functionRightLayout->addWidget(pbMC);
	functionRightLayout->addWidget(pbMR);
	functionRightLayout->addWidget(pbMA);
	//	functionRightLayout->addStretch(1);

	buttonLayout->addLayout(numberLeftLayout);
	buttonLayout->addLayout(numberMidLayout);
	buttonLayout->addLayout(numberRightLayout);
	buttonLayout->addLayout(functionLeftLayout);
	buttonLayout->addLayout(functionRightLayout);

	vLayout->addLayout(buttonLayout);

	this->setLayout(vLayout);

	connect(pbNumber0, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbNumber1, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbNumber2, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbNumber3, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbNumber4, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbNumber5, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbNumber6, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbNumber7, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbNumber8, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbNumber9, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));
	connect(pbDot, SIGNAL(clicked()), this, SLOT(pbNumberClicked()));

	connect(pbBackSpace, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbAdd, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbCE, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbDivide, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbEqual, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbMA, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbMC, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbMR, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbMul, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbSub, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
	connect(pbAddSub, SIGNAL(clicked()), this, SLOT(pbFunctionClicked()));
}

TQCalculator::~TQCalculator()
{
	delete m_pleInput;
}
//数字键
void TQCalculator::pbNumberClicked()
{
	QString strNumber = ((QPushButton *) sender())->text();
	if (m_bIsFunctionClicked)
	{
		m_pleInput->clear();
		//m_pleInput->setText(((QPushButton *) sender())->text());
		m_bIsFunctionClicked = false;
	}
	if (strNumber == ".") //点号
	{
		if (m_pleInput->text() != "0")
		{
			QString str = m_pleInput->text();
			if (str.indexOf('.') <= 0)
			{
				m_pleInput->insert(".");
			}
		}
	}
	else
	{
		if (m_pleInput->text() == "0")
			m_pleInput->clear();
		m_pleInput->setText(m_pleInput->text() + strNumber);
	}
	m_bDoFunc = true;
}
//功能键
void TQCalculator::pbFunctionClicked()
{
	QString strFunc = ((QPushButton *) sender())->text();
	//	cout << strFunc.toStdString().c_str() << endl;
	if (strFunc == "BackSapce")
	{
		if (m_pleInput->text().length() > 0)
			m_pleInput->setText(
					m_pleInput->text().mid(0, m_pleInput->text().length() - 1));
	}
	else if (strFunc == "CE/C")
	{
		m_pleInput->clear();
		m_strOld = "";
		m_bIsFunctionClicked = false;
		m_strFunc = "";
	}
	else if (strFunc == "+" || strFunc == "-" || strFunc == "x" || strFunc
			== "/")
	{
		if (m_strOld != "")
		{
			if (m_bDoFunc)
			{
				m_pleInput->setText(
						DoFunc(m_strOld, m_pleInput->text(), m_strFunc));
			}
		}
		else
		{
			m_strFunc = strFunc;
			m_strOld = m_pleInput->text();
		}
		m_bIsFunctionClicked = true;
		m_bDoFunc = false;
	}
	else if (strFunc == "=")
	{
		if (m_strOld != "")
		{
			m_pleInput->setText(DoFunc(m_strOld, m_pleInput->text(), m_strFunc));
		}
		m_strFunc = "";
		m_strOld = "";
		m_bIsFunctionClicked = true;
	}
	else if (strFunc == "MC")
	{
		m_strMemory = "0";
	}
	else if (strFunc == "M+")
	{
		m_strMemory = m_pleInput->text();
	}
	else if (strFunc == "MR")
	{
		m_pleInput->setText(m_strMemory);
	}
	else if (strFunc == "+/-")
	{
		QString str = m_pleInput->text();
		if (str != "0")
		{
			double dValue = str.toDouble();
			dValue = 0 - dValue;
			str = QString::number(dValue);
			m_pleInput->setText(str);
			//cout<<str.toStdString().c_str()<<endl;
		}
	}
}
QString TQCalculator::DoFunc(QString strPara1, QString strPara2,
		QString strFunc)
{
	QString strResult;
	double dResult, dPara1, dPara2;
	dPara1 = strPara1.toDouble();
	dPara2 = strPara2.toDouble();
	if (strFunc == "+")
	{
		dResult = dPara1 + dPara2;
	}
	else if (strFunc == "-")
	{
		dResult = dPara1 - dPara2;
	}
	else if (strFunc == "x")
	{
		dResult = dPara1 * dPara2;
	}
	else if (strFunc == "/")
	{
		if (strPara2.toInt(NULL, 10) == 0)
			return "Divide zero error";
		dResult = dPara1 / dPara2;
	}
	strResult = QString::number(dResult);
	return strResult;
}
