#ifndef TQCALCULATOR_H
#define TQCALCULATOR_H

#include <QtGui/QWidget>
#include <QLineEdit>
#include <QStringList>
class TQCalculator : public QWidget
{
    Q_OBJECT

public:
    TQCalculator(QWidget *parent = 0);
    ~TQCalculator();

private:
    QLineEdit *m_pleInput;
    bool m_bIsFunctionClicked;//是否有功能键
    bool m_bEuqalClicked;//等号是否按过
    bool m_bDoFunc;//是否做算法
    QString m_strOld;//原值
    QString m_strFunc;//算法
    QString m_strMemory;//记忆
    QString DoFunc(QString strPara1,QString strPara2,QString strFunc);//计算
public slots:
	void pbNumberClicked();
	void pbFunctionClicked();
};

#endif // TQCALCULATOR_H
