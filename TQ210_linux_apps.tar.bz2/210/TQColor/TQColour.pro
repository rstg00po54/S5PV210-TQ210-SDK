#-------------------------------------------------
#
# Project created by QtCreator 2011-04-15T18:39:57
#
#-------------------------------------------------

TARGET = tqcolour
TEMPLATE = app


SOURCES += main.cpp\
        colour.cpp

HEADERS  += colour.h

FORMS    += colour.ui
