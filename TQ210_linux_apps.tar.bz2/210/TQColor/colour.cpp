/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		颜色测试
 *    文件名:     		colour.cpp
 *    文件描述:  		主界面
 *    创建日期:      2011-06-28
 *    创 建 人:      gxx
 *    文档:
 *    数据库："/opt/PDA/src/fingerdata.db"
 *    运行平台:      linux
 *    其
 */
#include "colour.h"
#include<QTimer>
#include<QPixmap>
//#include<iostream>
//using namespace std;
int n;//记录按下次数
QString str_colour[3] =
{ "red", "green", "blue" };
int pos_x, pos_y;
bool B_updown, B_leftright;
colour *g_colour;
colour::colour(QWidget *parent) :
	QWidget(parent)
{
	//	setAttribute(Qt::WA_DeleteOnClose);

	m_labPic = new QLabel(this);
	m_labPic->move(QPoint(0, 0));
	m_labPic->setPixmap(QPixmap("/opt/PDA/app/images/start"));

	timer = new QTimer(this);
	connect(timer, SIGNAL(timeout()), this, SLOT(flowPic()));
	timer->start(20);
}

colour::~colour()
{
	delete m_labPic;
	timer->stop();
	delete timer;
}

//鼠标按下响应
void colour::mousePressEvent(QMouseEvent *event)//鼠标按下相应
{

	event->globalX();
	n++;

	if (n == 1)
	{
		m_labPic->setPixmap(QPixmap("/opt/PDA/app/images/red.png"));
		pal.setColor(QPalette::Background, QColor(str_colour[n - 1]));
		this->setPalette(pal);
	}
	else if (n == 2)
	{
		m_labPic->setPixmap(QPixmap("/opt/PDA/app/images/green.png"));
		pal.setColor(QPalette::Background, QColor(str_colour[n - 1]));
		this->setPalette(pal);
	}
	else if (n == 3)
	{
		m_labPic->setPixmap(QPixmap("/opt/PDA/app/images/blue.png"));
		pal.setColor(QPalette::Background, QColor(str_colour[n - 1]));
		this->setPalette(pal);
	}
	else if (n == 4)
	{
		close();
	}

}
//动态显示颜色标签
void colour::flowPic()
{
	QRect screen_size = QApplication::desktop()->screenGeometry();//获取夜景屏大小

	if (B_leftright == 1)//如果需要左移
		pos_x -= 2;
	else
		//需要右移
		pos_x += 2;

	if (B_updown == 1)//上移
		pos_y--;
	else
		//下移
		pos_y++;

	if (pos_x == (screen_size.width() - 82))//到达最右端
		B_leftright = 1;
	if (pos_x == 0)//
		B_leftright = 0;
	if (pos_y == (screen_size.height() - 32))//
		B_updown = 1;
	if (pos_y == 0)//
		B_updown = 0;

	m_labPic->move(pos_x, pos_y);
}
