#ifndef COLOUR_H
#define COLOUR_H

#include <QWidget>
#include <QtGui>
#include<QLabel>
class colour: public QWidget
{
Q_OBJECT
public:
	colour(QWidget *parent = 0);
	~colour();
	void mousePressEvent(QMouseEvent * event);
public slots:
	void flowPic();

private:
	QLabel *m_labPic;
	QTimer *timer;
	QPalette pal;
};
extern colour *g_colour;
#endif // COLOUR_H
