#include "colour.h"

#include <QtGui>
#include <QApplication>
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	g_colour=new colour();
	QRect screen_size = QApplication::desktop()->screenGeometry();
	g_colour->setGeometry(0, 0, screen_size.width(), screen_size.height());
	g_colour->show();
	return a.exec();
}
