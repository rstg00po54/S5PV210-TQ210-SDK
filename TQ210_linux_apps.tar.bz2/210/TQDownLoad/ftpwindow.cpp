#include <QtGui>
#include <QtNetwork>
#include "ftpwindow.h"
#include "tqdownload.h"
#include<QMessageBox>
#include<QPixmap>
#include<iostream>
using namespace std;

#define WIDTH screen_size.width()/800
#define HEIGHT screen_size.height()/480

FtpWindow::FtpWindow(QWidget *parent, bool bKeyShow) :
	QDialog(parent), ftp(0)
{
	//123
	//this->setGeometry(0, 0, 800, 480);
	QRect screen_size = QApplication::desktop()->screenGeometry();
	this->setGeometry(0, 0, screen_size.width(), screen_size.height());

	m_pbKey = new QPushButton(this);
	m_pbKey->setFixedSize(60*WIDTH, 32*HEIGHT);
	m_pbKey->setIconSize(QSize(60*WIDTH, 32*HEIGHT));
	QPixmap pix("/opt/PDA/app/images/key.png", 0, Qt::AutoColor);
	pix = pix.scaled(60*WIDTH, 32*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	m_pbKey->setIcon(QIcon(pix));
	m_pbKey->setEnabled(0);

	ftpServerLabel = new QLabel(trUtf8("Ftp服务器:"));
	ftpServerLineEdit = new QLineEdit();
	ftpServerLineEdit->setText("ftp.qt.nokia.com");
	ftpServerLabel->setBuddy(ftpServerLineEdit);

	statusLabel = new QLabel(trUtf8("请输入Ftp服务器名."));

	fileList = new QTreeWidget;
	//fileList->setGeometry(new QRect(400,200));
	//fileList->setFixedSize(435, 110);
	fileList->setEnabled(false);
	fileList->setRootIsDecorated(false);
	fileList->setHeaderLabels(
			QStringList() << trUtf8("名称") << trUtf8("大小")
					<< trUtf8("所有者") << trUtf8("群组")
					<< trUtf8("日期"));
	fileList->header()->setStretchLastSection(false);

	connectButton = new QPushButton(this);
	connectButton->setFixedSize(82*WIDTH, 32*HEIGHT);
	connectButton->setIcon(QIcon("/opt/PDA/app/images/connect.png"));//设置退出案件图标
	connectButton->setIconSize(QSize(82*WIDTH, 32*HEIGHT));

	cdToParentButton = new QPushButton(this);
	cdToParentButton->setFixedSize(82*WIDTH, 32*HEIGHT);
	cdToParentButton->setIcon(QIcon("/opt/PDA/app/images/return.png"));//设置退出案件图标
	cdToParentButton->setIconSize(QSize(82*WIDTH, 32*HEIGHT));
	cdToParentButton->setEnabled(false);

	downloadButton = new QPushButton(this);
	downloadButton->setFixedSize(60*WIDTH, 32*HEIGHT);
	downloadButton->setIconSize(QSize(60*WIDTH, 32*HEIGHT));
	pix.load("/opt/PDA/app/images/down.png", 0, Qt::AutoColor);
	pix = pix.scaled(60*WIDTH, 32*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	downloadButton->setIcon(QIcon(pix));

	m_pbHelp = new QPushButton(this);
	m_pbHelp->setFixedSize(60*WIDTH, 32*HEIGHT);
	m_pbHelp->setIconSize(QSize(60*WIDTH, 32*HEIGHT));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(60*WIDTH, 32*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	quitButton = new QPushButton(this);
	quitButton->setFixedSize(60*WIDTH, 32*HEIGHT);
	quitButton->setIconSize(QSize(60*WIDTH, 32*HEIGHT));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(60*WIDTH, 32*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	quitButton->setIcon(QIcon(pix));

	//
	//	buttonBox = new QDialogButtonBox;
	//	buttonBox->addButton(downloadButton, QDialogButtonBox::ActionRole);
	//	buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

	QHBoxLayout *controlLayout = new QHBoxLayout;
	controlLayout->addWidget(statusLabel);
	controlLayout->addWidget(m_pbKey);
	controlLayout->addWidget(m_pbHelp);
	controlLayout->addWidget(downloadButton);
	controlLayout->addWidget(quitButton);

	progressDialog = new QProgressDialog(this);

	connect(
			fileList,
			SIGNAL(itemActivated(QTreeWidgetItem *, int)),
			this,
			SLOT(processItem(QTreeWidgetItem *, int)));
	connect(
			fileList,
			SIGNAL(currentItemChanged(QTreeWidgetItem *, QTreeWidgetItem *)),
			this, SLOT(enableDownloadButton()));
	connect(progressDialog, SIGNAL(canceled()), this,
			SLOT(cancelDownload()));
	connect(connectButton, SIGNAL(clicked()), this,
			SLOT(connectOrDisconnect()));
	connect(cdToParentButton, SIGNAL(clicked()), this, SLOT(cdToParent()));
	connect(downloadButton, SIGNAL(clicked()), this, SLOT(downloadFile()));
	connect(quitButton, SIGNAL(clicked()), this, SLOT(pbQuitClicked()));

	QHBoxLayout *topLayout = new QHBoxLayout;
	topLayout->addWidget(ftpServerLabel);
	topLayout->addWidget(ftpServerLineEdit);
	topLayout->addWidget(cdToParentButton);
	topLayout->addWidget(connectButton);
	//	topLayout->addSpacing(30);

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(topLayout);
	mainLayout->addWidget(fileList);
	//	mainLayout->addWidget(statusLabel);
	//	mainLayout->addWidget(buttonBox);
	mainLayout->addLayout(controlLayout);
	//	mainLayout->addSpacing(60*WIDTH);
	setLayout(mainLayout);

	//setWindowTitle(tr("FTP"));
	if (bKeyShow)
	{
		m_pbKey->setEnabled(1);
		connect(m_pbKey, SIGNAL(clicked()), this, SLOT(pbKeyShowHide()));
		im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(false);
	}
}
FtpWindow::~FtpWindow()
{
	delete ftpServerLabel;
	delete ftpServerLineEdit;
	delete statusLabel;
	delete fileList;
	delete cdToParentButton;
	delete connectButton;
	delete downloadButton;
	delete quitButton;
	delete progressDialog;
	delete ftp;
	delete file;
}
QSize FtpWindow::sizeHint() const
{
	QRect screen_size = QApplication::desktop()->screenGeometry();
	return QSize(500*WIDTH, 300*HEIGHT);
}

//![0]
void FtpWindow::pbQuitClicked()
{
	g_pDownLoad->close();
}
void FtpWindow::connectOrDisconnect()
{
	QRect screen_size = QApplication::desktop()->screenGeometry();

	if (ftp)
	{
		ftp->abort();
		ftp->deleteLater();
		ftp = 0;
		//![0]
		fileList->setEnabled(false);
		cdToParentButton->setEnabled(false);
		downloadButton->setEnabled(false);
		connectButton->setEnabled(true);
		connectButton->setEnabled(false);
		connectButton->setFixedSize(82*WIDTH, 32*HEIGHT);
		connectButton->setIcon(QIcon("/opt/PDA/app/images/connect.png"));//设置退出案件图标
		connectButton->setIconSize(QSize(82*WIDTH, 32*HEIGHT));
#ifndef QT_NO_CURSOR
		setCursor(Qt::ArrowCursor);
#endif
		return;
	}

#ifndef QT_NO_CURSOR
	setCursor(Qt::WaitCursor);
#endif

	//![1]
	ftp = new QFtp(this);
	connect(ftp, SIGNAL(commandFinished(int, bool)), this,
			SLOT(ftpCommandFinished(int, bool)));
	connect(ftp, SIGNAL(listInfo(const QUrlInfo &)), this,
			SLOT(addToList(const QUrlInfo &)));
	connect(
			ftp,
			SIGNAL(dataTransferProgress(qint64, qint64)),
			this,
			SLOT(updateDataTransferProgress(qint64, qint64)));

	fileList->clear();
	currentPath.clear();
	isDirectory.clear();
	//![1]

	//![2]
	QUrl url(ftpServerLineEdit->text());
	if (!url.isValid() || url.scheme().toLower() != QLatin1String("ftp"))
	{
		ftp->connectToHost(ftpServerLineEdit->text(), 21);
		ftp->login();
	}
	else
	{
		ftp->connectToHost(url.host(), url.port(21));

		if (!url.userName().isEmpty())
			ftp->login(
					QUrl::fromPercentEncoding(
							url.userName().toLatin1()),
					url.password());
		else
			ftp->login();
		if (!url.path().isEmpty())
			ftp->cd(url.path());
	}
	//![2]

	fileList->setEnabled(true);
	connectButton->setEnabled(false);
	connectButton->setFixedSize(82*WIDTH, 32*HEIGHT);
	connectButton->setIcon(QIcon("/opt/PDA/app/images/cancel.png"));//设置退出案件图标
	connectButton->setIconSize(QSize(82*WIDTH, 32*HEIGHT));

	statusLabel->setText(trUtf8("连接%1...") .arg(ftpServerLineEdit->text()));
}

//![3]
void FtpWindow::downloadFile()
{
	//	QString fileName = fileList->currentItem()->text(0);
	QString fileName = "/opt/PDA/download/" + fileList->currentItem()->text(0);
	//![3]
	//
	if (QFile::exists(fileName))
	{
//		QMessageBox::information(
//				this,
//				trUtf8("天嵌FTP下载"),
//				tr("There already exists a file called %1 in "
//					"the current directory.") .arg(fileName));

		QMessageBox msgBox;
		msgBox.setWindowTitle(trUtf8("警告"));
		msgBox.setText(trUtf8("文件已存在，是否覆盖并下载？"));
		msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
		msgBox.setDefaultButton(QMessageBox::Yes);
		int ret = msgBox.exec();
		switch (ret)
		{
		case QMessageBox::Yes:
		{
		}
			break;
		case QMessageBox::No:
			return;
			break;
		default:
			break;
		}

	}

	//![4]
	file = new QFile(fileName);
	if (!file->open(QIODevice::WriteOnly))
	{
		QMessageBox::information(
				this,
				trUtf8("天嵌FTP下载"),
				trUtf8("无法保存文件： %1: %2.") .arg(fileName).arg(
						file->errorString()));
		delete file;
		return;
	}

	ftp->get(fileList->currentItem()->text(0), file);

	progressDialog->setLabelText(trUtf8("下载中 %1...").arg(fileName));
	downloadButton->setEnabled(false);
	progressDialog->exec();
}
//![4]

//![5]
void FtpWindow::cancelDownload()
{
	ftp->abort();
}
//![5]

//![6]
void FtpWindow::ftpCommandFinished(int, bool error)
{

#ifndef QT_NO_CURSOR
	setCursor(Qt::ArrowCursor);
#endif

	if (ftp->currentCommand() == QFtp::ConnectToHost)
	{
		if (error)
		{
			QMessageBox::information(
					this,
					trUtf8("天嵌FTP下载"),
					trUtf8("无法连接到Ftp服务器 "
						" %1. 请检查目标机是否正确.") .arg(
							ftpServerLineEdit->text()));
			connectOrDisconnect();
			return;
		}
		statusLabel->setText(
				trUtf8("成功登陆 %1.") .arg(
						ftpServerLineEdit->text()));
		fileList->setFocus();
		downloadButton->setDefault(true);
		connectButton->setEnabled(true);
		return;
	}
	//![6]

	//![7]
	if (ftp->currentCommand() == QFtp::Login)
		ftp->list();
	//![7]

	//![8]
	if (ftp->currentCommand() == QFtp::Get)
	{
		if (error)
		{
			statusLabel->setText(
					trUtf8("取消下载 %1.") .arg(
							file->fileName()));
			file->close();
			file->remove();
		}
		else
		{
			//			statusLabel->setText(trUtf8("成功下载 : %1") .arg(file->fileName()));

			QMessageBox warn;
			warn.setWindowTitle(trUtf8("提示"));
			warn.setText(trUtf8("下载到/opt/PDA/download/目录成功！"));
			warn.setStandardButtons(QMessageBox::Ok);
			QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0,
					Qt::AutoColor);
			QIcon icon(pix);
			warn .setWindowIcon(icon);
			warn.exec();

			file->close();
		}
		delete file;
		enableDownloadButton();
		progressDialog->hide();
	}
	else if (ftp->currentCommand() == QFtp::List)
	{
		if (isDirectory.isEmpty())
		{
			fileList->addTopLevelItem(
					new QTreeWidgetItem(
							QStringList()
									<< tr(
											"<empty>")));
			fileList->setEnabled(false);
		}
	}
	//![9]
}

//![10]
void FtpWindow::addToList(const QUrlInfo &urlInfo)
{
	QTreeWidgetItem *item = new QTreeWidgetItem;
	item->setText(0, urlInfo.name());
	item->setText(1, QString::number(urlInfo.size()));
	item->setText(2, urlInfo.owner());
	item->setText(3, urlInfo.group());
	item->setText(4, urlInfo.lastModified().toString("yyyy-MM-dd"));

	QPixmap pixmap(urlInfo.isDir() ? "images/dir.png" : "images/file.png");
	item->setIcon(0, pixmap);

	isDirectory[urlInfo.name()] = urlInfo.isDir();
	fileList->addTopLevelItem(item);
	if (!fileList->currentItem())
	{
		fileList->setCurrentItem(fileList->topLevelItem(0));
		fileList->setEnabled(true);
	}
}
//![10]

//![11]
void FtpWindow::processItem(QTreeWidgetItem *item, int /*column*/)
{
	QString name = item->text(0);
	if (isDirectory.value(name))
	{
		fileList->clear();
		isDirectory.clear();
		currentPath += "/" + name;
		ftp->cd(name);
		ftp->list();
		cdToParentButton->setEnabled(true);
#ifndef QT_NO_CURSOR
		setCursor(Qt::WaitCursor);
#endif
		return;
	}
}
//![11]

//![12]
void FtpWindow::cdToParent()
{
#ifndef QT_NO_CURSOR
	setCursor(Qt::WaitCursor);
#endif
	fileList->clear();
	isDirectory.clear();
	currentPath = currentPath.left(currentPath.lastIndexOf('/'));
	if (currentPath.isEmpty())
	{
		cdToParentButton->setEnabled(false);
		ftp->cd("/");
	}
	else
	{
		ftp->cd(currentPath);
	}
	ftp->list();
}
//![12]

//![13]
void FtpWindow::updateDataTransferProgress(qint64 readBytes, qint64 totalBytes)
{
	progressDialog->setMaximum(totalBytes);
	progressDialog->setValue(readBytes);
}
//![13]

//![14]
void FtpWindow::enableDownloadButton()
{
	QTreeWidgetItem *current = fileList->currentItem();
	if (current)
	{
		QString currentFile = current->text(0);
		downloadButton->setEnabled(!isDirectory.value(currentFile));
	}
	else
	{
		downloadButton->setEnabled(false);
	}
}
//![14]
void FtpWindow::pbKeyShowHide()
{
	((TQInputMethod *) im)->setVisible(true);
}
void FtpWindow::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
