#include <QtGui>
#include <QtNetwork>

#include "httpwindow.h"
#include "ui_authenticationdialog.h"
#include "tqdownload.h"
#include<iostream>

#define WIDTH screen_size.width()/800
#define HEIGHT screen_size.height()/480

using namespace std;
HttpWindow::HttpWindow(QWidget *parent, bool bKeyShow) :
	QDialog(parent)
{
	QRect screen_size = QApplication::desktop()->screenGeometry();
	this->setGeometry(0, 0, screen_size.width(), screen_size.height());
#ifndef QT_NO_OPENSSL
	urlLineEdit = new QTextEdit();
#else
	urlLineEdit = new QTextEdit();
#endif
	//	urlLineEdit->setText("https://");//
	//	urlLineEdit->setText("http://qt.nokia.com/index.html");//
	//	urlLineEdit->setText("﻿http://nchc.dl.sourceforge.net/project/u-boot/u-boot/U-Boot-1.1.6/u-boot-1.1.6.tar.bz2");
	urlLineEdit->setText(
			"http://mp3.baidu.com/j?j=2&url=http%3A%2F%2Fzhangmenshiting.baidu.com%2Fdata%2Fmusic%2F5220899%2F%25E4%25B9%2589%25E5%258B%2587%25E5%2586%259B%25E8%25BF%259B%25E8%25A1%258C%25E6%259B%25B2.mp3%3Fxcode%3Da7a71646832ddb4b67a477b1c0900709");
	urlLineEdit->setMinimumHeight(150*HEIGHT);
	urlLineEdit->setMaximumHeight(150*HEIGHT);

	urlLabel = new QLabel(tr("&URL:"));
	urlLabel->setBuddy(urlLineEdit);
	statusLabel = new QLabel(trUtf8("请输入要下载的链接或文件"));

	m_pbKey = new QPushButton(this);
	m_pbKey->setFixedSize(82*WIDTH, 32*HEIGHT);
	m_pbKey->setIcon(QIcon("/opt/PDA/app/images/key.png"));//设置退出案件图标
	m_pbKey->setIconSize(QSize(82*WIDTH, 32*HEIGHT));
	m_pbKey->setDefault(true);
	connect(m_pbKey, SIGNAL(clicked()), this, SLOT(pbKeyShowHide()));

	downloadButton = new QPushButton(this);
	downloadButton->setFixedSize(82*WIDTH, 32*HEIGHT);
	downloadButton->setIcon(QIcon("/opt/PDA/app/images/down.png"));//设置退出案件图标
	downloadButton->setIconSize(QSize(82*WIDTH, 32*HEIGHT));
	downloadButton->setDefault(true);

	quitButton = new QPushButton(this);
	quitButton->setFixedSize(82*WIDTH, 32*HEIGHT);
	quitButton->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出案件图标
	quitButton->setIconSize(QSize(82*WIDTH, 32*HEIGHT));
	quitButton->setAutoDefault(false);

	buttonBox = new QDialogButtonBox;//m_pbKey
	buttonBox->addButton(m_pbKey, QDialogButtonBox::ActionRole);
	buttonBox->addButton(downloadButton, QDialogButtonBox::ActionRole);
	buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

	progressDialog = new QProgressDialog(this);

	http = new QHttp(this);

	connect(urlLineEdit, SIGNAL(textChanged()), this,
			SLOT(enableDownloadButton()));
	connect(http, SIGNAL(requestFinished(int, bool)), this,
			SLOT(httpRequestFinished(int, bool)));
	connect(http, SIGNAL(dataReadProgress(int, int)), this,
			SLOT(updateDataReadProgress(int, int)));
	connect(
			http,
			SIGNAL(responseHeaderReceived(const QHttpResponseHeader &)),
			this,
			SLOT(readResponseHeader(const QHttpResponseHeader &)));
	connect(
			http,
			SIGNAL(authenticationRequired(const QString &, quint16, QAuthenticator *)),
			this,
			SLOT(slotAuthenticationRequired(const QString &, quint16, QAuthenticator *)));
#ifndef QT_NO_OPENSSL
	connect(
			http,
			SIGNAL(sslErrors(const QList<QSslError> &)),
			this,
			SLOT(sslErrors(const QList<QSslError> &)));
#endif
	connect(progressDialog, SIGNAL(canceled()), this,
			SLOT(cancelDownload()));
	connect(downloadButton, SIGNAL(clicked()), this, SLOT(downloadFile()));
	connect(quitButton, SIGNAL(clicked()), this, SLOT(pbQuitClicked()));

	QHBoxLayout *topLayout = new QHBoxLayout;
	topLayout->addWidget(urlLabel);
	topLayout->addWidget(urlLineEdit);

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(topLayout);
	mainLayout->addWidget(statusLabel);
	mainLayout->addWidget(buttonBox);
	setLayout(mainLayout);

	setWindowTitle(trUtf8("HTTP下载"));
	urlLineEdit->setFocus();

	m_pbKey->setEnabled(0);
	if (bKeyShow)
	{
		m_pbKey->setEnabled(1);
		connect(m_pbKey, SIGNAL(clicked()), this, SLOT(pbKeyShowHide()));

		im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(false);
	}
}
HttpWindow::~HttpWindow()
{
	delete statusLabel;
	delete urlLabel;
	delete urlLineEdit;
	delete progressDialog;
	delete downloadButton;
	delete quitButton;
	delete buttonBox;

	delete http;
	delete file;
}
void HttpWindow::pbQuitClicked()
{
	g_pDownLoad->close();
}
void HttpWindow::downloadFile()
{
	QUrl url(urlLineEdit->toPlainText());
	QFileInfo fileInfo(url.path());

	QString fileName = fileInfo.fileName();
	if (fileName.isEmpty())
		fileName = "/opt/PDA/lib/index.html";

	//	fileName = "/opt/PDA/download/" + url.path();

	if (QFile::exists(fileName))
	{
		if (QMessageBox::question(this, trUtf8("天嵌HTTP下载"),
				trUtf8("当前目录下已存在文件 %1. 是否覆盖?").arg(fileName),
				QMessageBox::Yes | QMessageBox::No,
				QMessageBox::No) == QMessageBox::No)
			return;
		QFile::remove(fileName);
	}

//	fileName = "/tmp/" + fileName;
//	cout << "filenane->" << fileName.toStdString().c_str() << endl;
	fileName = "/opt/PDA/download/" + url.path();
	file = new QFile(fileName);
	if (!file->open(QIODevice::WriteOnly))
	{
		QMessageBox::information(
				this,
				trUtf8("天嵌HTTP下载"),
				trUtf8("无法保存文件 %1: %2.") .arg(fileName).arg(
						file->errorString()));
		delete file;
		file = 0;
		return;
	}

	QHttp::ConnectionMode
			mode =
					url.scheme().toLower() == "https" ? QHttp::ConnectionModeHttps
							: QHttp::ConnectionModeHttp;
	http->setHost(url.host(), mode, url.port() == -1 ? 0 : url.port());

	if (!url.userName().isEmpty())
		http->setUser(url.userName(), url.password());

	httpRequestAborted = false;
	QByteArray path = QUrl::toPercentEncoding(url.path(), "!$&'()*+,;=:@/");
	if (path.isEmpty())
		path = "/";

	httpGetId = http->get(path, file);

	progressDialog->setWindowTitle(trUtf8("天嵌HTTP下载"));
	progressDialog->setLabelText(trUtf8("下载中 %1.").arg(fileName));
	downloadButton->setEnabled(false);
}

void HttpWindow::cancelDownload()
{
	statusLabel->setText(trUtf8("下载已取消."));
	httpRequestAborted = true;
	http->abort();
	downloadButton->setEnabled(true);
}

void HttpWindow::httpRequestFinished(int requestId, bool error)
{
	if (requestId != httpGetId)
		return;
	if (httpRequestAborted)
	{
		if (file)
		{
			file->close();
			file->remove();
			delete file;
			file = 0;
		}

		progressDialog->hide();
		return;
	}

	if (requestId != httpGetId)
		return;

	progressDialog->hide();
	file->close();

	if (error)
	{
		file->remove();
		QMessageBox::information(this, trUtf8("天嵌HTTP下载"),
				trUtf8("下载失败: %1.") .arg(http->errorString()));
	}
	else
	{
		QString
				fileName =
						QFileInfo(
								QUrl(
										urlLineEdit->toPlainText()).path()).fileName();
		//		statusLabel->setText(
		//				trUtf8("下载 %1 到 /opt/PDA/download下.").arg(fileName));

		QMessageBox warn;
		warn.setWindowTitle(trUtf8("提示"));
		warn.setText(trUtf8("下载到/opt/PDA/download/目录成功"));
		warn.setStandardButtons(QMessageBox::Ok);
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0,
				Qt::AutoColor);
		QIcon icon(pix);
		warn .setWindowIcon(icon);
		warn.exec();
		//
		//		QMessageBox::information(this, trUtf8("天嵌FTP下载"),
		//				tr("There already exists a file called %1 in "
		//					"the current directory.") .arg(fileName));
	}

	downloadButton->setEnabled(true);
	delete file;
	file = 0;
}

void HttpWindow::readResponseHeader(const QHttpResponseHeader &responseHeader)
{
	switch (responseHeader.statusCode())
	{
	case 200: // Ok
	case 301: // Moved Permanently
	case 302: // Found
	case 303: // See Other
	case 307: // Temporary Redirect
		// these are not error conditions
		break;

	default:
		QMessageBox::information(
				this,
				trUtf8("天嵌HTTP下载"),
				trUtf8("下载失败: %1.") .arg(
						responseHeader.reasonPhrase()));
		httpRequestAborted = true;
		progressDialog->hide();
		http->abort();
	}
}

void HttpWindow::updateDataReadProgress(int bytesRead, int totalBytes)
{
	if (httpRequestAborted)
		return;

	progressDialog->setMaximum(totalBytes);
	progressDialog->setValue(bytesRead);
}

void HttpWindow::enableDownloadButton()
{
	downloadButton->setEnabled(!urlLineEdit->toPlainText().isEmpty());
}

void HttpWindow::slotAuthenticationRequired(const QString &hostName, quint16,
		QAuthenticator *authenticator)
{
	QDialog dlg;
	Ui::Dialog ui;
	ui.setupUi(&dlg);
	dlg.adjustSize();
	ui.siteDescription->setText(
			trUtf8("%1 在 %2").arg(authenticator->realm()).arg(
					hostName));

	if (dlg.exec() == QDialog::Accepted)
	{
		authenticator->setUser(ui.userEdit->text());
		authenticator->setPassword(ui.passwordEdit->text());
	}
}
void HttpWindow::pbKeyShowHide()
{
	((TQInputMethod *) im)->setVisible(true);
}
#ifndef QT_NO_OPENSSL
void HttpWindow::sslErrors(const QList<QSslError> &errors)
{
	QString errorString;
	foreach (const QSslError &error, errors)
		{
			if (!errorString.isEmpty())
				errorString += ", ";
			errorString += error.errorString();
		}

	if (QMessageBox::warning(
			this,
			tr("HTTP Example"),
			tr("One or more SSL errors has occurred: %1").arg(
					errorString),
			QMessageBox::Ignore | QMessageBox::Abort)
			== QMessageBox::Ignore)
	{
		http->ignoreSslErrors();
	}
}
#endif
