#include "tqdownload.h"

#include <QtGui>
#include <QApplication>
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	QTextCodec *codec = QTextCodec::codecForName("UTF-8");
	QTextCodec::setCodecForLocale(codec);
	QTextCodec::setCodecForCStrings(codec);
	QTextCodec::setCodecForTr(codec);

	bool bShowKey = false;

	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "EmbedSky") == 0)
		{
			g_pDownLoad = new TQDownLoad(0, 1);
			bShowKey = true;
			break;
		}
	}
	if (!bShowKey)
		g_pDownLoad = new TQDownLoad(0, 0);
	g_pDownLoad->show();
	return a.exec();
}
