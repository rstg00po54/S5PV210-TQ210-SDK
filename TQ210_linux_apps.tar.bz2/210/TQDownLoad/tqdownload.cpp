#include "tqdownload.h"
#include <QApplication>
#include <QDesktopWidget>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QRegExpValidator>
#include <QRegExp>
#include <httpwindow.h>
#include <ftpwindow.h>
#include<QLabel>
#include <iostream>
using namespace std;

TQDownLoad *g_pDownLoad;

TQDownLoad::TQDownLoad(QWidget *parent, bool bKeyShow) :
	QWidget(parent)
{
//	this->setWindowTitle(trUtf8("天嵌科技下载程序V1.0(www.EmbedSky.net)"));
	QRect screen_size = QApplication::desktop()->screenGeometry();
	this->setGeometry(0, 0, screen_size.width(), screen_size.height());
	//setGeometry(0, 0, 480, 272);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

//	QLabel *labelTitle = new QLabel(trUtf8("天嵌科技网络下载程序"), this);
/*	QHBoxLayout *titleLayout = new QHBoxLayout;
	titleLayout->addStretch(33);
	titleLayout->addWidget(labelTitle);
	titleLayout->addStretch(33);*/

	m_pTabWidget = new QTabWidget(this);
	m_pTabWidget->setGeometry(0, 0, screen_size.width(), screen_size.height());
	if (bKeyShow)
	{
		m_pTabWidget->addTab(new FtpWindow(this,bKeyShow), trUtf8("FTP下载"));
		m_pTabWidget->addTab(new HttpWindow(this,bKeyShow), trUtf8("HTTP下载"));
	}
	else
	{
		m_pTabWidget->addTab(new FtpWindow(this), trUtf8("FTP下载"));
		m_pTabWidget->addTab(new HttpWindow, trUtf8("HTTP下载"));
	}

	QVBoxLayout *mainLayout = new QVBoxLayout;
//	mainLayout->addLayout(titleLayout);
	mainLayout->addWidget(m_pTabWidget);
	this->setLayout(mainLayout);

	/*m_pbCancel = new QPushButton(trUtf8("关闭"));
	 m_pbCancel->setMaximumWidth(100);
	 connect(m_pbCancel, SIGNAL(clicked()), this, SLOT(close()));*/

}

TQDownLoad::~TQDownLoad()
{
	delete m_pTabWidget;
}

