#ifndef TQDOWNLOAD_H
#define TQDOWNLOAD_H

#include <QtGui/QWidget>
#include <QPushButton>
#include <QMessageBox>
#include <QTabWidget>
#include <QFtp>

class TQDownLoad: public QWidget
{
Q_OBJECT

public:
	TQDownLoad(QWidget *parent = 0,bool bKeyShow=0);
	~TQDownLoad();

private:
	QPushButton *m_pbCancel;
	QTabWidget *m_pTabWidget;


};
extern TQDownLoad *g_pDownLoad;
#endif // TQDOWNLOAD_H
