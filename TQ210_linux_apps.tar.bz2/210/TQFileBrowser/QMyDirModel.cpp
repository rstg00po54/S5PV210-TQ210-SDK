/*
 * QMyDirModel.cpp
 *
 *  Created on: May 7, 2011
 *      Author: root
 */

#include "QMyDirModel.h"

QMyDirModel::QMyDirModel():QDirModel()
{
	// TODO Auto-generated constructor stub

}

QMyDirModel::~QMyDirModel()
{
	// TODO Auto-generated destructor stub
}
QVariant QMyDirModel::headerData(int section, Qt::Orientation orientation, int role) const
    {
        if (orientation == Qt::Horizontal) {
            if (role != Qt::DisplayRole)
                return QVariant();
            switch (section) {
            case 0: return trUtf8("名字");
            case 1: return trUtf8("大小");
            case 2: return trUtf8("类型");
    #ifdef Q_OS_MAC
            trUtf8("Kind", "Match OS X Finder");
    #else
            trUtf8("Type", "All other platforms");
    #endif
            // Windows   - Type
            // OS X      - Kind
            // Konqueror - File Type
            // Nautilus  - Type
            case 3: return trUtf8("修改时间");
            default: return QVariant();
            }
        }
        return QAbstractItemModel::headerData(section, orientation, role);
    }
