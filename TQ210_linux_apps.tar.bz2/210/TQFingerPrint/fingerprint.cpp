/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		指纹模块
 *    文件名:     	fingerprint.cpp
 *    文件描述:  		主界面
 *    创建日期:      2011-06-28
 *    创 建 人:      gxx
 *    文档:
 *    数据库："/opt/PDA/src/fingerdata.db"
 *    运行平台:      linux
 *    其他:             无
 */

#include "fingerprint.h"
#include <QMessageBox>
#include <QUrl>
#include <QImage>
#include <QPixmap>
#include <QBitmap>
#include<stdio.h>
#include<stdlib.h>
#include <QFile>
#include <QVBoxLayout>
#include<QHBoxLayout>
#include <QGridLayout>
#include <iostream>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QtSql>
#include <QDateTime>
#include <iostream>
using namespace std;
FingerModule *g_pCom;//指纹模块
FingerPrint *g_pFingerPrint;
int gpImageWidth[6] =
{ 304, 280, 256, 256, 196, 160 };//指纹图片大小判断
int gpImageHeight[6] =
{ 304, 280, 280, 256, 196, 208 };//
#define IMAGE_WIDTH		304//默认304长
#define IMAGE_HEIGHT	304
char gpImage[304 * 304];//指纹图片信息数组

char cNum;//加入新指纹，默认id号自动加1，先读取已经存在的指纹数量明
char cNumHigh, cNumlow;//发送命令，指纹id号高8位，低8位
bool bEnroll;

char m_CComPack[8];//指纹指令
enum QImage::Format format;//显示图片格式
char cData[9900];
QSqlDatabase g_Sql;//声明一个数据库全局变量,db

QString FingerPrint::m_tReturnCode[][2] =
{
{ "01", "第一次录入失败" },
{ "02", "第一次录入失败" },
{ "03", "录入失败，请重新发送命令" },
{ "05", "删除用户信息失败" },
{ "09", "取用户总数失败" },
{ "24", "采集显示图片失败" } };

FingerPrint::FingerPrint(QWidget *parent) :
	QWidget(parent)
{
	ui.setupUi(this);
	this->setWindowTitle(trUtf8("﻿指纹通信设置"));

	QLabel *lab_Title = new QLabel(trUtf8("指纹应用程序"), this);

	g_Sql = QSqlDatabase::addDatabase("QSQLITE");
	g_Sql.setDatabaseName("/opt/PDA/lib/data/fingerdata.db");

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");//设置背景
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	m_pbGetCout = new QPushButton(this);
	m_pbGetCout->setFixedSize(82, 32);
	m_pbGetCout->setIcon(QIcon("/opt/PDA/app/images/getNum.png"));//设置获取用户总数图标
	m_pbGetCout->setIconSize(QSize(82, 32));

	m_pbEnroll = new QPushButton(this);
	m_pbEnroll->setFixedSize(82, 32);
	m_pbEnroll->setIcon(QIcon("/opt/PDA/app/images/enroll.png"));//设置指纹录入图标
	m_pbEnroll->setIconSize(QSize(82, 32));

	m_pbDeleteAll = new QPushButton(this);
	m_pbDeleteAll->setFixedSize(82, 32);
	m_pbDeleteAll->setIcon(QIcon("/opt/PDA/app/images/deleteAllFinger.png"));//设置删除所有用户图标
	m_pbDeleteAll->setIconSize(QSize(82, 32));

	m_pbScall = new QPushButton(this);
	m_pbScall->setFixedSize(82, 32);
	m_pbScall->setIcon(QIcon("/opt/PDA/app/images/scan.png"));//设置扫描指纹图标
	m_pbScall->setIconSize(QSize(82, 32));

	//m_pbImport = new QPushButton(this);
	//m_pbImport->setFixedSize(82, 32);
	//m_pbImport->setIcon(QIcon("/opt/PDA/app/images/importUserInfo.png"));//设置退出案件图标
	//m_pbImport->setIconSize(QSize(82, 32));

	//keyboard = new KeyBoard(this);

	m_pbExit = new QPushButton(this);
	m_pbExit->setFixedSize(82, 32);
	m_pbExit->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出案件图标
	m_pbExit->setIconSize(QSize(82, 32));



	m_labRetValue = new QLabel(trUtf8("数\n据\n分\n析"), this);
	m_teInfo = new MyTextEdit(this);
	m_teInfo->setFixedSize(222, 88);

	m_lbImage = new QLabel(trUtf8("    指纹图片"), this);
	m_lbImage->setFrameShape(QFrame::Box);
	m_lbImage->setFixedSize(88, 88);

	QHBoxLayout *hHeadLayout = new QHBoxLayout;
	hHeadLayout->addWidget(m_pbGetCout);
	hHeadLayout->addWidget(m_pbEnroll);
	hHeadLayout->addWidget(m_pbDeleteAll);
	hHeadLayout->addWidget(m_pbScall);
	hHeadLayout->addWidget(m_pbExit);



	connect(m_pbGetCout, SIGNAL(clicked()), this, SLOT(m_pbGetCoutClicked()));
	connect(m_pbEnroll, SIGNAL(clicked()), this, SLOT(m_pbEnrollClicked()));
	connect(m_pbDeleteAll, SIGNAL(clicked()), this,SLOT(m_pbDeleteAllClicked()));
	connect(m_pbScall, SIGNAL(clicked()), this, SLOT(m_pbScallClicked()));
	connect(m_pbExit, SIGNAL(clicked()), this, SLOT(close()));

	/*m_pbGetValue = new QPushButton(trUtf8("采集特征值"), this);//
	 m_pbGetValue->setMaximumWidth(88);
	 m_pbImportIDInfo = new QPushButton(trUtf8("导入特征值"), this);
	 m_pbImportIDInfo->setMaximumWidth(88);*/



	//connect(m_pbImport, SIGNAL(clicked()), this, SLOT(pbImportClicked()));//
	/*	connect(m_pbGetValue, SIGNAL(clicked()), this, SLOT(m_pbGetValueClicked()));//
	 connect(m_pbImportIDInfo, SIGNAL(clicked()), this,
	 SLOT(m_pbImportIDValue()));*/


	//QHBoxLayout *hMideleLayout = new QHBoxLayout();
	//hMideleLayout->addWidget(m_pbImport);
	//	hMideleLayout->addWidget(m_pbGetValue);
	//	hMideleLayout->addWidget(m_pbImportIDInfo);
	//hMideleLayout->addWidget(m_pbExit);

	//QVBoxLayout *midLayout = new QVBoxLayout;
	//midLayout->addLayout(hHeadLayout);
	//midLayout->addLayout(hMideleLayout);

	m_gbOperSelect = new QGroupBox(this);
	m_gbOperSelect->setLayout(hHeadLayout);

	QHBoxLayout *hRetLayout = new QHBoxLayout;
	hRetLayout->addWidget(m_labRetValue);
	hRetLayout->addWidget(m_teInfo);
	hRetLayout->addSpacing(33);
	hRetLayout->addWidget(m_lbImage);




	QHBoxLayout *titleLayout = new QHBoxLayout;
	titleLayout->addStretch(33);
	titleLayout->addWidget(lab_Title);
	titleLayout->addStretch(33);

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addLayout(titleLayout);
	mainLayout->addWidget(m_gbOperSelect);
	mainLayout->addLayout(hRetLayout);

	this->setLayout(mainLayout);

	g_pCom = FingerModule::getInstance(FingerModule::MODULE2, "/dev/ttySAC2");
	if (!g_pCom->IsOpen())
	{
		if (!g_pCom->openDevice())
		{
			QMessageBox::warning(this, trUtf8("信息"), trUtf8("串口打开失败！"),
					QMessageBox::Ok);
		}
	}
}
FingerPrint::~FingerPrint()
{
	m_pTimer->stop();
	g_Sql.close();
}
//取用户总数
void FingerPrint::m_pbGetCoutClicked()
{
	m_teInfo->clear();
	m_teInfo->setText(trUtf8("正在读取用户总数，请稍后"));
	m_lbImage->clear();//关掉图片
	m_CComPack[1] = 0x09;//命令码
	m_CComPack[6] = 0x09;//校验码
	pbSendClicked();
}
//导入新指纹信息
void FingerPrint::m_pbEnrollClicked()
{
	bEnroll = 1;
	m_teInfo->clear();
	m_teInfo->setText(trUtf8("正在导入指纹信息，请稍后"));
	m_lbImage->clear();
	m_CComPack[1] = 0x09;
	m_CComPack[6] = 0x09;
	pbSendClicked();
}
//删除所有指纹信息
void FingerPrint::m_pbDeleteAllClicked()
{
	m_teInfo->clear();
	m_teInfo->setText(trUtf8("正在删除所有指纹信息，请稍后"));
	m_lbImage->clear();
	m_CComPack[1] = 0x05;
	m_CComPack[6] = 0x05;
	pbSendClicked();
}
//扫描指纹
void FingerPrint::m_pbScallClicked()
{
	m_teInfo->clear();
	m_teInfo->setText(trUtf8("正在扫描对比，请稍后"));
	m_lbImage->clear();
	m_CComPack[1] = 0x0c;
	m_CComPack[6] = 0x0c;
	pbSendClicked();
}
//采集特征值
/*void FingerPrint::m_pbGetValueClicked()
 {
 m_teInfo->setText(trUtf8("采集特征值，请稍后"));
 m_lbImage->clear();

 m_CComPack[0] = 0xf5;
 m_CComPack[1] = 0x09;//命令码
 m_CComPack[2] = 0x00;
 m_CComPack[3] = 0x00;
 m_CComPack[4] = 0x00;
 m_CComPack[5] = 0x00;
 m_CComPack[6] = 0x09;//校验码
 m_CComPack[7] = 0xf5;
 g_pCom->sendMsg(m_CComPack, sizeof(m_CComPack));// 发送命令
 sleep(1);
 if (g_pCom->IsOpen())// 如果串口打开
 {
 int iLen = g_pCom->readMsg(cData, sizeof(cData));// 读串口数据
 if ((iLen > 0) && ((cData[1] ^ cData[2] ^ cData[3] ^ cData[4]
 ^ cData[5]) == cData[6]) && (cData[4] == 0x00))
 {
 cNum = cData[2] * 256 + cData[3];
 m_CComPack[0] = 0xf5;
 m_CComPack[1] = 0x31;
 m_CComPack[4] = 0x00;
 m_CComPack[5] = 0x00;
 QFile file("/opt/qt-4.5/src/id_value.txt");
 if (!file.open(QIODevice::ReadWrite))
 return;
 for (int i = 1; i <= cNum; i++)
 {
 m_CComPack[2] = i / 256;
 m_CComPack[3] = i % 256;
 m_CComPack[6] = getCheckSum(m_CComPack, 1, 5);
 m_CComPack[7] = 0xf5;
 g_pCom->sendMsg(m_CComPack, sizeof(m_CComPack));// 发送命令
 sleep(1);
 if (g_pCom->IsOpen())// 如果串口打开
 {
 int iLen = g_pCom->readMsg(cData, sizeof(cData));// 读串口数据
 cout << "iLen" << iLen << endl;
 if ((iLen > 0) && ((cData[1] ^ cData[2] ^ cData[3]
 ^ cData[4] ^ cData[5]) == cData[6]) && (cData[4]
 == 0x00))
 {
 char cDataValue[193];
 memcpy(cDataValue, cData + 12, 193);
 //		for (int i = 0; i < 193; i++)
 //			printf("%02x\n", cDataValue[i]);
 char aa[386];
 ByteToStr((unsigned char *) cDataValue, aa,
 sizeof(cDataValue));

 char abc[4];
 char cNumValue[1];
 cNumValue[0] = (char) i;
 ByteToStr((unsigned char *) cNumValue, abc,
 sizeof(cNumValue));
 file.write("ID:");
 file.write("\n");
 file.write(abc);
 file.write("\n");
 file.write(aa);
 file.write("\n");
 }
 }
 }
 m_teInfo->setText(trUtf8("采集成功"));
 }
 }
 }*/
/*void FingerPrint::m_pbImportIDValue()
 {
 QFile file("/opt/PDA/bin/fingerprint_file/id_value.txt");
 if (!file.open(QIODevice::ReadWrite))
 return;
 QString str_Num;
 QString str_info;
 QByteArray line;
 while (!file.atEnd())
 {
 line = file.readLine();
 if (line.at(0) == 'I')
 {
 line = file.readLine();
 str_Num = line.data();
 line = file.readLine();
 str_info = line.data();
 cout << endl << "str_info:" << str_info.toStdString().c_str()
 << endl;
 ///////////////////////////////////
 m_CComPack[0] = 0xf5;
 m_CComPack[1] = 0x41;
 m_CComPack[2] = 0x00;
 m_CComPack[3] = 196;
 m_CComPack[4] = 0x00;
 m_CComPack[5] = 0x00;
 m_CComPack[6] = getCheckSum(m_CComPack, 1, 5);
 m_CComPack[7] = 0xf5;

 char *p_num = str_Num.toLocal8Bit().data();
 char *p_info = str_info.toLocal8Bit().data();
 printf("\n000:\n");
 printf("%s\n", p_info);
 char hexNum[2], hexValue[193];
 int ii = str2Hex((unsigned char *) p_num, (unsigned char *) hexNum,
 16);
 ii = str2Hex((unsigned char *) p_info, (unsigned char *) hexValue,
 386);

 printf("\n234a\n");
 for (int i = 0; i < 193; i++)
 printf("%02x", hexValue[i]);
 printf("\n234a\n");

 char m_CComPackData[199];
 m_CComPackData[0] = 0xf5;
 //	m_CComPackData[1] =hexNum[0]/256;
 //	m_CComPackData[2] =hexNum[0]%256;
 m_CComPackData[1] = hexNum[1];
 m_CComPackData[2] = hexNum[0];
 m_CComPackData[3] = 0x01;
 for (int i = 0; i < 193; i++)
 m_CComPackData[i + 4] = hexValue[i];
 m_CComPackData[197] = getCheckSum(m_CComPackData, 1, 196);
 m_CComPackData[198] = 0xf5;

 g_pCom->sendMsg(m_CComPack, sizeof(m_CComPack));// 发送命令
 g_pCom->sendMsg(m_CComPackData, sizeof(m_CComPackData));// 发送命令
 sleep(1);
 if (g_pCom->IsOpen())// 如果串口打开
 {
 int iLen = g_pCom->readMsg(cData, sizeof(cData));// 读串口数据
 cout << "iLen=" << iLen << endl;
 if ((iLen > 0) && ((cData[1] ^ cData[2] ^ cData[3] ^ cData[4]
 ^ cData[5]) == cData[6]))
 {
 printf("aaaaaaaaa=%d\n", cData[4]);
 }
 }
 }
 }
 }*/

//导入用户信息
void FingerPrint::FingerPrint::pbImportClicked()
{
	FileView *fileview = new FileView();
//	fileview->move(0, -33);
	fileview->showFullScreen();
}

//软键盘
/*void FingerPrint::pbKeyBoard()
 {
 KeyBoard *keyboard = new KeyBoard();
 keyboard->show();
 keyboard->move(33, 33);
 }*/
//发送
void FingerPrint::pbSendClicked()
{
	//cout<<"pbSendClicked..start"<<endl;
	m_CComPack[0] = 0xf5;
	m_CComPack[2] = 0x00;
	m_CComPack[3] = 0x00;
	m_CComPack[4] = 0x00;
	m_CComPack[5] = 0x00;
	m_CComPack[7] = 0xf5;
	g_pCom->sendMsg(m_CComPack, sizeof(m_CComPack));// 发送命令 
	if (m_CComPack[1] == 0x23)
		sleep(1);
	if (g_pCom->IsOpen())// 如果串口打开
	{
		//cout<<"com...open!"<<endl;
		int iLen = g_pCom->readMsg(cData, sizeof(cData));// 读串口数据
		//cout << "iLen = " << iLen << endl;
		//cout << "cData = " << cData << endl;
		while ((m_CComPack[1] == 0x0c) && (iLen == 0))
		{

			iLen = g_pCom->readMsg(cData, sizeof(cData));// 读串口数据

			//cout << "iLen = " << iLen << endl;
			//cout << "cData = " << cData << endl;
		}

	//	cout << "read...data" << endl;

		if ((iLen > 0) && ((cData[1] ^ cData[2] ^ cData[3] ^ cData[4]
				^ cData[5]) == cData[6]))
		{
		//	cout << "check...right" << endl;
			if ((cData[4] == 0x01) && (cData[1] != 0x0c))
			{
				QString str_tem = QString("%1").arg((int) cData[1]);
				QString str_Error = getErrorMeaning(str_tem);
				m_teInfo->setText(str_Error);
			}
			else
			{
				if (cData[1] == 0x0c)//扫描指纹命令
				{
					if (cData[4] == 0x05)
						m_teInfo->setText(trUtf8("无此用户"));
					else if (cData[4] == 0x08)
						m_teInfo->setText(trUtf8("获取用户ID失败，请重新发送命令"));
					else
					{

						int iNum = (int) (cData[2] * 256 + cData[3]);
						QString str_IDNum = QString("%1").arg(iNum);
						m_teInfo ->setText(trUtf8("该用户ID为：") + str_IDNum);

						if (!g_Sql.open())
						{
							QMessageBox::critical(NULL,
									QObject::tr("无法打开数据库\n"),
									QObject::tr("退出清按Cancel键"),
									QMessageBox::Cancel, QMessageBox::NoButton);
						}

						QSqlQuery query("SELECT * FROM finger");

						while (query.next())
						{
							QString str_id = query.value(0).toString();
							QString str_name = query.value(1).toString();
							QString str_privilege = query.value(2).toString();
							QString str_department = query.value(3).toString();
							QString str_intro = query.value(4).toString();

							if (str_id == str_IDNum)
							{
								//cout << str_id.toStdString().c_str() << endl;
								//cout << str_name.toStdString().c_str() << endl;
								m_teInfo ->setText(
										m_teInfo->toPlainText() + "\n名字："
												+ str_name + "\n权限:"
												+ str_privilege + "\n部门:"
												+ str_department + "\n介绍："
												+ str_intro);
							}
						}
					}// 权限:"+str_privilege+"\n部门"+str_department
					//ShowImage();//比对，显示图片
					return;
				}

				if ((bEnroll == 0) && (cData[4] == 0x00) && (cData[1] == 0x09))
				{
					int iNum = (int) (cData[2] * 256 + cData[3]);//取已经存在的用户总数
					QString str_tem;//临时字符串
					str_tem = QString("%1").arg(iNum);//
					m_teInfo->setText(trUtf8("用户总数为：") + (str_tem));//显示提示信息
				}
				else if ((bEnroll == 1) && (cData[4] == 0x00) && (cData[1]
						== 0x09))//录入指纹信息
				{
					cNum = cData[2] * 256 + cData[3];
					cNum++;
					cNumHigh = cNum / 256;
					cNumlow = cNum % 256;
					//printf("%d", cNum);
					//printf("\n");

					m_CComPack[0] = 0xf5;
					m_CComPack[1] = 0x01;
					m_CComPack[2] = cNumHigh;
					m_CComPack[3] = cNumlow;
					m_CComPack[4] = 0x01;
					m_CComPack[6] = m_CComPack[1] ^ m_CComPack[2]
							^ m_CComPack[3] ^ m_CComPack[4] ^ m_CComPack[5];//校验
					g_pCom->sendMsg(m_CComPack, sizeof(m_CComPack));//发送
					int iLen = g_pCom->readMsg(cData, sizeof(cData));

					m_CComPack[0] = 0xf5;
					m_CComPack[1] = 0x02;//第二次录入指纹，
					m_CComPack[6] = m_CComPack[1] ^ m_CComPack[2]
							^ m_CComPack[3] ^ m_CComPack[4] ^ m_CComPack[5];
					g_pCom->sendMsg(m_CComPack, sizeof(m_CComPack));
					iLen = g_pCom->readMsg(cData, sizeof(cData));

					m_CComPack[0] = 0xf5;
					m_CComPack[1] = 0x03;
					m_CComPack[6] = m_CComPack[1] ^ m_CComPack[2]
							^ m_CComPack[3] ^ m_CComPack[4] ^ m_CComPack[5];
					g_pCom->sendMsg(m_CComPack, sizeof(m_CComPack));
					sleep(1);

					char cData[9900];
					if (g_pCom->IsOpen())
					{
						iLen = g_pCom->readMsg(cData, sizeof(cData));
						if (iLen > 0)
						{
							if ((cData[1] == 0x03) && (cData[4] == 0x00))
							{
								//		 int iNum = (int) cNum;
								QString str_tem = QString("%1").arg((int) cNum);
								m_teInfo ->setText(
										trUtf8("录入成功") + "\n" + trUtf8("ID号为：")
												+ str_tem);

								if (!g_Sql.open())// 如果数据库已打开

								{
									QMessageBox::critical(NULL,
											QObject::tr("无法打开数据库\n"),
											QObject::tr("退出清按Cancel键"),
											QMessageBox::Cancel,
											QMessageBox::NoButton);
								}
								QSqlQuery query("SELECT * FROM finger");//搜索全部数据
								while (query.next())
								{
									QString str_id = query.value(0).toString();//数据库中用户id号
									QString str_name =
											query.value(1).toString();//数据库中用户名字号
									QString str_privilege =
											query.value(2).toString();//数据库中用户名字号
									QString str_department =
											query.value(3).toString();//数据库中用户名字号
									QString str_intro =
											query.value(4).toString();//数据库中用户介绍号
									if (str_id == str_tem)//如果在数据库搜索到但前用户id号

									{
										//cout << str_id.toStdString().c_str()
											//	<< endl;
										//cout << str_name.toStdString().c_str()
										//		<< endl;
										m_teInfo ->setText(
												m_teInfo->toPlainText()
														+ "\n名字：" + str_name
														+ "\n权限:" + str_privilege
														+ "\n部门:"
														+ str_department
														+ "\n介绍：" + str_intro);
									}
								}
							}
							else if ((cData[1] == 0x03) && (cData[4] == 0x08))
								m_teInfo->setText(trUtf8("采集超时，请重新发送命令"));
							else if ((cData[1] == 0x03) && (cData[4] == 0x04))
								m_teInfo->setText(trUtf8("数据库已满，请先删除用户再导入"));
						}
					}
					ShowImage();//指纹录入时显示图片
					bEnroll = 0;
				}
				if (cData[1] == 0x05)
				{
					if (cData[4] == 0x00) //删除所有用户命令
						m_teInfo->setText(trUtf8("删除所有用户成功"));
					else if (cData[4] == 0x01)
						m_teInfo->setText(trUtf8("删除所有用户失败，请重新发送命令"));
				}
				/*else if (cData[1] == 0x24)//采集指纹显示返回值，没有单独显示图片功能，屏蔽掉了
				 {
				 ShowImage();
				 }*/
			}
		}
	}
}
//字符转Hex
int FingerPrint::str2Hex(unsigned char *buf, unsigned char *hex, int sLen)
{
	unsigned char tHex = 0x00;
	unsigned char *tBuf = (unsigned char *) malloc(sizeof(unsigned char) * 8);
	memset(tBuf, '\0', 8);
	int i = 0;
	for (i = 0; i < sLen; i += 2)
	{
		memcpy(tBuf, &buf[i], 2);
		tHex = (unsigned char) strtol((char *) tBuf, NULL, 16);
		hex[i / 2] = tHex;
	}
	return sLen / 2;
}
char *FingerPrint::ByteToStr(const unsigned char *pIn, char *pOut, int len)
{
	char *pstr = pOut;
	unsigned char *p = (unsigned char *) pIn;

	int i = 0;
	for (i = 0; i < len; i++, pstr += 2)
		sprintf(pstr, "%02x ", *p++);

	return pOut;
}
//显示指纹图片操作
void FingerPrint::ShowImage()
{
	//命令
	m_CComPack[0] = 0xf5;
	m_CComPack[1] = 0x24;
	m_CComPack[2] = 0x00;
	m_CComPack[3] = 0x00;
	m_CComPack[4] = 0x00;
	m_CComPack[5] = 0x00;
	m_CComPack[6] = 0x24;
	m_CComPack[7] = 0xf5;
	g_pCom->sendMsg(m_CComPack, sizeof(m_CComPack));

	if (g_pCom->IsOpen())//
	{
		int iLen = g_pCom->readMsg(cData, sizeof(cData));
		if (iLen > 0)
		{
			int IndxSrc = 9;
			int IndxDest = 0;
			int img_size;
			int cnt;
			img_size = cData[2] * 256 + cData[3];
			memset(gpImage, 0, IMAGE_WIDTH * IMAGE_HEIGHT);
			//处理返回图片信息，能直接显示bmp格式
			for (cnt = 0; cnt < 6; cnt++)
			{
				if (img_size * 8 == gpImageWidth[cnt] * gpImageHeight[cnt])
				{
					//			cout << "gImagewidth" << gpImageWidth[cnt] << endl;
					for (int i = ((IMAGE_HEIGHT - gpImageHeight[cnt]) / 4); i
							< (gpImageHeight[cnt] / 2) + ((IMAGE_HEIGHT
									- gpImageHeight[cnt]) / 4); i++)
					{
						IndxDest = i * (IMAGE_WIDTH / 2) + (IMAGE_WIDTH
								- gpImageWidth[cnt]) / 4;
						for (int j = ((IMAGE_WIDTH - gpImageWidth[cnt]) / 4)
								/ 2; j < ((gpImageWidth[cnt] / 2)
								+ ((IMAGE_WIDTH - gpImageWidth[cnt]) / 4)) / 2; j++)
						{
							gpImage[IndxDest++] = cData[IndxSrc] & 0xF0;
							gpImage[IndxDest++] = (cData[IndxSrc++] << 4)
									& 0xF0;
						}
					}
					break;
				}
			}
			if (img_size == 80 * 80)
			{
				for (int i = 0; i < 80; i++)
				{
					IndxDest = (80 + i) * 240 + 80;
					for (int j = 0; j < 80; j++)
					{
						gpImage[IndxDest++] = cData[IndxSrc++];
					}
				}
				format = QImage::Format_RGB16;
				QImage image((uchar *) gpImage, 240, 240, format);
				QPixmap pixmap;
				pixmap = pixmap.fromImage(image);
				m_lbImage->setPixmap(pixmap);
			}
			else
			{
				format = QImage::Format_RGB444;//图片格式
				QImage image((uchar *) gpImage, 304 / 4, 304 / 2, format);
				QPixmap pixmap;
				pixmap = pixmap.fromImage(image);//
				pixmap = pixmap.scaled(88, 88, Qt::IgnoreAspectRatio);//图片大小
				m_lbImage->setPixmap(pixmap);//显示
			}
		}
	}
}
QString FingerPrint::getErrorMeaning(QString cCode)
{
	for (int i = 0; i < 15; i++)
	{
		if (m_tReturnCode[i][0].compare(cCode, Qt::CaseInsensitive) == 0)
			return m_tReturnCode[i][1];
	}
	return "未知错误码";
}
char FingerPrint::getCheckSum(char *cData, int iStart, int ilen)
{
	char cCheck = 0x00;
	for (int i = iStart; i < ilen + iStart; i++)
	{
		cCheck ^= cData[i];
	}
	return cCheck;
}
