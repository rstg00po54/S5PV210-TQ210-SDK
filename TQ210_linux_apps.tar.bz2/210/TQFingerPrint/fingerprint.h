#ifndef COMDEBUGGER_H
#define COMDEBUGGER_H

#include <QtGui/QWidget>
//#include "src/MsgQueue/uMsgQueue.h"
#include "ui_fingerprint.h"
#include <QTimer>
#include <QKeyEvent>
#include "src/armapi/posix_qextserialport.h"
#include "src/widget/MyTextEdit.h"
#include "src/widget/KeyBoard.h"
#include "src/widget/FileView.h"
#include"src/FingerModel/FingerModule.h"
#include <QStatusBar>
#include <QCheckBox>
#include <QLabel>
#include <QRadioButton>
#include <QGroupBox>
#include<QPushButton>
#include <QLineEdit>
#include <QComboBox>

struct SendData
{
	char cHead;//命令头一般是0xf5
	char cCmd;//命令
	char cPara1;//参数1
	char cPara2;//数据2
	char cPara3;//数据3
	char cEmpty;//
	char cCheck;//校验
	char cLast;
};

class FingerPrint: public QWidget
{
Q_OBJECT

public:
	FingerPrint(QWidget *parent = 0);
	~FingerPrint();


QString getErrorMeaning(QString);
char getCheckSum(char *cData, int iStart,int ilen);
public slots:
//	void ShowComMsg();

	//	void pbKeyBoard();
	void pbImportClicked();//导入用户信息

	void m_pbGetCoutClicked();//查询用户总数
	void m_pbEnrollClicked();//加入新指纹
	void m_pbDeleteAllClicked();//删除所有指纹
	void m_pbScallClicked();//扫描指纹
//	void m_pbGetValueClicked();
//	void m_pbImportIDValue();

private:
	Ui::ComDebuggerClass ui;
	QTimer *m_pTimer;//串口读取定时器

	static QString m_tReturnCode[][2];//返回信息提示

	QGroupBox *m_gbOperSelect;//基本操作groupbox
	QGroupBox *m_gbSend;//

	QPushButton *m_pbGetCout;//取用户总数按键
	QPushButton *m_pbEnroll;//导入
	QPushButton *m_pbDeleteAll;//删除所有
	QPushButton *m_pbScall;//扫描

	QPushButton *m_pbImport;//导入
//	QPushButton *m_pbGetValue;
//	QPushButton *m_pbImportIDInfo;//导入特征值
	QPushButton *m_pbExit;//退出
	QPushButton *m_pbKeyBoard;//阮键盘

	QLabel *m_labRetValue;//
	QLabel *m_lbImage;//

	MyTextEdit *m_teInfo;//提示信息

	//	KeyBoard *keyboard;
	FileView *fileview;//导入信息文档浏览窗口

	SendData sendData;//发送数据

	void pbSendClicked();//发送命令
	void ShowImage();//显示指纹图片
	QString getErrorMeaning(char);//错误信息

	int str2Hex(unsigned char *buf, unsigned char *hex, int sLen);//
	char *ByteToStr(const unsigned char *pIn, char *pOut, int len);//
};
extern FingerPrint *g_pFingerPrint;
extern FingerModule *g_pCom;
#endif // COMDEBUGGER_H
