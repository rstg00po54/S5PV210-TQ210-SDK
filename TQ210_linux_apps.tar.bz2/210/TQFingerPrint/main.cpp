/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		指纹模块
 *    文件名:     	main.cpp
 *    文件描述:  		主界面
 *    创建日期:      2011-06-28
 *    创 建 人:      gxx
 *    文档:
 *    数据库：  fingerpint.cpp和fileview.cpp 都要更改数据库路径
 *    运行平台:      linux
 *    其他:             无
 */

#include "fingerprint.h"

#include <QtGui>
#include <QApplication>
#include "src/armapi/uArm.h"
//#include "src/MsgQueue/uMsgQueue.h"

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));

	g_pFingerPrint = new FingerPrint();

	QRect screen_size = QApplication::desktop()->screenGeometry();
	g_pFingerPrint->setGeometry(0, 0, screen_size.width(), screen_size.height());

	g_pFingerPrint->show();

	return a.exec();
}
