/*
 * FingerModule.cpp
 *
 *  Created on: Jun 18, 2011
 *      Author: root
 */

#include "FingerModule.h"
#include "FingerModule2.h"
#include "FingerModule3.h"
FingerModule *FingerModule::getInstance(int type, QString name)
{
	if (type == MODULE2)
		return new FingerModule2(name);
	else if (type == MODULE3)
		return new FingerModule3(name);
	else
		return NULL;
}
FingerModule::FingerModule(QString name)
{
	// TODO Auto-generated constructor stub
	m_pSerial = new Posix_QextSerialPort(name, QextSerialBase::Polling);
}

FingerModule::~FingerModule()
{
	// TODO Auto-generated destructor stub
}
bool FingerModule::IsOpen()
{
	return m_pSerial->isOpen();
}
