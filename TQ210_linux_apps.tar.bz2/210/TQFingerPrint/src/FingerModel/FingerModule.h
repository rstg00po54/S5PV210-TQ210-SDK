/*
 * FingerModule.h
 *
 *  Created on: Jun 18, 2011
 *      Author: root
 */

#ifndef FINGERMODULE_H_
#define FINGERMODULE_H_

#include "src/armapi/posix_qextserialport.h"
#include <iostream>
using namespace std;

class FingerModule
{
public:
	FingerModule(QString name);
	virtual ~FingerModule();
	static FingerModule *getInstance(int type, QString name);
	enum MODUEL
	{
		MODULE3 = 0, MODULE2 = 1
	};
	enum SENDSTATUS
	{
		SENDSUCCESS = 0,
		SENDFAIL = 1,
		ENCVSUCCESS = 2,
		RECVFIAL = 3,
		UNKNOWN = 4
	};
	Posix_QextSerialPort *m_pSerial;
	QMutex m_Mutex;
	virtual bool openDevice() = 0;
	virtual bool closeDevice() = 0;
	virtual bool sendMsg(char *msg, int len) = 0;
	virtual char readMsg(char *msg, int len) = 0;
	bool IsOpen();
};

#endif /* FINGERMODULE_H_ */
