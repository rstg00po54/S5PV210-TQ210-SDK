/*
 * FingerModule2.cpp
 *
 *  Created on: Jun 18, 2011
 *      Author: root
 */

#include "FingerModule2.h"

FingerModule2::FingerModule2(QString name) :
	FingerModule(name)
{
	// TODO Auto-generated constructor stub

}

FingerModule2::~FingerModule2()
{
	// TODO Auto-generated destructor stub
}

bool FingerModule2::openDevice()
{
	if (m_pSerial->open(QIODevice::ReadWrite))
	{
		m_pSerial->setBaudRate(BAUD19200);
		m_pSerial->setDataBits(DATA_8);
		m_pSerial->setParity(PAR_NONE);
		m_pSerial->setStopBits(STOP_1);
		m_pSerial->setFlowControl(FLOW_OFF);
		m_pSerial->setTimeout(500);
	}
	else
	{
		return false;
	}
	return true;
}

bool FingerModule2::sendMsg(char *msg, int len)
{
	bool bOK = false;
	if (m_Mutex.tryLock(1000))
	{
		bOK = m_pSerial->write(msg, len) == len ? true : false;
		m_Mutex.unlock();
	}
	return bOK;
}
char FingerModule2::readMsg(char *msg, int len)
{
	return m_pSerial->read(msg,len);
}
bool FingerModule2::closeDevice()
{
	return true;
}
