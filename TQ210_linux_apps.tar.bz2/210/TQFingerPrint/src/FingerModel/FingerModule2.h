/*
 * FingerModule2.h
 *
 *  Created on: Jun 18, 2011
 *      Author: root
 */

#ifndef FINGERMODULE2_H_
#define FINGERMODULE2_H_
#include"FingerModule.h"
class FingerModule2: public FingerModule
{
public:
	FingerModule2(QString name);
	~FingerModule2();
	bool openDevice();
	bool closeDevice();
	bool sendMsg(char *msg, int len);
	char readMsg(char *msg, int len);
};

#endif /* FINGERMODULE2_H_ */
