/*
 * FingerModule3.cpp
 *
 *  Created on: Jun 18, 2011
 *      Author: root
 */

#include "FingerModule3.h"

FingerModule3::FingerModule3(QString name):FingerModule(name)
{
	// TODO Auto-generated constructor stub

}

FingerModule3::~FingerModule3()
{
	// TODO Auto-generated destructor stub
}
bool FingerModule3::openDevice()
{

	if (m_pSerial->open(QIODevice::ReadWrite))
	{
		m_pSerial->setBaudRate(BAUD115200);
		m_pSerial->setDataBits(DATA_8);
		m_pSerial->setParity(PAR_NONE);
		m_pSerial->setStopBits(STOP_1);
		m_pSerial->setFlowControl(FLOW_OFF);
		m_pSerial->setTimeout(500);

	}
	else
	{
		return false;
	}
	return true;
}
bool FingerModule3::sendMsg(char *msg,int len)
{
	bool bOK=false;
	if(m_Mutex.tryLock(1000))
	{
		bOK=m_pSerial->write(msg,len)?true:false;
		m_Mutex.unlock();
	}
	return bOK;
}
bool FingerModule3::closeDevice()
{
	return true;
}
char FingerModule3::readMsg(char *msg,int len)
{
	return m_pSerial->read(msg,len);
}
