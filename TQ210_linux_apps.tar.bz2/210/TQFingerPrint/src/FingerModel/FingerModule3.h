/*
 * FingerModule3.h
 *
 *  Created on: Jun 18, 2011
 *      Author: root
 */

#ifndef FINGERMODULE3_H_
#define FINGERMODULE3_H_
#include"FingerModule.h"
class FingerModule3: public FingerModule
{
public:
	FingerModule3(QString name);
	~FingerModule3();
	bool openDevice();
	bool closeDevice();
	bool sendMsg(char *msg, int len);
	char readMsg(char *msg, int len);
};

#endif /* FINGERMODULE3_H_ */
