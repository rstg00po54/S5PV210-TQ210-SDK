#include "SerialPortCom.h"

using namespace std;
/************************************************************************/
/*
 * SerialPortCom(int portNum)
 * 依据串口号初始化串口设备
 */
/************************************************************************/
SerialPortCom::SerialPortCom(int portNum)
{
	char devName[32];
	sprintf(devName, "/dev/ttyS%d", portNum);
	this->sFd = open(devName, O_RDWR | O_NOCTTY | O_NDELAY);
	if (sFd == -1)
	{
		return;
	}
	cout << "串口位置：" << devName << endl;
	/*Set Serial Port*/
	struct termios newtio;
	tcgetattr(sFd, &newtio);
	bzero(&newtio, sizeof(newtio));
	newtio.c_cflag &= ~CSIZE;
	/*8位数据位*/
	newtio.c_cflag |= CS8;
	/*设置奇校验*/
	newtio.c_cflag &= ~PARENB; /* Clear parity enable */
	newtio.c_iflag &= ~INPCK; /* Enable parity checking */
	/*设置停止位*/
	newtio.c_cflag &= ~CSTOPB;//1
	newtio.c_cc[VTIME] = 150;
	newtio.c_cc[VMIN] = 8;
	newtio.c_cflag |= (CLOCAL | CREAD);
	newtio.c_oflag |= OPOST;
	newtio.c_iflag &= ~(IXON | IXOFF | IXANY);

	newtio.c_cflag |= CREAD | CLOCAL;
	newtio.c_lflag &= (~(ICANON | ECHO | ECHOE | ECHOK | ECHONL
			| ISIG));
	newtio.c_iflag &= (~(INPCK | IGNPAR | PARMRK | ISTRIP | ICRNL
			| IXANY));
	newtio.c_oflag &= (~OPOST);
	newtio.c_cc[VMIN] = 0;
	newtio.c_cc[VINTR] = _POSIX_VDISABLE;
	newtio.c_cc[VQUIT] = _POSIX_VDISABLE;
	newtio.c_cc[VSTART] = _POSIX_VDISABLE;
	newtio.c_cc[VSTOP] = _POSIX_VDISABLE;
	newtio.c_cc[VSUSP] = _POSIX_VDISABLE;

	cfsetispeed(&newtio, B115200);//B300 B600 B900 B1200 B2400 B4800 B9600 B19200 B38400 B9600
	cfsetospeed(&newtio, B115200);
	tcflush(sFd, TCIFLUSH);
	if (tcsetattr(sFd, TCSANOW, &newtio) != 0)
	{
		cout << "Serial setup error " << portNum << endl;
		close(sFd);
		sFd = -1;
	}
}
/************************************************************************/
/*
 * SerialPortCom(int portNum,speed_t bs)
 * 依据串口号初始化串口设备并设置波特率
 */
/************************************************************************/
SerialPortCom::SerialPortCom(int portNum, speed_t bs)
{
	char devName[32];
	sprintf(devName, "/dev/ttyS%d", portNum);

	this->sFd = open(devName, O_RDWR | O_NOCTTY | O_NDELAY);
	if (sFd == -1)
	{
		return;
	}
	cout << devName << endl;
	/*Set Serial Port*/
	struct termios newtio;
	tcgetattr(sFd, &newtio);
	bzero(&newtio, sizeof(newtio));
	newtio.c_cflag &= ~CSIZE;
	/*8位数据位*/
	newtio.c_cflag |= CS8;
	/*设置奇校验*/
	newtio.c_cflag &= ~PARENB; /* Clear parity enable */
	newtio.c_iflag &= ~INPCK; /* Enable parity checking */
	/*设置停止位*/
	newtio.c_cflag &= ~CSTOPB;//1
	newtio.c_cc[VTIME] = 150;
	newtio.c_cc[VMIN] = 0;
	newtio.c_cflag |= (CLOCAL | CREAD);
	newtio.c_oflag |= OPOST;
	newtio.c_iflag &= ~(IXON | IXOFF | IXANY);
	cfsetispeed(&newtio, bs);//B300 B600 B900 B1200 B2400 B4800 B9600 B19200 B38400 B9600
	cfsetospeed(&newtio, bs);
	tcflush(sFd, TCIFLUSH);
	if (tcsetattr(sFd, TCSANOW, &newtio) != 0)
	{
		cout << "Serial setup error" << portNum << endl;
		close(sFd);
		sFd = -1;
	}
}
/************************************************************************/
/*
 * writePort(unsigned char *buf,int wLen)
 * 写数据到指定的串口
 * return -1 表示设备错误
 * 			 >0  表示写设备字节数
 */
/************************************************************************/

int SerialPortCom::writePort(unsigned char *buf, int wLen)
{
	if (sFd < 0)
	{
		return -1;
	}
	/*	cout<<"Com write data start "<<endl;
	 for (int i=0; i<wLen; i++)
	 {
	 printf("%02x ", buf[i]);
	 }
	 cout<<"\nCom write data end "<<endl;*/
	int bak = write(sFd, buf, wLen);
	return bak;
}
/************************************************************************/
/*
 * readPort(unsigned char *buf,int maxLen)
 * 读数据在指定的串口
 * return -1 表示设备错误
 * 			 >0  表示实际读取的字节数
 * 具体应用中需要子类继承该方法实现自己的读数据
 */
/************************************************************************/
int SerialPortCom::readPort(unsigned char *buf, int maxLen)
{
	if (sFd < 0)
	{
		return -1;
	}
	fd_set readfd;
	FD_ZERO(&readfd);
	FD_SET(sFd, &readfd);
	int rc = select(sFd + 1, &readfd, NULL, NULL, NULL);
	if (rc <= 0)
	{
		cout << "select sFd:" << sFd << " Failure" << endl;
	}
	/*	unsigned char bData;
	 int iLen = -1;
	 while (iLen < maxLen && bData != 0x0d)
	 {
	 //printf("%02x ", bData);
	 cout<<bData<<endl;
	 iLen += read(sFd, &bData, 1);
	 buf[iLen] = bData;
	 //		printf("%02x ", bData);
	 cout<<"----------"<<iLen<<endl;
	 }
	 cout<<"========="<<iLen<<endl;*/
	return read(sFd, buf, maxLen);
}
/************************************************************************/
/*
 * ~SerialPortCom()
 * 析构时释放串口资源
 */
/************************************************************************/
SerialPortCom::~SerialPortCom()
{
	if (sFd != -1)
	{
		close(sFd);
	}
}

