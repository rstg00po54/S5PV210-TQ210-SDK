#ifndef SERIALPORTCOM_H_
#define SERIALPORTCOM_H_
//-----------------------
/*Std libs*/
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
//-----------------------
/*Linux libs*/
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <sys/time.h>
class SerialPortCom 
{
protected:
	int sFd;
public:
	SerialPortCom(int);
	SerialPortCom(int, speed_t);
	int writePort(unsigned char *, int);
	int readPort(unsigned char *, int);
	~SerialPortCom();

};

#endif /*SERIALPORTCOM_H_*/
