/*
 *     公司名:    	东莞市建邦计算机软件有限公司
 *     项目名:   		ECard
 *    文件名:     	uQArm.cpp
 *     文件描述:   arm板命令处理类
 *    创建日期:     2009-06-25
 *    创 建 人:      lkp
 *     文档:
 *    运行平台:     linux
 *     其他:             无
 */
#include "uArm.h"
#include "../../fingerprint.h"
QArm *g_pArm;
QArm::QArm(int iPort)
{
	m_iRecvLen = 0;
	spc = new SerialPortCom(iPort);
	//arm = this;
}

QArm::~QArm()
{
	delete spc;
	//delete arm;
}

/*QArm * QArm::getInstance()
 {
 if (arm == NULL)
 return new QArm();
 return arm;
 }*/
/*
 ** 函数名称：run
 ** 创建日期：2009-06-30
 ** 创 建 人：lkp
 ** 函数功能：串口监听线程
 ** 参    数： 无
 ** 返    回：无
 ** 数 据 库：无
 ** 其它说明：无
 */
void QArm::run()
{
	BYTE cCanFrmLen = 0, cTranCount = 0;
	BYTE bComData[2048]; // 接收数据
	BYTE cCheck; // 异或校验
	int iRecvLen = 0;
	while (true)
	{
//		usleep(100);
		iRecvLen = RecvCommand(bComData);
		if (iRecvLen > 0)
		{
	//		RecvMsg *msg = new RecvMsg();
	//		memcpy(msg, bComData, iRecvLen);
	//		msg->_iMsgLen = iRecvLen;
			//g_pComMsgQueue->Add(msg);
			//g_ComDebugger->AddDisplay(bComData, iRecvLen);
	//		cout<<"接收到数据"<<endl;
			//printf("%02x ", cCommGet);
		}
	}
}
/*
 ** 函数名称：WriteCommand
 ** 创建日期：2009-06-30
 ** 创 建 人：lkp
 ** 函数功能：写串口
 ** 参    数：
 * 						msg[in] arm板命令
 * 						IsIcCard[i] 是否是IC卡命令
 ** 返    回：写入串口长度
 ** 数 据 库：无
 ** 其它说明：无
 */
/*int QArm::WriteCommand(ArmMessage *msg, bool IsIcCard)
 {
 m_Mutex.lock();
 unsigned char cCommand[msg->_iContLength + 10];
 int iPos = 0;
 int iIndex= 1;//索引
 int iResult = 0;
 int iCommandLength = 0;
 if (IsIcCard)//IC卡
 iCommandLength = msg->_iContLength + 10;
 else
 iCommandLength = msg->_iContLength + 8;
 cCommand[iPos++] = 0xab;//帧头1
 cCommand[iPos++] = 0x0f;//帧头2
 cCommand[iPos++] = iCommandLength;//帧长度低字节
 cCommand[iPos++] = iCommandLength>>8;//帧长度高字节
 cCommand[iPos++] = iIndex;//帧索引
 cCommand[iPos++] = iIndex>>8;
 cCommand[iPos++] = msg->_iType;//接口类型
 cCommand[iPos++] = msg->_iCommand;//命令字
 memcpy(&cCommand[iPos], msg->_cContent, msg->_iContLength);
 cCommand[iPos + msg->_iContLength] = '\0';
 iPos += msg->_iContLength;
 if (IsIcCard)//IC卡
 {
 msg->_iBCC = GetBCC(&cCommand[2], iPos - 2);
 cCommand[iPos++] = msg->_iBCC;//BCC验证
 cCommand[iPos++] = 0x03;//结束符
 }
 iResult = spc->writePort((unsigned char *)cCommand, iCommandLength);//写串口
 if (iResult != iCommandLength)//写入串口与要写入的长度不一致，就认为失败
 {
 m_Mutex.unlock();
 return -1;
 }
 m_Mutex.unlock();
 return iCommandLength;
 }*/
/*
 ** 函数名称：RecvCommand
 ** 创建日期：2009-06-30
 ** 创 建 人：lkp
 ** 函数功能：写串口
 ** 参    数：
 * 						msg[in/out] 接收到的arm板命令
 ** 返    回：是否接收到串口发出的数据
 ** 数 据 库：无
 ** 其它说明：无
 */
int QArm::RecvCommand(BYTE *msg)
{
	m_iRecvLen = spc->readPort(msg, 2048);//读串口
	return m_iRecvLen;
}
//设置事件接收者
void QArm::setListener(QObject * listener)
{
	this->listener = listener;
}
int QArm::write(BYTE *buf, int iLen)
{
	return spc->writePort((unsigned char *) buf, iLen);//写串口
}

