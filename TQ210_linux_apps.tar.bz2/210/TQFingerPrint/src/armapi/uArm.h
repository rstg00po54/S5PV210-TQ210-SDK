#ifndef UARM_H_
#define UARM_H_
#include <QThread>
#include <QMutex>
#include <QWaitCondition>
#include "SerialPortCom.h"
#include "../uStruct.h"
#include <iostream>
using namespace std;
class QArm : public QThread
{
public:
	QArm(int iPort);
	~QArm();
	//static QArm * getInstance();
	void run();
	QMutex m_Mutex;
	QWaitCondition m_ComWrite;
	QWaitCondition m_ComRead;
	void setListener(QObject *);
	//int WriteCommand(ArmMessage *msg, bool IsIcCard);
	int write(BYTE *, int i);
	//bool CardInit(ArmMessage *msg);//卡片初始化
	bool GetCardBalance();//取卡片金额
	//bool CardProcess(ArmMessage *msg);//圈存
	bool MakeKeyActive(bool bIsPin);//激活密钥
	bool OpenKeyBoard(bool bIsCard);//进入加密状态
	bool CloseKeyBoard();//取消加密状态
	bool SetWorkKey(unsigned char *cWorkKey, int iLen, bool bIsPin);//设置工作密钥
	bool SetPrimaryKey(unsigned char *cPrimaryKey, int iLen, bool IsSecret);//设置主密钥
	bool CalcMacValueOfMsg(unsigned char *msg, unsigned char *mac, int iLen);//计算MAC值
	bool GetPin();
private:
	//static QArm       *arm;
	SerialPortCom     *spc;
	QObject           *listener;
	int 				m_iTimeOut;//超时时间
	int 				m_iRecvLen;//接收长度
	unsigned char       m_bRecvData[2048];
	int m_iTtyStatus;
	int 				RecvCommand(BYTE *);
};
extern QArm *g_pArm;
#endif /*UARM_H_*/
