#include "FileView.h"

#include<QHBoxLayout>
#include<QVBoxLayout>
#include <QModelIndex>
#include<QMessageBox>
#include<QFile>
#include <QByteArray>
//#include<iostream>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QtSql>
//using namespace std;
extern QSqlDatabase g_Sql;//声明一个全局变量,db
bool bFail;

FileView::FileView(QDialog *parent) :
	QDialog(parent)
{
	// TODO Auto-generated constructor stub
	g_Sql = QSqlDatabase::addDatabase("QSQLITE");
	g_Sql.setDatabaseName("/opt/PDA/lib/fingerdata.db");

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");//设置背景
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	m_dirmodel = new QDirModel;

	m_treeview = new QTreeView(this);
	m_treeview->setModel(m_dirmodel);
	m_treeview->hideColumn(1);
	m_treeview->hideColumn(2);
	m_treeview->hideColumn(3);
	m_treeview->setFixedSize(460, 180);
	QModelIndex index = m_dirmodel->index("/opt/PDA");//获取当前exe文件运行等路径位置，并显示当前路径
	m_treeview->expand(index);//展开这一路径
	m_treeview->scrollTo(index);//把试图等视口滚动到这个路径的位置
	m_treeview->expand(index);//展开这一路径

	m_leShowInfo = new QLineEdit(trUtf8("导入提示"), this);

	m_pbConfirm = new QPushButton(this);
	m_pbConfirm->setFixedSize(82, 32);
	m_pbConfirm->setIcon(QIcon("/opt/PDA/app/images/confirm.png"));//设置退出案件图标
	m_pbConfirm->setIconSize(QSize(82, 32));

	connect(m_pbConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));

	m_pbExit = new QPushButton(this);
	m_pbExit->setFixedSize(82, 32);
	m_pbExit->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出案件图标
	m_pbExit->setIconSize(QSize(82, 32));

	connect(m_pbExit, SIGNAL(clicked()), this, SLOT(close()));

	QHBoxLayout *hLayout = new QHBoxLayout;
	hLayout->addWidget(m_pbConfirm);
	hLayout->addWidget(m_pbExit);

	QVBoxLayout *vLayout = new QVBoxLayout;
	vLayout->addWidget(m_treeview);
	vLayout->addSpacing(44);
	vLayout->addWidget(m_leShowInfo);
	vLayout->addLayout(hLayout);
	this->setLayout(vLayout);
}

FileView::~FileView()
{
	// TODO Auto-generated destructor stub
}

void FileView::pbConfirmClicked()
{
	if (!g_Sql.open())
	{
		QMessageBox::critical(NULL, QObject::tr("无法打开数据库\n"),
				QObject::tr("退出清按Cancel键"), QMessageBox::Cancel,
				QMessageBox::NoButton);
	}
	QSqlQuery delete_query("DELETE FROM finger");
	QModelIndex index = m_treeview->currentIndex();
	if (!index.isValid())
	{
		QMessageBox::information(this, trUtf8("没有选择文件"), trUtf8("请选择文件"));
		return;
	}
	QModelIndex index_parent = m_dirmodel->index(
			m_dirmodel->fileInfo(index).path(), 0);
	if (m_dirmodel->fileInfo(index).isDir())
	{
		QMessageBox::information(this, trUtf8("选择文件夹错误"), trUtf8("请选择文件"));
	}
	QString str_num, str_name, str_privi, str_depart, str_info;
	QFile file;
	file.setFileName(m_dirmodel->filePath(index));
	if (!file.open(QIODevice::ReadOnly))
		return;
	while (!file.atEnd())
	{
		QByteArray line = file.readLine();
		if (line.at(0) == 'I')
		{
			line = file.readLine();
			str_num = line.data();
			str_num.remove('\n');
			line = file.readLine();
			line = file.readLine();
			str_name = line.data();
			str_name.remove('\n');
			line = file.readLine();
			line = file.readLine();
			str_privi = line.data();
			str_privi.remove('\n');
			line = file.readLine();
			line = file.readLine();
			str_depart = line.data();
			str_depart.remove('\n');
			line = file.readLine();
			line = file.readLine();
			str_info = line.data();
			str_info.remove('\n');

			QString str_import("insert into finger values(");
			str_import.append(str_num);
			str_import.append(",");
			str_import.append('"');
			str_import.append(str_name);
			str_import.append('"');
			str_import.append(",");
			str_import.append(str_privi);
			str_import.append(",");
			str_import.append('"');
			str_import.append(str_depart);
			str_import.append('"');
			str_import.append(",");
			str_import.append('"');
			str_import.append(str_info);
			str_import.append('"');
			str_import.append(')');
			str_import.append(';');
//			cout << str_import.toStdString().c_str() << endl;

			//		QSqlQuery import_query(str_import);
			QSqlQuery import_query;
			if (import_query.exec(str_import))
			{
				m_leShowInfo->setText(trUtf8("导入成功"));
			}
			else
				bFail = 1;

			/*QSqlQuery query;
			 query.exec("INSERT INTO employee (id, name, salary) "
			 "VALUES (1001, 'Thad Beaumont', 65000)");*/
		}
	}
	if (bFail == 1)
		m_leShowInfo->setText(trUtf8("导入失败"));
	/*QSqlQuery select_query("SELECT * FROM finger");
	 while (select_query.next())
	 {
	 QString str_id = select_query.value(0).toString();
	 cout<<"ddddddd"<<str_id.toStdString().c_str()<<endl;
	 }*/
}
