/*
 * FileView.h
 *
 *  Created on: Jun 17, 2011
 *      Author: root
 */

#ifndef FILEVIEW_H_
#define FILEVIEW_H_
#include <QtGui/QDialog>
#include<QPushButton>
#include<QTreeView>
#include <QDirModel>
#include<QLineEdit>

class FileView: public QDialog
{
	Q_OBJECT
public:
	FileView(QDialog *parent = 0);
	~FileView();

public slots:
	void pbConfirmClicked();

private:
	QPushButton *m_pbConfirm;
	QPushButton *m_pbExit;
	QTreeView *m_treeview;
	QDirModel *m_dirmodel;
	QLineEdit *m_leShowInfo;


};

#endif /* FILEVIEW_H_ */
