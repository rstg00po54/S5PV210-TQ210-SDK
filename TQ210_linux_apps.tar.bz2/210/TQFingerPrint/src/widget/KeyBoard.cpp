#include "KeyBoard.h"
#include <QGridLayout>
#include<QVBoxLayout>

KeyBoard::KeyBoard(QWidget *parent) :
	QWidget(parent)
{
	// TODO Auto-generated constructor stub

	m_leShow = new QLineEdit(this);

	m_pb1 = new QPushButton("1", this);
	m_pb1->setFixedSize(33,33);
	m_pb2 = new QPushButton("2", this);
	m_pb3 = new QPushButton("3", this);
	m_pb4 = new QPushButton("4", this);
	m_pb5 = new QPushButton("5", this);
	m_pb6 = new QPushButton("6", this);
	m_pb7 = new QPushButton("7", this);
	m_pb8 = new QPushButton("8", this);
	m_pb9 = new QPushButton("9", this);
	m_pb0 = new QPushButton("0", this);
	m_pbConfirm = new QPushButton(trUtf8("确定"), this);
	m_pbClear = new QPushButton(trUtf8("清除"), this);

	connect(m_pb1, SIGNAL(clicked()), this, SLOT(m_pb1Clicked()));
	connect(m_pb2, SIGNAL(clicked()), this, SLOT(m_pb2Clicked()));
	connect(m_pb3, SIGNAL(clicked()), this, SLOT(m_pb3Clicked()));
	connect(m_pb4, SIGNAL(clicked()), this, SLOT(m_pb4Clicked()));
	connect(m_pb5, SIGNAL(clicked()), this, SLOT(m_pb5Clicked()));
	connect(m_pb6, SIGNAL(clicked()), this, SLOT(m_pb6Clicked()));
	connect(m_pb7, SIGNAL(clicked()), this, SLOT(m_pb7Clicked()));
	connect(m_pb8, SIGNAL(clicked()), this, SLOT(m_pb8Clicked()));
	connect(m_pb9, SIGNAL(clicked()), this, SLOT(m_pb9Clicked()));
	connect(m_pb0, SIGNAL(clicked()), this, SLOT(m_pb0Clicked()));
	connect(m_pbConfirm, SIGNAL(clicked()), this, SLOT(m_pbConfirmClicked()));
	connect(m_pbClear, SIGNAL(clicked()), this, SLOT(m_pbClearClicked()));

	QGridLayout *gNumLayout = new QGridLayout;
	gNumLayout->addWidget(m_pb1, 0, 0);
	gNumLayout->addWidget(m_pb2, 0, 1);
	gNumLayout->addWidget(m_pb3, 0, 2);
	gNumLayout->addWidget(m_pb4, 1, 0);
	gNumLayout->addWidget(m_pb5, 1, 1);
	gNumLayout->addWidget(m_pb6, 1, 2);
	gNumLayout->addWidget(m_pb7, 2, 0);
	gNumLayout->addWidget(m_pb8, 2, 1);
	gNumLayout->addWidget(m_pb9, 2, 2);
	gNumLayout->addWidget(m_pbClear, 3, 0);
	gNumLayout->addWidget(m_pb0, 3, 1);
	gNumLayout->addWidget(m_pbConfirm, 3, 2);

	QVBoxLayout *vmainLayout = new QVBoxLayout;
	vmainLayout->addWidget(m_leShow);
	vmainLayout->addLayout(gNumLayout);

	this->setLayout(vmainLayout);
}

KeyBoard::~KeyBoard()
{
	// TODO Auto-generated destructor stub
}
void KeyBoard::m_pb1Clicked()
{
	//m_leShow->setText(QString::number(1));
}
void KeyBoard::m_pb2Clicked()
{
	//m_leShow->setText(m_leShow->text().toInt() *10 + 2);
}
void KeyBoard::m_pb3Clicked()
{
	m_leShow->setText("3");
}
void KeyBoard::m_pb4Clicked()
{
	m_leShow->setText("4");
}
void KeyBoard::m_pb5Clicked()
{
	m_leShow->setText("5");
}
void KeyBoard::m_pb6Clicked()
{
	m_leShow->setText("6");
}
void KeyBoard::m_pb7Clicked()
{
	m_leShow->setText("7");
}
void KeyBoard::m_pb8Clicked()
{
	m_leShow->setText("8");
}
void KeyBoard::m_pb9Clicked()
{
	m_leShow->setText("9");
}
void KeyBoard::m_pb0Clicked()
{
	m_leShow->setText("0");
}
void KeyBoard::m_pbConfirmClicked()
{

}void KeyBoard::m_pbClearClicked()
{
	m_leShow->clear();
}
