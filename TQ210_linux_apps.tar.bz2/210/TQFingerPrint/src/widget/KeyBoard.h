#ifndef KEYBOARD_H_
#define KEYBOARD_H_

#include <QtGui/QWidget>
#include<QPushButton>
#include<QLineEdit>

class KeyBoard: public QWidget
{
	Q_OBJECT

public:
	KeyBoard(QWidget *parent = 0);
	~KeyBoard();
public slots:
	void m_pb1Clicked();
	void m_pb2Clicked();
	void m_pb3Clicked();
	void m_pb4Clicked();
	void m_pb5Clicked();
	void m_pb6Clicked();
	void m_pb7Clicked();
	void m_pb8Clicked();
	void m_pb9Clicked();
	void m_pb0Clicked();
	void m_pbConfirmClicked();
	void m_pbClearClicked();

private:
	QLineEdit *m_leShow;

	QPushButton *m_pb1;
	QPushButton *m_pb2;
	QPushButton *m_pb3;
	QPushButton *m_pb4;
	QPushButton *m_pb5;
	QPushButton *m_pb6;
	QPushButton *m_pb7;
	QPushButton *m_pb8;
	QPushButton *m_pb9;
	QPushButton *m_pb0;
	QPushButton *m_pbConfirm;
	QPushButton *m_pbClear;
};

#endif /* KEYBOARD_H_ */
