/*
 * MyTextEdit.cpp
 *
 *  Created on: 2011-4-12
 *      Author: lkp
 */

#include "MyTextEdit.h"
#include <iostream>
using namespace std;

MyTextEdit::MyTextEdit(QWidget *)
{
}

MyTextEdit::~MyTextEdit()
{
}
void MyTextEdit::keyPressEvent(QKeyEvent *event)
{
//	cout << "按键值：" << event->key();
	//this->append(m_strInput.mid(m_strInput.length() - 1, 1));
	//	this->setText(this->te);
	if (event->key() == Qt::Key_Space)
	{
		if (m_strInput.length() == 1)
		{
			m_strInput += ' ';
			emit EnterPressed(m_strInput);
			m_strInput = "";
			return;
		}
	}
	else if (event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter)
	{
		m_strInput += '\n';
		emit EnterPressed(m_strInput);
		m_strInput = "";
		return;
	}
	m_strInput += event->key();
	m_strInput = m_strInput.toLower();
	QString str =this->toPlainText()+event->key();
	str = str.toLower();
	this->setText(str);
	QWidget::keyPressEvent(event);
}
