#ifndef COMDEBUGGER_H
#define COMDEBUGGER_H

#include <QtGui/QWidget>
//#include "ui_gps.h"
#include <QTimer>
#include <QKeyEvent>
#include "src/armapi/posix_qextserialport.h"
//#include "src/widget/MyTextEdit.h"
#include <QStatusBar>
#include <QCheckBox>
#include <QLabel>
#include <QtSql>
#include<QtGui>
#include"src/MyLabel/MyLabel.h"
#include <qprocess.h>
class GPS: public QWidget
{
	Q_OBJECT

public:
	GPS(QWidget *parent = 0);
	~GPS();
	//	void keyPressEvent(QKeyEvent *event);
	//	void SetComStatus(QString str);
	QStringList strListUser;public slots:
	void ShowComMsg(char *,int);//处理gps数据
	void pbSetClicked();//设置相应
	void pbContrGPSClicked();//开始暂停
	void pbImportGPSData();//导入数据
	void pbExit();//退出
	void lbDoubleClicked();//双击图片
	void pbHelpClicked();
private:
//	Ui::ComDebuggerClass ui;
	QTimer *m_pTimer;//串口读取定时器
	QSqlDatabase db;//数据库
	QTextEdit *m_introDisplay;//显示地区信息
	QTextEdit *m_numDisplay;//显示经纬度数字
	QPushButton *m_pbSet;
	QPushButton *m_pbImportGPSData;
	QPushButton *m_pbContrGPS;//开始暂停GPS
	QPushButton *m_pbExit;////退出
	QLabel *m_laTitle;//标题
	MyLabel *m_lbImage;//显示图片的QLabel
	bool m_IsFullScreen;//用于图片全屏
	bool m_isStartGPS;
	int m_iRecvCount;//接收数据包
	int m_iSendCount;//发送数据包

	QPushButton *m_pbHelp;
	QProcess process;

	QPushButton *m_pbKey;
};
extern GPS *g_pComDebugger;
extern QSqlDatabase g_Sql;//声明一个数据库全局变量,db
#endif // COMDEBUGGER_H
