/********************************************************************************
** Form generated from reading ui file 'gps.ui'
**
** Created: Wed Sep 12 10:11:15 2012
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_GPS_H
#define UI_GPS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ComDebuggerClass
{
public:

    void setupUi(QWidget *ComDebuggerClass)
    {
        if (ComDebuggerClass->objectName().isEmpty())
            ComDebuggerClass->setObjectName(QString::fromUtf8("ComDebuggerClass"));
        ComDebuggerClass->resize(480, 272);
        ComDebuggerClass->setAutoFillBackground(true);
        ComDebuggerClass->setStyleSheet(QString::fromUtf8(""));

        retranslateUi(ComDebuggerClass);

        QMetaObject::connectSlotsByName(ComDebuggerClass);
    } // setupUi

    void retranslateUi(QWidget *ComDebuggerClass)
    {
        ComDebuggerClass->setWindowTitle(QApplication::translate("ComDebuggerClass", "ComDebugger", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(ComDebuggerClass);
    } // retranslateUi

};

namespace Ui {
    class ComDebuggerClass: public Ui_ComDebuggerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GPS_H
