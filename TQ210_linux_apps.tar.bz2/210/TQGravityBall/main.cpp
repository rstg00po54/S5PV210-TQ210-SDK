#include <QApplication>

#include "tqgravityball.h"
#include "thread/Thread.h"

int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	g_Thread= new Thread();
	g_Thread->start();
	TQGravityBall window;
	window.showFullScreen();
	return app.exec();
}
