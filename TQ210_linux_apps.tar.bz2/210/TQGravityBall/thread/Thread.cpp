/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		GpsThread
 *    文件名:     	 GpsThread.cpp
 *    文件描述:  		gps读取数据线程
 *    创建日期:      2011-06-27
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */
#include "Thread.h"
#include <fcntl.h>
#include <math.h>
#include<iostream>
using namespace std;

static int fd;
unsigned int x_value, y_value, z_value;
float x_start, y_start, z_start;
float angle_data[3];
unsigned int value_temp[4];
unsigned char mode = 3;
int ret;
#define pi 3.141592653
Thread *g_Thread;

Thread::Thread()
{
	m_bFlg = true;
	openDevice();
}
Thread::~Thread()
{
}
bool Thread::openDevice()
{
	fd = open("/dev/angle", O_RDWR);
	if (fd < 0)
	{
		m_bFlg = false;
		return false;
	}
	else
		m_bFlg = true;
	return true;
}
bool Thread::openSucess()
{
	return m_bFlg;
}
//线程函数
void Thread::run()
{
	while (1)
	{
		ret = read(fd, value_temp, sizeof(value_temp));
		if (ret != sizeof(value_temp))
		{
			exit(1);
		}

		mode = value_temp[3];

		x_start = dToa(value_temp[0], mode);
		y_start = dToa(value_temp[1], mode);
		z_start = dToa(value_temp[2], mode);

		angle_data[0] = angle(y_start, z_start, x_start) * 180 / pi;
		angle_data[1] = angle(z_start, x_start, y_start) * 180 / pi;
		angle_data[2] = angle_f(x_start, y_start, z_start) * 180 / pi;

		emit Readdata(angle_data);
		usleep(10);
	}
}
float Thread::dToa(unsigned short dat, unsigned char mode)
{
	float result = 0.0;

	if ((dat & 0x200) != 0)
	{
		dat = ((~dat) + 1) & 0x1ff;
		result = -(9.8 * (float) (mode + 1)) * 2 * dat / 512.0;
	}
	else
	{
		dat = dat & 0x1ff;
		result = (9.8 * (float) (mode + 1)) * dat * 2 / 512.0;
	}
	return result;
}
float Thread::angle(float axis0, float axis1, float axis2)
{
	float temp;
	float result;
	temp = sqrt(axis0 * axis0 + axis1 * axis1);
	if (temp == 0.0)
		return 1;
	result = atan(axis2 / temp);
	return result;

}
float Thread::angle_f(float axis0, float axis1, float axis2)
{
	float temp;
	float result;
	temp = sqrt(axis0 * axis0 + axis1 * axis1);
	if (axis2 == 0.0)
		return 1;
	result = atan(temp / axis2);
	return result;

}
