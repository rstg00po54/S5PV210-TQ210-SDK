/*
 * uIDReaderThread.h
 *
 *  Created on: 2011-6-27
 *      Author: root
 */

#ifndef UIDREADERTHREAD_H_
#define UIDREADERTHREAD_H_
#include <QThread>
#include <QObject>

class Thread: public QThread
{
	Q_OBJECT
public:
	Thread();
	virtual ~Thread();
	void run();
	bool openDevice();
	bool openSucess();
signals:
	void openWrong();
	void Readdata(float *);

private:
	bool m_bFlg;
	float dToa(unsigned short dat, unsigned char mode);
	float angle(float axis0, float axis1, float axis2);
	float angle_f(float axis0, float axis1, float axis2);
};
extern Thread *g_Thread;
#endif /* UIDREADERTHREAD_H_ */
