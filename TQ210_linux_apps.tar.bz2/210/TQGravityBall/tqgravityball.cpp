#include "tqgravityball.h"
#include"thread/Thread.h"
#include <QPicture>
#include<QPainter>
#include<QMessageBox>
#include<QApplication>
#include <QDesktopWidget>
#include<QPalette>
#include<QTime>
#include <iostream>
#include <qboxlayout.h>
using namespace std;
bool bStart, bNewTime;
TQGravityBall::TQGravityBall(QWidget *parent) :
	QWidget(parent)
{
	isSucess = true;
	screen_size = QApplication::desktop()->screenGeometry();

	bStart = true;
	bNewTime = true;

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	QLabel *labTitle = new QLabel(trUtf8("天嵌科技重力球游戏"), this);
	labTitle->setFixedHeight(30);
	labTitle->setAlignment(Qt::AlignCenter);

	//滚动球
	QPixmap m_pix;
	m_pix.load("/opt/PDA/app/images/ball.png");
	m_pix = m_pix.scaled(30, 30, Qt::IgnoreAspectRatio);//图片大小

	//滚动球位置
	m_iX = 0;
	m_iY = 0;
	m_label = new QLabel(this);
	m_label->setPixmap(m_pix);
	m_label->move(m_iX, m_iY);

	m_timScroe = new QTimer();
	connect(m_timScroe, SIGNAL(timeout()), this, SLOT(timScorSlot()));

	//四个按钮
	m_pbStartStop = new QPushButton(this);
	//m_pbStartStop->move(30, 230);
	m_pbStartStop->setFixedSize(75, 30);//图片大小
	m_pbStartStop->setIconSize(QSize(75, 30));//图片大小
	QPixmap pix("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
	pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbStartStop->setIcon(QIcon(pix));
	connect(m_pbStartStop, SIGNAL(clicked()), this,
			SLOT(pbStartStopClicked()));

	m_pbRestart = new QPushButton(this);//restart
	//m_pbRestart->move(110, 230);
	m_pbRestart->setFixedSize(75, 30);//图片大小
	m_pbRestart->setIconSize(QSize(75, 30));//图片大小
	pix.load("/opt/PDA/app/images/restart_letter.png", 0, Qt::AutoColor);
	pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbRestart->setIcon(QIcon(pix));
	connect(m_pbRestart, SIGNAL(clicked()), this, SLOT(pbRestartClicked()));

	m_pbExit = new QPushButton(this);
	//m_pbExit->move(190, 230);
	m_pbExit->setFixedSize(75, 30);//图片大小
	m_pbExit->setIconSize(QSize(75, 30));//图片大小
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbExit->setIcon(QIcon(pix));
	connect(m_pbExit, SIGNAL(clicked()), this, SLOT(close()));

	m_pbHelp = new QPushButton(this);
	//m_pbHelp->move(270, 230);
	m_pbHelp->setFixedSize(75, 30);
	m_pbHelp->setIconSize(QSize(75, 30));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	QPalette p = QPalette();
	p.setColor(QPalette::WindowText, QColor("white"));
	QLabel *lab_time = new QLabel(trUtf8("时间："), this);
	lab_time->setFixedWidth(30);
	//lab_time->move(360, 220);
	lab_time->setPalette(p);
	QLabel *lab_score = new QLabel(trUtf8("得分："), this);
	lab_score->setFixedWidth(30);
	//lab_score->move(360, 245);
	lab_score->setPalette(p);

	m_lcdnumTime = new QLCDNumber(4, this);
	m_lcdnumTime->setFixedSize(75,30);

	m_lcdnumScore = new QLCDNumber(4, this);
	m_lcdnumScore->setFixedSize(75,30);

	QLabel *label = new QLabel(this);
	pix.load("/opt/PDA/app/images/cave.png", 0, Qt::AutoColor);
	pix = pix.scaled(40, 40, Qt::IgnoreAspectRatio);//图片大小
	label->setPixmap(pix);
	label->setAlignment(Qt::AlignCenter);
	//label->move(240 - 35, 135 - 35);

	//*****************by lih*********************************

	//title
	QVBoxLayout *vTitle = new QVBoxLayout();
	vTitle->addWidget(labTitle);
	//vTitle->setAlignment(Qt::AlignCenter);

	//body
	QHBoxLayout *cBody = new QHBoxLayout();
	cBody->addWidget(label);
	cBody->setAlignment(Qt::AlignCenter);

	//ground
	QVBoxLayout *cCounTtitleLayout = new QVBoxLayout();
	cCounTtitleLayout->addWidget(lab_time);
	cCounTtitleLayout->addWidget(lab_score);

	QVBoxLayout *cCountLayout = new QVBoxLayout();
	cCountLayout->addWidget(m_lcdnumTime);
	cCountLayout->addWidget(m_lcdnumScore);


	QHBoxLayout *cBtnLayout = new QHBoxLayout();
	cBtnLayout->addWidget(m_pbStartStop);
	cBtnLayout->addWidget(m_pbRestart);
	cBtnLayout->addWidget(m_pbExit);
	cBtnLayout->addWidget(m_pbHelp);


	QHBoxLayout *cGroundLayout = new QHBoxLayout();
	cGroundLayout->addLayout(cBtnLayout);
	cGroundLayout->addLayout(cCounTtitleLayout);
	cGroundLayout->addLayout(cCountLayout);
	//cGroundLayout->set



	QVBoxLayout *cvAll = new QVBoxLayout();
	cvAll->addLayout(vTitle);
	cvAll->addLayout(cBody);
	cvAll->addLayout(cGroundLayout);

	setLayout(cvAll);

}

TQGravityBall::~TQGravityBall()
{
	g_Thread->exit();
}
void TQGravityBall::showFullScreen()
{
	QWidget::showFullScreen();

	QTimer::singleShot(1000, this, SLOT(openWrongSlot()));
}
void TQGravityBall::openWrongSlot()
{
	if (!g_Thread->openSucess())
	{
		isSucess = false;
		bNewTime=false;
		bStart  = true;
		m_timScroe->stop();
		m_pbStartStop->setFixedSize(75, 30);
		m_pbStartStop->setIconSize(QSize(75, 30));
		QPixmap pix("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
		pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
		m_pbStartStop->setIcon(QIcon(pix));
		disconnect (g_Thread, SIGNAL(Readdata(float *)), 0,0);

		QMessageBox warn;
		warn.setWindowTitle(trUtf8("警告"));
		warn.setText(trUtf8("重力传感器未就绪！"));
		warn.setStandardButtons(QMessageBox::Ok);
		QPixmap pix1("/opt/PDA/app/images/EmbedSky.png", 0,
				Qt::AutoColor);
		QIcon icon(pix1);
		warn .setWindowIcon(icon);
		warn.exec();
	}
	else
		isSucess = true;
}

void TQGravityBall::ReadDataSlot(float angle[3])
{

	if ((abs(screen_size.width() / 2 - 35 - m_iX) < 10) && (abs(
			screen_size.height() / 2 - 35 - m_iY) < 10))
	{
		m_timScroe->stop();
		bStart = true;
		disconnect (g_Thread, SIGNAL(Readdata(float *)), 0,0);

		QMessageBox warn;
		warn.setWindowTitle(trUtf8("提示"));
		warn.setText(trUtf8("成功！\n得分:%1\n时间:%2").arg(score).arg(time));
		warn.setStandardButtons(QMessageBox::Ok);
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0,
				Qt::AutoColor);
		QIcon icon(pix);
		warn .setWindowIcon(icon);
		warn.exec();

		m_label->move(0, 0);
		m_lcdnumTime->display(0);
		m_lcdnumScore->display(0);

		//		bStart = !bStart;
		m_pbStartStop->setFixedSize(75, 30);
		m_pbStartStop->setIconSize(QSize(75, 30));
		pix.load("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
		pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
		m_pbStartStop->setIcon(QIcon(pix));
	}
	else
	{
		if (angle[1] > 16)
		{
			m_iY += 2;
		}
		else if (angle[1] < -4)
		{
			m_iY -= 2;
		}

		if (angle[0] > 16)
		{
			m_iX -= 2;
		}
		else if (angle[0] < -4)
		{
			m_iX += 2;
		}

		if (m_iX < 0)
			m_iX = 800;//screen_size.width();
		else if (m_iX > 800)//screen_size.width())
			m_iX = 0;

		if (m_iY < 0)
			m_iY = 480;//screen_size.height();
		else if (m_iY > 480)//screen_size.height())
			m_iY = 0;
		m_label->move(m_iX, m_iY);
	}
}
void TQGravityBall::pbStartStopClicked()
{
	bStart = !bStart;
	if (bStart == false)
	{
		if(!isSucess)
			QTimer::singleShot(10, this, SLOT(openWrongSlot()));
		else
		{
			m_timScroe->start(1000);

			m_iX = 0;
			m_iY = 0;
			m_label->move(m_iX, m_iY);

			m_timScroe->start(1000);
			if (bNewTime == true)
			{
				time = 50;
				score = 1000;
			}
			m_lcdnumTime->display(time);
			m_lcdnumScore->display(score);

			m_pbStartStop->setFixedSize(75, 30);
			m_pbStartStop->setIconSize(QSize(75, 30));
			QPixmap pix("/opt/PDA/app/images/pause.png", 0, Qt::AutoColor);
			pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
			m_pbStartStop->setIcon(QIcon(pix));

			connect	(g_Thread, SIGNAL(Readdata(float *)), this,
						SLOT(ReadDataSlot(float *)));
		}
	}
	else
	{
		bNewTime=false;
		m_timScroe->stop();
		m_pbStartStop->setFixedSize(75, 30);
		m_pbStartStop->setIconSize(QSize(75, 30));
		QPixmap pix("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
		pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
		m_pbStartStop->setIcon(QIcon(pix));

		disconnect (g_Thread, SIGNAL(Readdata(float *)), 0,0);
	}

}
void TQGravityBall::pbRestartClicked()
{
	if(!isSucess)
		QTimer::singleShot(10, this, SLOT(openWrongSlot()));
	else
	{
		m_iX = 0;
		m_iY = 0;
		m_label->move(m_iX, m_iY);
		m_timScroe->start(1000);

		time = 50;
		score = 1000;
		m_lcdnumTime->display(time);
		m_lcdnumScore->display(score);

		m_pbStartStop->setFixedSize(75, 30);
		m_pbStartStop->setIconSize(QSize(75, 30));
		QPixmap pix("/opt/PDA/app/images/pause.png", 0, Qt::AutoColor);
		pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
		m_pbStartStop->setIcon(QIcon(pix));

		connect (g_Thread, SIGNAL(Readdata(float *)), this,
				SLOT(ReadDataSlot(float *)));
		bStart = false;
	}
}
void TQGravityBall::timScorSlot()
{
	time -= 1;
	if (time != -1)
	{
		score -= 20;
		m_lcdnumTime->display(time);
		m_lcdnumScore->display(score);
	}

	if (time < 0)
	{
		m_timScroe->stop();
		bNewTime = true;
		bStart = true;

		disconnect (g_Thread, SIGNAL(Readdata(float *)), 0,0);

		if ((abs(screen_size.width() / 2 - 35 - m_iX) > 5) || (abs(
				screen_size.height() / 2 - 35 - m_iY) > 5))
		{
			QMessageBox question;
			question.setWindowTitle(trUtf8("提示"));
			question.setText(trUtf8("      游戏失败\n   是否重新开始？"));

			//			question.setStandardButtons(
			//					QMessageBox::Yes | QMessageBox::No);
			question.addButton(trUtf8("是"), QMessageBox::YesRole);
			question.addButton(trUtf8("否"), QMessageBox::NoRole);

			question.setDefaultButton(QMessageBox::Yes);
			QPixmap piqx("/opt/PDA/app/images/EmbedSky.png", 0,
					Qt::AutoColor);
			QIcon icon(piqx);
			question .setWindowIcon(icon);
			int ret = question.exec();
			switch (ret)
			{
			case 0:
			{
				pbRestartClicked();
			}
				break;
			case 1:
			{
				m_pbStartStop->setFixedSize(75, 30);
				m_pbStartStop->setIconSize(QSize(75, 30));
				QPixmap pix("/opt/PDA/app/images/start.png", 0,
						Qt::AutoColor);
				pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
				m_pbStartStop->setIcon(QIcon(pix));
			}
				break;
			default:
				break;
			}
		}

	}
}
void TQGravityBall::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
