#ifndef TQGRAVITYBALL_H
#define TQGRAVITYBALL_H

#include <QtGui/QWidget>
#include <QMouseEvent>
#include<QTimer>
#include<QLabel>
#include<QPushButton>
#include<QLCDNumber>
#include <qprocess.h>
class TQGravityBall: public QWidget
{
	Q_OBJECT

public:
	TQGravityBall(QWidget *parent = 0);
	~TQGravityBall();
	int m_iX;
	int m_iY;
	int time;
	int score;
	bool isSucess;
	void showFullScreen();

public	slots:
	void timScorSlot();
	void ReadDataSlot(float *);
	void openWrongSlot();
	void pbStartStopClicked();
	void pbRestartClicked();
	void pbHelpClicked();

private:
	QTimer *m_timScroe;
	QLabel *m_label;
	QRect screen_size;
	QLCDNumber *m_lcdnumTime;
	QLCDNumber *m_lcdnumScore;
	QPushButton *m_pbStartStop;
	QPushButton *m_pbRestart;
	QPushButton *m_pbExit;
	QProcess process;
	QPushButton *m_pbHelp;

};

#endif // TQGRAVITYBALL_H
