#include "uTQHelp.h"

#include <QtGui>
#include <QApplication>
#include <iostream>
//#include<QFont>
using namespace std;
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	QTQHelp *w = new QTQHelp;
	if (argc > 1)
	{
		QString str = QString(argv[1]);
		int iIndex = str.indexOf("appname");
		if (iIndex > 0)
		{
			w = new QTQHelp(
					0,
					str.mid(
							iIndex + 8,
							str.length() - iIndex
									- 8));
		}
	}

	w->showFullScreen();
	return a.exec();
}
