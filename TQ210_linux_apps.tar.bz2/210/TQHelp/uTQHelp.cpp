/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		QTQHelp
 *    文件名:     	uTQHelp.cpp
 *    文件描述:  		查看，修改帮助
 *    创建日期:      2011-06-28
 *    创 建 人:      lkp
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */
#include "uTQHelp.h"
#include <qlayout.h>
#include <QtXml>
#include <QMessageBox>
#include<QLabel>
//#include<iostream>
//using namespace std;

//---------------------------------------------------------------------------
/*
 ** 函数名称：initXmlContent
 ** 创建日期：2011-06-28
 ** 创 建 人： lkp
 ** 函数功能： 构造函数
 ** 参    数：
 ** 	parent     [in]:父界面
 ** 	strApp	   [in]:程序名
 ** 返    回：名称
 ** 数 据 库：无
 ** 其它说明：无
 */

QTQHelp::QTQHelp(QWidget *parent, QString strApp) :
	QWidget(parent)
{
	setAttribute(Qt::WA_DeleteOnClose);

	setGeometry(0, 0, 480, 272);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	m_strExpand = strApp;
	m_pItemParent = new QTreeWidgetItem();
	m_pItem = new QTreeWidgetItem();
	m_pItem = NULL;

	QLabel *labTitle = new QLabel(trUtf8("天嵌科技帮助程序"), this);
	labTitle->setAlignment(Qt::AlignCenter);

	QVBoxLayout *vLayout = new QVBoxLayout;
	QHBoxLayout *hLayout = new QHBoxLayout;
	QHBoxLayout *btnLayout = new QHBoxLayout;

	m_pTW = new QTreeWidget(this);
	m_pTE = new QTextEdit;

	m_pTE->setReadOnly(true);

	m_pTW->setMaximumWidth(150);
	m_pTW->setColumnCount(1);

	m_pTW->setHeaderLabel(trUtf8("应用名称"));

	//	QFont font("wenquanyi", 15, QFont::Bold);
	//	m_pTW->setFont(font);


	hLayout->addWidget(m_pTW);
	hLayout->addWidget(m_pTE);

	m_pbConfirm = new QPushButton(this);
	m_pbConfirm->setFixedSize(82, 32);
	m_pbConfirm->setIcon(QIcon("/opt/PDA/app/images/confirm.png"));
	m_pbConfirm->setIconSize(QSize(82, 32));

	m_pbModify = new QPushButton(this);
	m_pbModify->setFixedSize(82, 32);
	m_pbModify->setIcon(QIcon("/opt/PDA/app/images/modify.png"));
	m_pbModify->setIconSize(QSize(82, 32));

	m_pbCancel = new QPushButton(this);
	m_pbCancel->setFixedSize(82, 32);
	m_pbCancel->setIcon(QIcon("/opt/PDA/app/images/cancel.png"));
	m_pbCancel->setIconSize(QSize(82, 32));

	m_pbQuit = new QPushButton(this);
	m_pbQuit->setFixedSize(82, 32);
	m_pbQuit->setIcon(QIcon("/opt/PDA/app/images/exit.png"));
	m_pbQuit->setIconSize(QSize(82, 32));

	m_pbConfirm->setEnabled(false);
	m_pbConfirm->setMaximumWidth(80);
	m_pbModify->setMaximumWidth(80);
	m_pbCancel->setMaximumWidth(80);
	m_pbCancel->setEnabled(false);
	m_pbQuit->setMaximumWidth(80);

	btnLayout->addWidget(m_pbModify);
	btnLayout->addWidget(m_pbCancel);
	btnLayout->addWidget(m_pbConfirm);
	btnLayout->addWidget(m_pbQuit);

	vLayout->addWidget(labTitle);
	vLayout->addLayout(hLayout);
	vLayout->addLayout(btnLayout);

	setLayout(vLayout);

	connect(
			m_pTW,
			SIGNAL(itemClicked(QTreeWidgetItem *, int)),
			this,
			SLOT(itemClicked(QTreeWidgetItem *, int)));

	connect(m_pbCancel, SIGNAL(clicked()), this, SLOT(pbCancelClicked()));
	connect(m_pbModify, SIGNAL(clicked()), this, SLOT(pbModifyClicked()));
	connect(m_pbConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));
	connect(m_pbQuit, SIGNAL(clicked()), this, SLOT(pbQuitClicked()));

	initXml("/opt/PDA/configs/app.xml", trUtf8("应用程序"));
	initXml("/opt/PDA/configs/set.xml", trUtf8("设置"));
	initXml("/opt/PDA/configs/test.xml", trUtf8("测试程序"));
	initXml("/opt/PDA/configs/game.xml", trUtf8("游戏"));
	initXml("/opt/PDA/configs/file.xml", trUtf8("文件管理"));
	m_pTW->insertTopLevelItems(0, items);
	//	m_pTW->expandAll();
	if (m_pItem)
	{
		m_pTW->expandItem(m_pItemParent);
		itemClicked(m_pItem, 0);
	}
}

QTQHelp::~QTQHelp()
{
	items.clear();
	delete m_pItem;
	delete m_pItemParent;
	delete m_pTW;
	delete m_pTE;
	delete m_pbConfirm;
	delete m_pbModify;
	delete m_pbCancel;
	delete m_pbQuit;
}
//点击列表
void QTQHelp::itemClicked(QTreeWidgetItem * item, int)
{
	m_pTE->clear();
	m_strFileName = item->text(1);
	if (m_strFileName.length() > 0)
	{
		QFile f(m_strFileName);
		if (f.exists())
		{
			if (f.open(QIODevice::ReadOnly))
			{
//				char cData[1024];
				char cData[2048];
				int ilen = 0;
				while ((ilen = f.read(cData, sizeof(cData)))
						> 0)
				{
					cData[ilen] = 0x00;
					QString str = m_pTE->toPlainText()
							+ QString(cData);
					m_pTE->setText(
							trUtf8(
									str.toStdString().c_str()));
				}
				f.close();
			}
			else
			{
				QMessageBox::warning(this, trUtf8("信息"),
						trUtf8("帮助文件打开失败！"),
						QMessageBox::Ok);
			}
		}
		else
		{
			QMessageBox::warning(this, trUtf8("信息"),
					trUtf8("帮助文件不存在！"), QMessageBox::Ok);
		}
	}
}
//取消
void QTQHelp::pbCancelClicked()
{
	m_pTE->setReadOnly(true);
	m_pbConfirm->setEnabled(false);
	m_pbModify->setEnabled(true);
	m_pbCancel->setEnabled(false);
}
//保存
void QTQHelp::pbConfirmClicked()
{
	if (m_pTE->toPlainText().length() > 0)
	{
		QFile f(m_strFileName);
		if (f.exists())
		{
			if (f.open(QIODevice::WriteOnly))
			{
				f.resize(0);

				if (f.write(
						m_pTE->toPlainText().toStdString().c_str(),
						m_pTE->toPlainText().length()))
				{
					QMessageBox::warning(this,
							trUtf8("信息"),
							trUtf8("保存成功！"),
							QMessageBox::Ok);
				}
				f.close();
			}
			else
			{
				QMessageBox::warning(this, trUtf8("信息"),
						trUtf8("帮助文件打开失败！"),
						QMessageBox::Ok);
			}
		}
		else
		{
			QMessageBox::warning(this, trUtf8("信息"),
					trUtf8("帮助文件不存在！"), QMessageBox::Ok);
		}
	}
	m_pTE->setReadOnly(true);
	m_pbConfirm->setEnabled(false);
	m_pbModify->setEnabled(true);
	m_pbCancel->setEnabled(false);
}
//修改
void QTQHelp::pbModifyClicked()
{
	m_pTE->setReadOnly(false);
	m_pbModify->setEnabled(false);
	m_pbConfirm->setEnabled(true);
	m_pbCancel->setEnabled(true);
}
//退出
void QTQHelp::pbQuitClicked()
{
	close();
}
//初始化树
void QTQHelp::initXml(QString xml, QString name)
{
	m_pTW->clear();
	QFile xmlFile(xml);
	if (!xmlFile.exists() || (xmlFile.error() != QFile::NoError))
	{
		//		qDebug() << "ERROR: Unable to open config file " << xml;
		return;
	}

	QDomDocument xmlDoc;
	xmlDoc.setContent(&xmlFile, true);
	xmlFile.close();
	QDomElement rootElement = xmlDoc.documentElement();
	QDomNodeList
			demoNodes =
					rootElement.firstChildElement("demos").elementsByTagName(
							"example");

	QTreeWidgetItem *item = new QTreeWidgetItem(QStringList(name));
	for (int i = 0; i < demoNodes.size(); i++)
	{
		QDomElement element = demoNodes.item(i).toElement();
		if (element.hasAttribute("filename"))
		{
			QStringList list;
			//			list << trUtf8(element.attribute("name").toStdString().c_str())
			//					<< trUtf8(element.attribute("help").toStdString().c_str());
			list
					<< trUtf8(
							element.attribute(
									"name").toStdString().c_str())
					<< trUtf8(
							element.attribute(
									"help").toStdString().c_str());

			if (m_strExpand.length() > 0 && m_strExpand.compare(
					element.attribute("filename"),
					Qt::CaseSensitive) == 0)
			{
				m_pItem = new QTreeWidgetItem(list, 0);
				m_pItemParent = item;
			}
			item->addChild(new QTreeWidgetItem(list, 0));
		}
	}
	items.append(item);
}
