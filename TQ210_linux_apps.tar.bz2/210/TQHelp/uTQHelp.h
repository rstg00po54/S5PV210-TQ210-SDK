#ifndef UTQHELP_H
#define UTQHELP_H

#include <QtGui/QWidget>

#include <QTreeWidget>
#include <qtextedit.h>
#include <QPushButton>

class QTQHelp : public QWidget
{
    Q_OBJECT

public:
    QTQHelp(QWidget *parent = 0,QString strApp="");
    ~QTQHelp();

private:
    QTreeWidget *m_pTW;
    QTextEdit *m_pTE;

    QPushButton *m_pbConfirm;
    QPushButton *m_pbModify;
    QPushButton *m_pbCancel;
    QPushButton *m_pbQuit;

    QString m_strFileName;//帮助文件名
    QString m_strExpand;//要显示的文件名
    QTreeWidgetItem *m_pItem;
    QTreeWidgetItem *m_pItemParent;
    QList<QTreeWidgetItem *> items;

    void initXml(QString xml,QString name);
public slots:
	void itemClicked(QTreeWidgetItem * item, int);
	void pbQuitClicked();
	void pbConfirmClicked();
	void pbModifyClicked();
	void pbCancelClicked();
};

#endif // UTQHELP_H
