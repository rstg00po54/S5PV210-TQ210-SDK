#include "imagebrowser.h"
#include <QHBoxLayout>
#include <QLabel>
#include <QVBoxLayout>
#include <QScrollArea>
#include <QFileDialog>
#include <QtGlobal>
#include <QApplication>
#include <QDesktopWidget>
#include <QPainter>
#include <QBuffer>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>
#include <errno.h>
#include <signal.h>
#include <QTimer>
#include <QWSInputMethod>
#include "TQInputMethod.h"
#include <iostream>
#include <QRect>

using namespace std;
int fd = -1;

#define WIDTH screen_size.width()/800
#define HEIGHT screen_size.height()/480

ImageBrowser::ImageBrowser(QWidget *parent, bool showInputMethod) :
	QWidget(parent)
{
	this->setWindowTitle(trUtf8("天嵌科技图片浏览器(www.embedsky.com)"));
	QRect screen_size = QApplication::desktop()->screenGeometry();

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	m_iZoom = 1;
	m_iAngle = 0;
	m_strRootDir = "/";
	m_bAutoRotate = false;
	m_bOk = true;

	m_MsgBox.addButton(new QPushButton(trUtf8("确定")), QMessageBox::YesRole);
	m_MsgBox.setWindowTitle(trUtf8("提示"));

	QHBoxLayout *headLayout = new QHBoxLayout;
	QLabel *lbImagePath = new QLabel(trUtf8("图片路径:"), this);
	m_pleImagePath = new QLineEdit("this");
	m_pleImagePath->setReadOnly(true);
	m_pleImagePath->setMinimumWidth(85*WIDTH);

	QLabel *lbWidtht = new QLabel(trUtf8("宽    度："));
	QLabel *lbHeight = new QLabel(trUtf8("高    度："));
	m_pleWidth = new QLineEdit;
	m_pleHeight = new QLineEdit;

	QPixmap pix;

	m_pbHelp = new QPushButton(trUtf8("帮助"), this);
	m_pbHelp->setText("");
	m_pbHelp->setMaximumWidth(85*WIDTH);
	m_pbHelp->setMaximumHeight(42*HEIGHT);
	m_pbHelp->setIconSize(QSize(85*WIDTH, 42*HEIGHT));

	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(85*WIDTH, 42*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));

	QPushButton *pbSelect = new QPushButton(trUtf8(""), this);
	//	pbSelect = new QPushButton(this);
	pbSelect->setText("");
	pbSelect->setFixedSize(85*WIDTH, 42*HEIGHT);
	pbSelect->setIconSize(QSize(85*WIDTH, 42*HEIGHT));
	pix.load("/opt/PDA/app/images/selectFile.png", 0, Qt::AutoColor);
	pix = pix.scaled(85*WIDTH, 42*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	pbSelect->setIcon(QIcon(pix));
#if 0
	QPushButton *pbZoom = new QPushButton(trUtf8("缩放"), this);
	pbZoom->setMaximumWidth(30*WIDTH);
	pbZoom->setText("");
	pbZoom->setFixedSize(85*WIDTH, 42*HEIGHT);
	pbZoom->setIconSize(QSize(85*WIDTH, 42*HEIGHT));
	pix.load("/opt/PDA/app/images/zoom.png", 0, Qt::AutoColor);
	pix = pix.scaled(85*WIDTH, 42*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	pbZoom->setIcon(QIcon(pix));
#endif
//	QPushButton *pbSave = new QPushButton(trUtf8("保存"), this);
//	pbSave->setMaximumWidth(50);
//	pbSave->setText("");
//	pbSave->setFixedSize(85, 42);
//	pbSave->setIconSize(QSize(85, 42));
//	pix.load("/opt/PDA/app/images/save.png", 0, Qt::AutoColor);
//	pix = pix.scaled(85, 42, Qt::IgnoreAspectRatio);//图片大小
//	pbSave->setIcon(QIcon(pix));

//	QPushButton *rotate = new QPushButton(trUtf8("旋转"), this);
//	rotate->setFixedSize(85, 42);
//	rotate->setText("");
//	rotate->setIconSize(QSize(85, 42));
//	pix.load("/opt/PDA/app/images/rotate.png", 0, Qt::AutoColor);
//	pix = pix.scaled(85, 42, Qt::IgnoreAspectRatio);//图片大小
//	rotate->setIcon(QIcon(pix));

	m_pbClose = new QPushButton(trUtf8("退出"), this);
	m_pbClose->setFixedSize(85*WIDTH, 42*HEIGHT);
	m_pbClose->setText("");
	m_pbClose->setIconSize(QSize(85*WIDTH, 42*HEIGHT));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(85*WIDTH, 42*HEIGHT, Qt::IgnoreAspectRatio);//图片大小
	m_pbClose->setIcon(QIcon(pix));

//	m_pRotate = new QComboBox;
//	m_pRotate->addItem("90");
//	m_pRotate->addItem("180");
//	m_pRotate->addItem("270");
//	m_pRotate->addItem(trUtf8("水平倒影"));
//	m_pRotate->addItem(trUtf8("垂直倒影"));

	headLayout->addWidget(lbImagePath);
	headLayout->addWidget(m_pleImagePath, 50);
	headLayout->addWidget(pbSelect);

	QHBoxLayout *secondLayout = new QHBoxLayout;

	/*secondLayout->addWidget(lbWidth);
	secondLayout->addWidget(m_pleWidth);
	secondLayout->addWidget(lbHeight);
	secondLayout->addWidget(m_pleHeight);
	secondLayout->addWidget(pbZoom);
	secondLayout->addWidget(m_pbHelp);
	secondLayout->addWidget(m_pbClose);*/

	//	headLayout->addWidget(pbZoomout);
	//	headLayout->addWidget(pbZoomin);
	/*headLayout->addWidget(m_pRotate);
	headLayout->addWidget(rotate);
	headLayout->addWidget(pbSave);*/

	headLayout->addWidget(m_pbHelp);
	headLayout->addWidget(m_pbClose);

	QVBoxLayout *vLayout = new QVBoxLayout;
	m_plbImage = new QLabel();
	m_plbImage->setAlignment(Qt::AlignCenter);

	m_pScrollArea = new QScrollArea(this);
	//	m_pScrollArea->setGeometry(QRect(0, 30, 270, 210));

	m_pScrollArea->setWidget(m_plbImage);
	//设置滚动条属性
	m_pScrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
	m_pScrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

	//设置背景色，可取QPalette::Dark和 QPalette::Light
	m_pScrollArea->viewport()->setBackgroundRole(QPalette::Light);
	//设置自动填充背景
	m_pScrollArea->viewport()->setAutoFillBackground(true);

	headLayout->setMargin(0);
	secondLayout->setMargin(0);
//	vLayout->setVerticalSpacing(3);
	vLayout->setSpacing(3);
	vLayout->addLayout(headLayout);
	vLayout->addLayout(secondLayout);
	vLayout->addWidget(m_pScrollArea);
	vLayout->setMargin(0);
	setLayout(vLayout);


	connect(pbSelect, SIGNAL(clicked()), this, SLOT(pbSelectClicked()));
//	connect(pbZoom, SIGNAL(clicked()), this, SLOT(pbZoomClicked()));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));
//	connect(rotate, SIGNAL(clicked()), this, SLOT(pbRotateClicked()));
//	connect(pbSave, SIGNAL(clicked()), this, SLOT(pbSaveClicked()));
	connect(m_pbClose, SIGNAL(clicked()), this, SLOT(pbCloseClicked()));
	connect(&m_fileName, SIGNAL(confirmClicked(QString)), this,
			SLOT(getInputFileName(QString)));

	m_pleImagePath->setText("");

	//m_pSensor = new QGravitySensor;
	QTimer::singleShot(1000, this, SLOT(openDevice()));

	if (showInputMethod)
	{
		QWSInputMethod* im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(true);
	}
}

ImageBrowser::~ImageBrowser()
{
	delete m_pScrollArea;
	delete m_pleImagePath;//图片路径
	delete m_pleWidth;//
	delete m_pleHeight;//
	delete m_pbHelp;
}
void ImageBrowser::pbCloseClicked()
{
	close();
}
void ImageBrowser::openDevice()
{
	/*if (!m_pSensor->openDevice())
	{
		QMessageBox warn;
		warn.setWindowTitle(trUtf8("警告"));
		warn.setText(trUtf8("重力传感器未就绪！"));
		warn.setStandardButtons(QMessageBox::Ok);
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
		QIcon icon(pix);
		warn .setWindowIcon(icon);
		warn.exec();
		return;
	}
	m_pSensor->start();
	connect(m_pSensor, SIGNAL(readData(float *)), this, SLOT(readData(float *)));*/

}
void ImageBrowser::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
void ImageBrowser::pbSelectClicked()
{
	QFileDialog fd;
	QRect screen_size = QApplication::desktop()->screenGeometry();
	fd.setWindowTitle(tr("请选择图像"));
//	fd.setGeometry(0, 0, 480*WIDTH, 272*HEIGHT);
	fd.showFullScreen();
	fd.setFilter("ImageFile (*.jpg *.JPG *.JPEG *.jpeg)");//*.bmp *.png *.ico
	fd.setDirectory(m_strRootDir);
	if (fd.exec() == QDialog::Accepted)
	{
		QString strImagePath = fd.selectedFiles()[0];
		if (strImagePath.length() > 0)
		{
			if (strImagePath.length() > 1)
				m_strRootDir = strImagePath.mid(0,
						strImagePath.lastIndexOf('/'));
			m_iAngle = 0;
			m_iZoom = 1;
			QPixmap pm;
			pm.load(strImagePath);
			m_srcPix = pm.copy(0, 0, pm.width(), pm.height());
			m_pleImagePath->setText(strImagePath);
			m_iWidth = pm.width();
			m_iHeight = pm.height();
			m_plbImage->setGeometry(0, 0, m_iWidth, m_iHeight);
			m_plbImage->setPixmap(pm);
			m_pleWidth->setText(QString::number(pm.width()));
			m_pleHeight->setText(QString::number(pm.height()));
		}
	}
}
//缩小
void ImageBrowser::pbZoomClicked()
{
	if (m_pleHeight->text().toInt() <= 0 || m_pleWidth->text().toInt() <= 0)
		return;

	if (m_pleHeight->text().toInt() % 16 != 0 || m_pleWidth->text().toInt()
			% 16 != 0)
	{
		m_MsgBox.setText(trUtf8("宽和高必须为16的倍数!"));
		m_MsgBox.exec();
		return;
	}

	if (m_pleImagePath->text().endsWith(".jpg", Qt::CaseInsensitive)
			|| m_pleImagePath->text().endsWith(".jpeg", Qt::CaseInsensitive))
	{
		int dst_width = (m_pleWidth->text().toInt() / 16) * 16, dst_height =
				(m_pleHeight->text().toInt() / 8) * 8;

		QImage image = m_plbImage->pixmap()->toImage();
		image = image.convertToFormat(QImage::Format_RGB16);
		m_iWidth = image.width();
		m_iHeight = image.height();
		if (m_iWidth < dst_width || m_iHeight < dst_height)
		{
			m_MsgBox.setText(trUtf8("新尺寸不能大于原始尺寸!"));
			m_MsgBox.exec();
			return;
		}
		unsigned char data[m_iWidth * m_iHeight * 3];
		memcpy(data, image.bits(), image.numBytes());
		int len = 0;

		//转码
		/*int convertfd = initConvertFormate();

		convertformate(convertfd, _RGB16, data, m_iWidth, m_iHeight, _RGB16,
				data, dst_width, dst_height);

		closeConvertFormate(convertfd);*/

		QImage dstimage((uchar *) data, dst_width, dst_height,
				QImage::Format_RGB16);
		QPixmap pixmap;
		pixmap = pixmap.fromImage(dstimage);
		m_srcPix = pixmap;
		m_plbImage->setPixmap(pixmap);
		m_plbImage->resize(dst_width, dst_height);
	}
}
void ImageBrowser::setRotateEnabled()
{
	m_bOk = true;
}
//放大
/*void ImageBrowser::pbZoomoutClicked()
 {
 if (m_pleImagePath->text().length() > 0)
 {
 if (m_iWidth > 1000)
 return;
 m_iWidth = m_iWidth * 5 / 4;
 QPixmap pm;
 pm = m_plbImage->pixmap()->copy(0, 0, m_plbImage->pixmap()->width(),
 m_plbImage->pixmap()->height());
 pm = pm.scaled(m_plbImage->pixmap()->width() * 5 / 4,
 m_plbImage->pixmap()->height() * 5 / 4, Qt::KeepAspectRatio,
 Qt::SmoothTransformation);
 m_plbImage->setPixmap(pm);
 }
 }*/
//void ImageBrowser::pbRotateClicked()
//{
	/*if (!m_bOk)
		return;
	m_bOk = false;
	if (m_pleHeight->text().toInt() <= 0 || m_pleWidth->text().toInt() <= 0)
		return;

	if (m_pleHeight->text().toInt() % 16 != 0 || m_pleWidth->text().toInt()
			% 16 != 0)
	{
		m_MsgBox.setText(trUtf8("宽和高必须为16的倍数!"));
		m_MsgBox.exec();
		return;
	}
	int dst_width = (m_pleWidth->text().toInt() / 16) * 16, dst_height =
			(m_pleHeight->text().toInt() / 16) * 16;

	if (m_pleImagePath->text().endsWith(".jpg", Qt::CaseInsensitive)
	 || m_pleImagePath->text().endsWith(".jpeg", Qt::CaseInsensitive))
	if (0)
	{
		//jpeg解码
		int jpegfd = jpeg_init(0);

		if (jpegfd == -1)
		{
			m_MsgBox.setText(trUtf8("JPEG编码初始化失败!"));
			m_MsgBox.exec();
			return;
		}
		int len = 0;
		QImage image = m_plbImage->pixmap()->toImage();
		//		image = image.convertToFormat(QImage::Format_RGB16);
		m_iWidth = image.width();
		m_iHeight = image.height();

		unsigned char data[m_iWidth * m_iHeight * 3];
		int ret = jpeg_decode(jpegfd, image.bits(),
				strlen((char *) image.bits()), data);
		jpeg_close(jpegfd, 0);

		if (ret == -1)
		{
			m_MsgBox.setText(trUtf8("JPEG编码失败!"));
			m_MsgBox.exec();
			return;
		}
		//转码
		int convertfd = initConvertFormate();
		if (convertfd == -1)
		{
			m_MsgBox.setText(trUtf8("转码初始化失败!"));
			m_MsgBox.exec();
			return;
		}
		ret = convertformate(convertfd, _YCBYCR, data, m_iWidth, m_iHeight,
				_RGB16, data, dst_width, dst_height);
		closeConvertFormate(convertfd);
		if (ret != 1)
		{
			m_MsgBox.setText(trUtf8("转码失败!"));
			m_MsgBox.exec();
			return;
		}
		fd = rotate_init(dst_width, dst_height, ROTATOR_RGB565);
		if (m_pRotate->currentIndex() == 0)
		{
			rotate_image(fd, data, data, 90);
			int i = dst_width;
			dst_width = dst_height;
			dst_height = i;
			m_iAngle = 90;
		}
		else if (m_pRotate->currentIndex() == 1)
		{
			rotate_image(fd, data, data, 180);
			m_iAngle = 180;
		}
		else if (m_pRotate->currentIndex() == 2)
		{
			rotate_image(fd, data, data, 270);
			int i = dst_width;
			dst_width = dst_height;
			dst_height = i;
			m_iAngle = 270;
		}
		else if (m_pRotate->currentIndex() == 3)
			rotate_image(fd, data, data, -180);
		else if (m_pRotate->currentIndex() == 4)
			rotate_image(fd, data, data, -270);

		rotate_close(fd);

		m_plbImage->setText("");
		QImage dstimage((uchar *) data, dst_width, dst_height,
				QImage::Format_RGB16);
		QPixmap pixmap;
		pixmap = pixmap.fromImage(dstimage);
		m_plbImage->resize(dst_width, dst_height);
		m_plbImage->setPixmap(pixmap);
		m_pleWidth->setText(QString::number(pixmap.width()));
		m_pleHeight->setText(QString::number(pixmap.height()));
	}
	else
	{
		QImage image = m_srcPix.toImage();//
		image = image.convertToFormat(QImage::Format_RGB16);
		m_iWidth = image.width();
		m_iHeight = image.height();
		fd = rotate_init(m_iWidth, m_iHeight, ROTATOR_RGB565);
		unsigned char dst[m_iWidth * m_iHeight * 4 + 1];
		dst[m_iWidth * m_iHeight * 4 + 1] = 0x00;

		if (m_pRotate->currentIndex() == 0)
		{
			rotate_image(fd, image.bits(), dst, 90);
			dst_width = m_iHeight;
			dst_height = m_iWidth;
		}
		else if (m_pRotate->currentIndex() == 1)
			rotate_image(fd, image.bits(), dst, 180);
		else if (m_pRotate->currentIndex() == 2)
		{
			rotate_image(fd, image.bits(), dst, 270);
			int i = dst_width;
			dst_width = dst_height;
			dst_height = i;
		}
		else if (m_pRotate->currentIndex() == 3)
			rotate_image(fd, image.bits(), dst, -180);
		else if (m_pRotate->currentIndex() == 4)
			rotate_image(fd, image.bits(), dst, -270);

		rotate_close(fd);

		QImage dstimage((uchar *) dst, dst_width, dst_height,
				QImage::Format_RGB16);
		QPixmap pixmap;
		pixmap = pixmap.fromImage(dstimage);
		m_plbImage->setPixmap(pixmap);
		if (!m_bAutoRotate)
		{
			m_srcPix = pixmap.copy(0, 0, pixmap.width(), pixmap.height());
			m_bAutoRotate = true;
		}
		else
		{
			m_srcPix = pixmap;
		}

//		cout<<"************************"<<endl;
//		cout<<"m_iWidth:"<<m_iWidth<<endl;
//		cout<<"m_iHeight:"<<m_iHeight<<endl;
//
//		cout<<"dst_width:"<<dst_width<<endl;
//		cout<<"dst_height:"<<dst_height<<endl;
//		cout<<"************************"<<endl;
		m_plbImage->update();
		m_plbImage->resize(dst_width, dst_height);
		m_pleWidth->setText(QString::number(dst_width));
		m_pleHeight->setText(QString::number(dst_height));
	}
	 QTimer::singleShot(600, this, SLOT(setRotateEnabled()));*/
//}

void ImageBrowser::getInputFileName(QString name)
{
	/*m_fileName.close();
	QFileDialog fd;
	fd.setWindowTitle(tr("请选择保存路径"));
	fd.setGeometry(0, 0, 480, 272);
	fd.setDirectory(m_strRootDir);
	fd.setOptions(QFileDialog::ShowDirsOnly);
	fd.setFileMode(QFileDialog::Directory);
	if (fd.exec() == QDialog::Accepted)
	{
		QString strImagePath = fd.selectedFiles()[0];
		if (strImagePath.length() > 0)
		{
			QImage image = m_plbImage->pixmap()->toImage();
			image = image.convertToFormat(QImage::Format_RGB16);

			//转码,rgb16-yuyv
			int convertfd = initConvertFormate();
			if (convertfd == -1)
			{
				m_MsgBox.setText(trUtf8("转码初始化失败!"));
				m_MsgBox.exec();
				return;
			}
			unsigned char data[image.width() * image.height() * 3];
			memcpy(data, image.bits(), image.numBytes());
			int ret = convertformate(convertfd, _RGB16, data, image.width(),
					image.height(), _YCBYCR, data, (image.width() / 16) * 16,
					(image.height() / 8) * 8);
			closeConvertFormate(convertfd);
			if (ret != 1)
			{
				m_MsgBox.setText(trUtf8("转码失败!"));
				m_MsgBox.exec();
				return;
			}
			//jpeg編碼
			int jpegfd = jpeg_init(1);
			if (jpegfd == -1)
			{
				m_MsgBox.setText(trUtf8("JPEG编码初始化失败!"));
				m_MsgBox.exec();
				return;
			}
			int jpeg_size = 0;
			ret = jpeg_encode(jpegfd, data, (image.width() / 16) * 16,
					(image.height() / 8) * 8, data, &jpeg_size, 85);
			jpeg_close(jpegfd, 1);
			if (ret != 1)
			{
				m_MsgBox.setText(trUtf8("JPEG编码失败!"));
				m_MsgBox.exec();
				return;
			}
			QString imageName = strImagePath + "/" + name;
			if (!imageName.endsWith(".jpeg", Qt::CaseInsensitive)
					&& !imageName.endsWith(".jpg", Qt::CaseInsensitive))
				imageName += ".jpg";
			QFile f(imageName);
			if (f.open(QIODevice::WriteOnly))
			{
				f.write((const char *) data, jpeg_size);
				f.close();
				m_MsgBox.setText(trUtf8("保存完成!"));
				m_MsgBox.exec();
			}
			else
			{
				m_MsgBox.setText(trUtf8("保存失败!"));
				m_MsgBox.exec();
			}
		}
	}*/
}
void ImageBrowser::pbSaveClicked()
{
	/*if (m_pleHeight->text().toInt() <= 0 || m_pleWidth->text().toInt() <= 0)
		return;
	if (m_pleHeight->text().toInt() % 16 != 0 || m_pleWidth->text().toInt()
				% 16 != 0)
	{
		m_MsgBox.setText(trUtf8("宽和高必须为16的倍数!"));
		m_MsgBox.exec();
		return;
	}
	//jpeg编码
	QImage image = m_plbImage->pixmap()->toImage();
	image = image.convertToFormat(QImage::Format_RGB16);

	if (image.width() > 1600 || image.height() > 1600)
	{
		m_MsgBox.setText(trUtf8("图片最大分辨率为1600x1600!"));
		m_MsgBox.exec();
		return;
	}
	m_fileName.showFullScreen();*/
}
void ImageBrowser::readData(float angle[3])
{
	m_bAutoRotate = true;
	if (angle[0] < 40 && angle[1] < 40 && angle[2] < 40 && m_iAngle != 0)//0
	{
		m_iAngle = 0;
		m_plbImage->setPixmap(m_srcPix);
		m_plbImage->resize(m_srcPix.width(), m_srcPix.height());
		m_pleWidth->setText(QString::number(m_srcPix.width()));
		m_pleHeight->setText(QString::number(m_srcPix.height()));
	}
#if 0
	else if (angle[0] > 85 && (angle[2] > 85 || angle[2] < -85) && m_iAngle
			!= 90)//90
	{
		m_pRotate->setCurrentIndex(0);
		pbRotateClicked();
		m_iAngle = 90;
	}
	else if (angle[0] < -85 && (angle[2] > 85 || angle[2] < -85) && m_iAngle
			!= 270)//90
	{
		m_pRotate->setCurrentIndex(2);
		pbRotateClicked();
		m_iAngle = 270;
	}
	else if ((angle[1] > 85 || angle[1] < -85) && (angle[2] > 85 || angle[2]
			< -85) && m_iAngle != 180)//90
	{
		m_pRotate->setCurrentIndex(1);
		pbRotateClicked();
		m_iAngle = 180;
	}
#endif
	m_bAutoRotate = false;
}
