#ifndef IMAGEBROWSER_H
#define IMAGEBROWSER_H

#include <QtGui/QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QPicture>
#include <QLabel>
#include <QPaintEvent>
#include <QScrollArea>
#include <QPicture>
#include <qcombobox.h>
#include <QMessageBox>
#include <QLineEdit>
#include <QProcess>
#include <QScrollArea>
#include "uiInputFileName.h"
//#include "src/threadProc/uGravitySensor.h"

class ImageBrowser: public QWidget
{
Q_OBJECT

public:
	ImageBrowser(QWidget *parent = 0,bool showInputMethod = false);
	~ImageBrowser();

private:
	QLineEdit *m_pleImagePath;//图片路径
	QLineEdit *m_pleWidth;//
	QLineEdit *m_pleHeight;//
	QPushButton *m_pbHelp;
	QPushButton *m_pbClose;
	// QPicture  *m_pImage;
	QLabel *m_plbImage;//图像
	QString m_strRootDir;//打开目录名
//	QComboBox *m_pRotate;//旋转角度
	QMessageBox m_MsgBox;
	QInputFileName m_fileName;
	//QPicture *pic;
	float m_iZoom;//缩小倍数
	int m_iWidth;
	int m_iHeight;
	QProcess process;
	QScrollArea *m_pScrollArea;
//	QGravitySensor *m_pSensor;
	//    void paintEvent ( QPaintEvent * event );
	QPixmap m_srcPix;
	int m_iAngle;//角度
	bool m_bAutoRotate;
	bool m_bOk;
public slots:
	void pbHelpClicked();
	void pbSelectClicked();
	void pbZoomClicked();
	void pbCloseClicked();
//	void pbRotateClicked();
	void pbSaveClicked();
	void getInputFileName(QString);
	void readData(float *);
	void openDevice();
	void setRotateEnabled();
};

#endif // IMAGEBROWSER_H
