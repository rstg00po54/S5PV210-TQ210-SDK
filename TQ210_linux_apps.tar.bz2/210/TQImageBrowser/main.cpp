#include "imagebrowser.h"

#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	QTextCodec *codec = QTextCodec::codecForName("UTF-8");
	QTextCodec::setCodecForLocale(codec);
	QTextCodec::setCodecForCStrings(codec);
	QTextCodec::setCodecForTr(codec);
	bool showMethod = false;
	ImageBrowser * w;
	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "EmbedSky") == 0)
		{
			w = new ImageBrowser(0, true);
			showMethod = true;
			break;
		}
	}
	if (!showMethod)
		w = new ImageBrowser;
	w->showFullScreen();
	return a.exec();
}
