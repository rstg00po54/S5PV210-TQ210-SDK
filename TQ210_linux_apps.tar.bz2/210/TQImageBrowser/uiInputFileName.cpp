#include "uiInputFileName.h"
#include <QLabel>
#include <qlayout.h>
#include <QDateTime>
//#include<iostream>
//using namespace std;
QInputFileName::QInputFileName(QWidget *parent) :
	QWidget(parent)
{
	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);
	setWindowTitle(trUtf8("请输入文件名"));
	setAutoFillBackground(true);
	setGeometry(0, 0, 480, 272);
	QLabel *lb = new QLabel(trUtf8("文件名："));

	m_pLeFileName = new QLineEdit(this);
	m_pLeFileName->setText(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss")+".jpg");

	m_pCancel = new QPushButton(trUtf8("取消"));
	m_pCancel->setIconSize(QSize(60, 32));
	m_pCancel->setText("");

	QPixmap pix;

	pix.load("/opt/PDA/app/images/cancel.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pCancel->setIcon(QIcon(pix));

	m_pConfirm = new QPushButton(trUtf8("确认"));
	m_pConfirm->setText("");
	m_pConfirm->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/confirm.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pConfirm->setIcon(QIcon(pix));

	m_pCancel->setMaximumWidth(60);
	m_pCancel->setMaximumHeight(32);
	m_pConfirm->setMaximumWidth(60);
	m_pConfirm->setMaximumHeight(32);

	QHBoxLayout *nameLayout = new QHBoxLayout;
	nameLayout->addWidget(lb);
	nameLayout->addWidget(m_pLeFileName);

	QHBoxLayout *btnLayout = new QHBoxLayout;
	btnLayout->addWidget(m_pCancel);
	btnLayout->addWidget(m_pConfirm);

	QVBoxLayout *layout = new QVBoxLayout;
	layout->addLayout(nameLayout);
	layout->addLayout(btnLayout);

	setLayout(layout);
	connect(m_pCancel, SIGNAL(clicked()), this, SLOT(pbCancelClicked()));
	connect(m_pConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));
}

QInputFileName::~QInputFileName()
{
	delete m_pCancel;
	delete m_pConfirm;
}

void QInputFileName::pbCancelClicked()
{
	close();
	//	done(-1);
}
void QInputFileName::pbConfirmClicked()
{
	QString str = m_pLeFileName->text();
	str = str.remove(' ');
	str = str.remove('\r');
	str = str.remove('\n');

	emit confirmClicked(str);
	//	pbCancelClicked();
	//	if (str != "")
	//		done(0);
}
QString QInputFileName::getText()
{
	return m_pLeFileName->text();
}
