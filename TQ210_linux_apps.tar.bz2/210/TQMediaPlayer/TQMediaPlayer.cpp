#include <QtGui>

#include "TQMediaPlayer.h"
#include <QVBoxLayout>
#include <QPushButton>
#include <iostream>
#include <qfiledialog.h>

void *dec_handle = NULL;
using namespace std;

long g_iWidth;
long g_iHeight;



TQMediaPlayer::TQMediaPlayer(QWidget * parent) :
	QWidget(parent)
{
	//	setAttribute(Qt::WA_DeleteOnClose);

	m_bFirst = true;
	m_bPause = false;
	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	//	setAttribute(Qt::WA_DeleteOnClose);
	QLabel *logo = new QLabel(trUtf8("天嵌科技视频播放器(www.EmbedSky.com)"));
	logo->setMaximumHeight(15);
	logo->setAlignment(Qt::AlignCenter);

	m_lbImage = new QLabel(trUtf8(""), this);
	//m_lbImage->setFrameShape(QFrame::Box);
	m_lbImage->setFixedSize(430, 320);
	m_lbImage->setAlignment(Qt::AlignCenter);


	QHBoxLayout *hHeadLayout = new QHBoxLayout;
	hHeadLayout->addWidget(m_lbImage);

	renderTarget = new QGroupBox(this);
	renderTarget->setMinimumHeight(200);
	//renderTarget->setMinimumWidth(600);
	renderTarget->setLayout(hHeadLayout);

	//renderTarget->setAttribute(Qt::WA_OpaquePaintEvent);
	//	return;
	mplayerProcess = new QProcess(this);

	connect(mplayerProcess, SIGNAL(started()), this, SLOT(start()));
	connect(
			mplayerProcess,
			SIGNAL(error(QProcess::ProcessError)),
			this,
			SLOT(error(QProcess::ProcessError)));
	connect(mplayerProcess,
			SIGNAL(finished(int, QProcess::ExitStatus)),
			this,
			SLOT(finished(int, QProcess::ExitStatus)));
	connect(mplayerProcess, SIGNAL(readyReadStandardOutput()), this,
			SLOT(readyReadStandardOutput()));
	//	m_Timer = new QTimer(this);
	//error: no match for 'operator<<' in 'std::cout << cmd;
	connect(&m_Timer, SIGNAL(timeout()), this, SLOT(setProgess()));

	m_pProcess = new QTQProcess(mplayerProcess);
	connect(m_pProcess, SIGNAL(fileLength(int)), this,
			SLOT(fileLength(int)));
	setActions();
	QToolBar *bar = new QToolBar;
	bar->setIconSize(QSize(30, 16));


	//	bar->setStyleSheet("background-color: rgb(0, 170, 0);");
	bar->addAction(m_pPlayAction);
	bar->addAction(m_pPauseAction);
	bar->addAction(m_pStopAction);
	bar->addAction(m_pbDirAction);
	bar->addAction(m_pbQuitAction);

	m_pPlayAction->setIcon(QIcon("/opt/PDA/app/images/mediaplay.png"));
	m_pPauseAction->setIcon(QIcon("/opt/PDA/app/images/mediapause.png"));
	m_pStopAction->setIcon(QIcon("/opt/PDA/app/images/mediastop.png"));
	m_pbDirAction->setIcon(QIcon("/opt/PDA/app/images/dir.png"));
	m_pbQuitAction->setIcon(QIcon("/opt/PDA/app/images/quit.png"));

	m_pSlider = new QSlider;
	m_pSlider->setMaximumWidth(60);
	m_pSlider->setOrientation(Qt::Horizontal);
	m_pSlider->setMinimum(1);
	m_pSlider->setMaximum(100);
	m_pSlider->setSingleStep(1);
	m_pSlider->setValue(50);

	m_pProgessSlider = new QSlider;
	//	m_pProgessSlider->setMaximumWidth(100);
	m_pProgessSlider->setOrientation(Qt::Horizontal);
	m_pProgessSlider->setMinimum(0);
	//	m_pProgessSlider->setMaximum(100);
				//获得控件位置坐标
	connect(m_pSlider, SIGNAL(valueChanged(int)), this,
			SLOT(volumeChanged()));
	connect(m_pProgessSlider, SIGNAL(valueChanged(int)), this,
			SLOT(progressChanged(int)));

	palette.setBrush(QPalette::Light, Qt::darkGray);

	QLabel *volumeLabel = new QLabel;
	volumeLabel->setPixmap(QPixmap("/opt/PDA/app/images/volume.png"));

	QHBoxLayout *hLayout = new QHBoxLayout;
	hLayout->addWidget(bar);
	//	hLayout->addStretch();
	hLayout->addWidget(m_pProgessSlider);
	hLayout->addWidget(m_pSlider);
	hLayout->addWidget(volumeLabel);
	volumeLabel->setMaximumHeight(10);

	QVBoxLayout *vLayout = new QVBoxLayout;

	vLayout->addWidget(logo);
	vLayout->addWidget(renderTarget);
	//	vLayout->addLayout(progessLayout);
	vLayout->addLayout(hLayout);
	setLayout(vLayout);

}

TQMediaPlayer::~TQMediaPlayer()
{
	delete renderTarget;
	delete mplayerProcess;
	delete m_pPlayAction;
	delete m_pPauseAction;
	delete m_pStopAction;
	delete m_pbDirAction;
	delete m_pbQuitAction;
	delete m_pSlider;
	delete m_pProgessSlider;
	delete m_pProcess;
}

void TQMediaPlayer::setActions()
{
	m_pPlayAction = new QAction(
			style()->standardIcon(QStyle::SP_MediaPlay),
			trUtf8("播放"), this);
	m_pPlayAction->setShortcut(tr("Crl+P"));
	//	m_pPlayAction->setDisabled(true);

	m_pPauseAction = new QAction(
			style()->standardIcon(QStyle::SP_MediaPause),
			trUtf8("暂停"), this);
	m_pPauseAction->setShortcut(tr("Ctrl+A"));
	m_pPauseAction->setDisabled(true);

	m_pStopAction = new QAction(
			style()->standardIcon(QStyle::SP_MediaStop),
			trUtf8("停止"), this);
	m_pStopAction->setShortcut(tr("Ctrl+S"));
	m_pStopAction->setDisabled(true);

	m_pbDirAction = new QAction(style()->standardIcon(QStyle::SP_DirIcon),
			trUtf8("选择目录"), this);
	m_pbDirAction->setShortcut(tr("Ctrl+O"));
	//	m_pbDirAction->setDisabled(true);

	m_pbQuitAction = new QAction(
			style()->standardIcon(QStyle::SP_DialogCloseButton),
			tr("退出"), this);
	m_pbQuitAction->setShortcut(tr("Ctrl+q"));
	//	m_pbQuitAction->setDisabled(true);

	connect(m_pPlayAction, SIGNAL(triggered()), this, SLOT(play()));
	connect(m_pPauseAction, SIGNAL(triggered()), this, SLOT(pause()));
	connect(m_pStopAction, SIGNAL(triggered()), this, SLOT(stop()));
	connect(m_pbDirAction, SIGNAL(triggered()), this, SLOT(selectFile()));
	connect(m_pbQuitAction, SIGNAL(triggered()), this, SLOT(StopAndClose()));
}
void TQMediaPlayer::play(const QString &fileName)
{
	QStringList args;
	char* output;
	args << tr("-slave");
	args << "-quiet";
	args << "-zoom";
	args << tr("-wid") << QString::number(renderTarget->winId());
	args << fileName;//tr("/home/hdc/视频/02-112009中国香港动作大片风云2 风云2DVD-RMVB国语中字 1024x434高清晰 无水印版.rmvb");

	QRect screen_size = QApplication::desktop()->screenGeometry();

	g_iWidth = screen_size.width();
	g_iHeight = screen_size.height();

	//cout << g_iWidth << endl;
	//cout << g_iHeight << endl;
	//long Real_height = mapToGlobal(p).x();
	p = m_pProgessSlider -> pos();
	long Real_height = p.y();
	long Real_Width = p.x();
	//cout << Real_height << endl;
/*	QString cmd = "mplayer -slave -quiet -framedrop -zoom -movie"\
					+ fileName\
					+ "-wid"\
					+ (renderTarget->winId());
	*/
	QString cmd = "mplayer -slave -quiet -framedrop -zoom -x " + QString::number(g_iWidth) + " -y " + QString::number(Real_height) + " ";
	cmd += fileName;
//+ QString::number(Real_height)\
	//QString cmd = "mplayer -slave -quiet -framedrop -zoom -x 480 -y 233 ";
	//g_iWidth
	//  QString cmd = "mplayer ";

	//	if (fileName.endsWith(".avi", Qt::CaseInsensitive))
	//	{
	//		cmd += " ";
	//	}
	//	else if (fileName.endsWith(".mp3", Qt::CaseInsensitive))g_iWidth
	//	{
	//		cmd = "mplayer -slave -quiet -ao oss ";
	//	}
	//    else
	//        cmd = "mplayer -slave -quiet -framedrop -zoom -x 480 -y 233 ";
	//	else
	//	{
	//		cmd += "-ac mad ";
	//	}



/*
	QByteArray byteArray = cmd.toUtf8();
	const char* cString = byteArray.constData();

	cout << cString << endl;
*/
	mplayerProcess->start(cmd);

	controlCmd("get_time_length\n");
}
void TQMediaPlayer::play()
{
	if (m_bPause)
	{
		controlCmd("pause\n");
		m_Timer.start(1000);
		m_bPause = false;
		m_pPauseAction->setEnabled(true);
		m_pPlayAction->setEnabled(false);
		return;
	}
	if (m_strName.length() > 0)
	{
		play(m_strName);
	}
}
void TQMediaPlayer::stop()
{
	mplayerProcess->terminate();
	m_bPause = false;
	m_pPauseAction->setEnabled(false);
	m_pPlayAction->setEnabled(true);
}
void TQMediaPlayer::pause()
{
	m_pPauseAction->setEnabled(false);
	m_pPlayAction->setEnabled(true);
	controlCmd("pause\n");
	m_bPause = true;
	if (m_Timer.isActive())
	{
		m_Timer.stop();
	}
}
//进度
void TQMediaPlayer::progressChanged(int value)
{
	//cout << value << endl;
	if (value > m_iLastValue + 1 || value < m_iLastValue)
	{
		QString progress;
		progress = QString::number(
				value * 100 / m_pProgessSlider->maximum());
		m_iLastValue = m_pProgessSlider->value();
		controlCmd(("seek " + progress + " 100\n"));
	}

}
//音量
void TQMediaPlayer::volumeChanged()
{
	QString volume = QString::number(m_pSlider->value());
	controlCmd(("volume " + volume + " 1\n"));
}
void TQMediaPlayer::setProgess()
{
	m_pProgessSlider->setValue(m_pProgessSlider->value() + 1);
	m_iLastValue = m_pProgessSlider->value();
}
void TQMediaPlayer::selectFile()
{
	stop();
	QFileDialog *fd = new QFileDialog(this);
	fd->setGeometry(0, 0, 480, 272);
	fd->setWindowTitle(trUtf8("请选择要播放的文件"));
	fd->setDirectory("/");
	//	fd->setFileMode(QFileDialog::Directory);
	fd->setNameFilter("*.wmv *.avi *.mpeg *.mpg *.mp4 *.m4v");
	QString strFilePath = "";
	if (fd->exec() == QDialog::Accepted)
	{
		m_strName = fd->selectedFiles()[0].toUtf8().data();
		m_bPause = false;
	}
	delete fd;
}
void TQMediaPlayer::fileLength(int length)
{
	//	cout << "文件长度：" << length << endl;
	m_pProgessSlider->setMaximum(length);
}
void TQMediaPlayer::controlCmd(const QString &cmd)
{
	mplayerProcess->write(cmd.toLatin1());
}

void TQMediaPlayer::resizeEvent(QResizeEvent * event)
{
	renderTarget->resize(event->size());
}

void TQMediaPlayer::start()
{
	m_pProcess->start();
	m_Timer.start(1000);
	m_pStopAction->setEnabled(true);
	m_pPlayAction->setEnabled(false);
	m_pPauseAction->setEnabled(true);
}

void TQMediaPlayer::error(QProcess::ProcessError error)
{
	stop();
}
void TQMediaPlayer::finished(int exitCode, QProcess::ExitStatus exitStatus)
{
	m_pPlayAction->setEnabled(true);
	m_pStopAction->setEnabled(false);
	m_pPauseAction->setEnabled(false);
	m_Timer.stop();
	m_pProgessSlider->setValue(0);
}

void TQMediaPlayer::readyReadStandardOutput()
{

}
void TQMediaPlayer::slotBackMessage()
{
	/*while (mplayerProcess->canReadLine())
	 {*/
	QString message(mplayerProcess->readLine());
	// message 即为读取的信息，我们可以根据需要取我们要的信息如：
	// 文件总时间为：ANS_LENGTH=23.00
	// 当前时间为：ANS_TIME_POSITION=23.00
	qDebug() << message;
	//}
}

void TQMediaPlayer::StopAndClose()
{
	mplayerProcess->terminate();
	m_bPause = false;
	m_pPauseAction->setEnabled(false);
	m_pPlayAction->setEnabled(true);
	close();
}

