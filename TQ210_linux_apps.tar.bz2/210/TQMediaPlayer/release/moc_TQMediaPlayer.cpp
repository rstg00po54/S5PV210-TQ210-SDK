/****************************************************************************
** Meta object code from reading C++ file 'TQMediaPlayer.h'
**
** Created: Fri Aug 31 11:44:19 2012
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../TQMediaPlayer.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'TQMediaPlayer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TQMediaPlayer[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // slots: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x08,
      22,   14,   14,   14, 0x08,
      30,   14,   14,   14, 0x08,
      37,   14,   14,   14, 0x08,
      50,   14,   14,   14, 0x08,
      88,   68,   14,   14, 0x08,
     129,  123,   14,   14, 0x08,
     159,   14,   14,   14, 0x08,
     167,   14,   14,   14, 0x08,
     193,   14,   14,   14, 0x08,
     209,   14,   14,   14, 0x08,
     225,   14,   14,   14, 0x08,
     246,   14,   14,   14, 0x08,
     259,   14,   14,   14, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_TQMediaPlayer[] = {
    "TQMediaPlayer\0\0play()\0pause()\0stop()\0"
    "selectFile()\0slotBackMessage()\0"
    "exitCode,exitStatus\0"
    "finished(int,QProcess::ExitStatus)\0"
    "error\0error(QProcess::ProcessError)\0"
    "start()\0readyReadStandardOutput()\0"
    "fileLength(int)\0volumeChanged()\0"
    "progressChanged(int)\0setProgess()\0"
    "StopAndClose()\0"
};

const QMetaObject TQMediaPlayer::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_TQMediaPlayer,
      qt_meta_data_TQMediaPlayer, 0 }
};

const QMetaObject *TQMediaPlayer::metaObject() const
{
    return &staticMetaObject;
}

void *TQMediaPlayer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TQMediaPlayer))
        return static_cast<void*>(const_cast< TQMediaPlayer*>(this));
    return QWidget::qt_metacast(_clname);
}

int TQMediaPlayer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: play(); break;
        case 1: pause(); break;
        case 2: stop(); break;
        case 3: selectFile(); break;
        case 4: slotBackMessage(); break;
        case 5: finished((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QProcess::ExitStatus(*)>(_a[2]))); break;
        case 6: error((*reinterpret_cast< QProcess::ProcessError(*)>(_a[1]))); break;
        case 7: start(); break;
        case 8: readyReadStandardOutput(); break;
        case 9: fileLength((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: volumeChanged(); break;
        case 11: progressChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: setProgess(); break;
        case 13: StopAndClose(); break;
        default: ;
        }
        _id -= 14;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
