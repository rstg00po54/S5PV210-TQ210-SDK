/****************************************************************************
** Meta object code from reading C++ file 'tqmp3player.h'
**
** Created: Fri Aug 31 16:10:51 2012
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../tqmp3player.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tqmp3player.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_TQMp3Player[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x08,
      20,   12,   12,   12, 0x08,
      28,   12,   12,   12, 0x08,
      35,   12,   12,   12, 0x08,
      48,   12,   12,   12, 0x08,
      61,   12,   12,   12, 0x08,
      79,   12,   12,   12, 0x08,
      95,   12,   12,   12, 0x08,
     136,  116,   12,   12, 0x08,
     177,  171,   12,   12, 0x08,
     207,   12,   12,   12, 0x08,
     215,   12,   12,   12, 0x08,
     241,   12,   12,   12, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_TQMp3Player[] = {
    "TQMp3Player\0\0play()\0pause()\0stop()\0"
    "selectFile()\0setProgess()\0setMp3Length(int)\0"
    "volumeChanged()\0progressChanged(int)\0"
    "exitCode,exitStatus\0"
    "finished(int,QProcess::ExitStatus)\0"
    "error\0error(QProcess::ProcessError)\0"
    "start()\0readyReadStandardOutput()\0"
    "pbCloseClicked()\0"
};

const QMetaObject TQMp3Player::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_TQMp3Player,
      qt_meta_data_TQMp3Player, 0 }
};

const QMetaObject *TQMp3Player::metaObject() const
{
    return &staticMetaObject;
}

void *TQMp3Player::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_TQMp3Player))
        return static_cast<void*>(const_cast< TQMp3Player*>(this));
    return QWidget::qt_metacast(_clname);
}

int TQMp3Player::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: play(); break;
        case 1: pause(); break;
        case 2: stop(); break;
        case 3: selectFile(); break;
        case 4: setProgess(); break;
        case 5: setMp3Length((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: volumeChanged(); break;
        case 7: progressChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: finished((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QProcess::ExitStatus(*)>(_a[2]))); break;
        case 9: error((*reinterpret_cast< QProcess::ProcessError(*)>(_a[1]))); break;
        case 10: start(); break;
        case 11: readyReadStandardOutput(); break;
        case 12: pbCloseClicked(); break;
        default: ;
        }
        _id -= 13;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
