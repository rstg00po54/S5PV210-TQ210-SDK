#ifndef TQMP3PLAYER_H
#define TQMP3PLAYER_H

#include <QtGui/QWidget>
#include <QTableWidget>
#include <QAction>
#include <QPushButton>
#include <QSlider>
#include <QTimer>
#include <QLCDNumber>
#include "src/ThreadProc/uTQProcess.h"
class TQMp3Player: public QWidget
{
Q_OBJECT

public:
	TQMp3Player(QWidget *parent = 0);
	~TQMp3Player();
private:
	QTableWidget *m_pMp3Table;
	QAction *m_pPlayAction;//播放
	QAction *m_pPauseAction;//暂停
	QAction *m_pStopAction;//停止
	QAction *m_pbDirAction;//添加文件
	QAction *m_pbQuitAction;//退出

	QSlider *m_pSlider;//声音
	QSlider *m_pProgessSlider;
	QLCDNumber *m_pLcd;
	QTimer m_Timer;
	QProcess *mplayerProcess;
	QTQProcess *m_pProcess;
	bool m_bPause;
	int m_iRowCount;
	int m_iLastValue;//
	void setActions();
	void sendCmd(QString);
	void getMp3File(QString dir);
private slots:
	void play();
	void pause();
	void stop();
	void selectFile();
	void setProgess();
	void setMp3Length(int);
	void volumeChanged();
	void progressChanged(int);
	void finished(int exitCode, QProcess::ExitStatus exitStatus);
	void error(QProcess::ProcessError error);
	void start();
	void readyReadStandardOutput();
	void pbCloseClicked();
};
void *readPipe(void *);
//extern int g_iFileLength;//文件长度
//extern int m_iFd;//
extern TQMp3Player *g_pPlayer;
#endif // TQMP3PLAYER_H
