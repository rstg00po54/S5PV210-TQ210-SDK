#include "tqwifi.h"

#include <QtGui>
#include <QApplication>
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
//	QTranslator translator(0);
//	translator.load("qt_zh_CN.qm");
	QApplication a(argc, argv);
	QTextCodec *codec = QTextCodec::codecForName("UTF-8");
	QTextCodec::setCodecForLocale(codec);
	QTextCodec::setCodecForCStrings(codec);
	QTextCodec::setCodecForTr(codec);
//	a.installTranslator(&translator);
	bool bShowKey = false;
	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "EmbedSky") == 0)
		{
			g_pWiFi = new TQWiFi(0, 1);
			bShowKey = true;
			break;
		}
	}
	if (!bShowKey)
		g_pWiFi = new TQWiFi(0, 0);
	g_pWiFi->showFullScreen();

	return a.exec();
}
