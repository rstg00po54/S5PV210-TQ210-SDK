#include "tqwifi.h"
#include "uiWiFiList.h"
#include <QTabWidget>
#include "uiNetConfigure.h"
#include "u3GModule.h"
#include<QFile>
//#include<iostream>
#include<QVBoxLayout>
#include<QHBoxLayout>

//using namespace std;
QString g_strIP;
QString g_strGateWay;
QString g_strNetMask;

TQWiFi *g_pWiFi;
TQWiFi::TQWiFi(QWidget *parent, bool bKeyShow) :
	QWidget(parent)
{
	ui.setupUi(this);

//	setAttribute(Qt::WA_DeleteOnClose);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	QLabel *labelTitle = new QLabel(trUtf8("天嵌科技网络配置程序"), this);
	labelTitle->setAlignment(Qt::AlignCenter);

	tabWidget = new QTabWidget(this);
	//tabWidget->setGeometry(0, 0, 480, 272);
	if (bKeyShow)
		tabWidget->addTab(new QNetConfigure(0,1), trUtf8("IP"));
	else
		tabWidget->addTab(new QNetConfigure, trUtf8("IP"));

	tabWidget->addTab(new Q3GModule, trUtf8("3G"));
	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addWidget(labelTitle);
	mainLayout->addWidget(tabWidget);
	mainLayout->setMargin(1);
	this->setLayout(mainLayout);
	show();
}

TQWiFi::~TQWiFi()
{
	delete tabWidget;
}

