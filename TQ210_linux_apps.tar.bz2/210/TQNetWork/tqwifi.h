#ifndef TQWIFI_H
#define TQWIFI_H

#include <QtGui/QWidget>
#include "ui_tqwifi.h"

class TQWiFi : public QWidget
{
    Q_OBJECT

public:
    TQWiFi(QWidget *parent = 0,bool bKeyShow=0);
    ~TQWiFi();
    QTabWidget *tabWidget;

private:
    Ui::TQWiFiClass ui;

};
extern TQWiFi *g_pWiFi;
extern QString g_strIP;
extern QString g_strGateWay;
extern QString g_strNetMask;
#endif // TQWIFI_H
