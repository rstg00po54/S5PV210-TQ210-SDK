/*
 * u3GModule.cpp
 *
 *  Created on: 2012-7-12
 *      Author: lkp
 */

#include "u3GModule.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <stdlib.h>
#include <QMessageBox>
#include <unistd.h>

#include <iostream>
using namespace std;
QString DefaultVendor[] =
{ "05c6", "12d1", "1410", "19d2", "15eb" };

QString DefaultProduct[] =
{ "0003", "0026", "0053", "0083", "0103", "1000", "1001", "1003", "101e",
		"2000", "1446", "14c1", "1520", "1521", "1523", "5010", "5020", "5030",
		"5031", "f000" };

QString TargetVendor[] =
{ "", "ff", "04e8", "05c6", "0af0", "12d1", "1410", "19d2", "1520", "1521",
		"1523", "15eb", "16d5", "1fe7", "fff5", "fff6", "ffff" };

QString TargetProduct[] =
{ "", "0001", "0031", "0094", "0100", "0124", "0031", "0037", "0052", "0063",
		"0108", "1001", "1003", "1001", "1406", "140c", "1412", "1464", "1465",
		"1491", "14ac", "14c6", "7152", "2001", "4100", "4400", "6000", "6002",
		"6600", "6601", "6701", "6889", "6901", "9000", "fff1", "fffe", "ffeb",
		"ffff" };
Q3GModule::Q3GModule(QWidget *parent) :
	QWidget(parent)
{
	m_pTimer = new QTimer;
	m_pDialTimer = new QTimer;
	m_pFile = new QFile;
	//system("rm -rf /tmp/3g.txt");
	m_pFile->setFileName("/tmp/3g.txt");
	if (!m_pFile->open(QIODevice::ReadWrite))
	{
		//		QMessageBox::warning(this, trUtf8("警告"), trUtf8("创建临时文件失败！"),
		//				QMessageBox::Ok);
		//ui.pbStart->setEnabled(false);
	}

	m_lbType = new QLabel(trUtf8("3G模块类型"));
	m_cbCDMA = new QRadioButton(trUtf8("CDMA"), this);
	m_cbWCDMA = new QRadioButton(trUtf8("WCDMA"), this);
	m_cbCDMA->setChecked(true);
	m_gbType = new QGroupBox();

	m_lbDefaultVendor = new QLabel(trUtf8("默认制造商ID:"));
	m_lbDefaultProduct = new QLabel(trUtf8("默认产品ID:"));
	m_lbTargetVendor = new QLabel(trUtf8("产品制造商ID:"));
	m_lbTargetProduct = new QLabel(trUtf8("产品ID:"));

	m_cbDefaultVendor = new QComboBox();
	m_cbDefaultProduct = new QComboBox();
	m_cbTargetVendor = new QComboBox();
	m_cbTargetProduct = new QComboBox();

	for (int i = 0; i < sizeof(DefaultVendor) / sizeof(QString); i++)
		m_cbDefaultVendor->addItem(DefaultVendor[i]);

	for (int i = 0; i < sizeof(DefaultProduct) / sizeof(QString); i++)
		m_cbDefaultProduct->addItem(DefaultProduct[i]);

	for (int i = 0; i < sizeof(TargetVendor) / sizeof(QString); i++)
		m_cbTargetVendor->addItem(TargetVendor[i]);

	for (int i = 0; i < sizeof(TargetProduct) / sizeof(QString); i++)
		m_cbTargetProduct->addItem(TargetProduct[i]);

	QHBoxLayout *typeHLayout = new QHBoxLayout();
	typeHLayout->addWidget(m_lbType);
	typeHLayout->addWidget(m_cbCDMA);
	typeHLayout->addWidget(m_cbWCDMA);

	QHBoxLayout *dvHLayout = new QHBoxLayout();
	dvHLayout->addStretch(0);
	dvHLayout->addWidget(m_lbDefaultVendor);
	dvHLayout->addWidget(m_cbDefaultVendor);
	dvHLayout->addStretch(0);
	//QHBoxLayout *dpHLayout = new QHBoxLayout();
	dvHLayout->addWidget(m_lbDefaultProduct);
	dvHLayout->addWidget(m_cbDefaultProduct);
	dvHLayout->addStretch(0);

	QHBoxLayout *tvHLayout = new QHBoxLayout();
	tvHLayout->addStretch(0);
	tvHLayout->addWidget(m_lbTargetVendor);
	tvHLayout->addWidget(m_cbTargetVendor);
	tvHLayout->addStretch(0);
	//QHBoxLayout *tpHLayout = new QHBoxLayout();
	tvHLayout->addWidget(m_lbTargetProduct);
	tvHLayout->addWidget(m_cbTargetProduct);
	tvHLayout->addStretch(0);

	m_pMsg = new QTextEdit();
	m_pMsg->setReadOnly(true);

	m_pConfirm = new QPushButton(trUtf8("拨号"));
	m_pConfirm->setMaximumWidth(100);

	m_pCancel = new QPushButton(trUtf8("断开"));
	m_pCancel->setMaximumWidth(100);

	QHBoxLayout *btnHLayout = new QHBoxLayout();
	btnHLayout->addWidget(m_pCancel);
	btnHLayout->addWidget(m_pConfirm);

	QVBoxLayout *vLayout = new QVBoxLayout();

	vLayout->addLayout(typeHLayout);
	vLayout->addLayout(dvHLayout);
	//vLayout->addLayout(dpHLayout);

	vLayout->addLayout(tvHLayout);
	//vLayout->addLayout(tpHLayout);

	vLayout->addWidget(m_pMsg);
	vLayout->addLayout(btnHLayout);
	vLayout->setMargin(0);
	setLayout(vLayout);

	connect(m_pTimer, SIGNAL(timeout()), this, SLOT(readFile()));
	connect(m_pDialTimer, SIGNAL(timeout()), this, SLOT(isSwitchSuccess()));

	connect(m_pCancel, SIGNAL(clicked()), this, SLOT(pbCancelClicked()));
	connect(m_pConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));
}

Q3GModule::~Q3GModule()
{
	m_pFile->close();
	delete m_pFile;
	m_pTimer->stop();
	delete m_pTimer;
	m_pDialTimer->stop();
	delete m_pDialTimer;
}
void Q3GModule::pbConfirmClicked()
{
	QString type = "/etc/usb-configures/" + m_cbDefaultVendor->currentText()
			+ "." + m_cbDefaultProduct->currentText() + ".";
	type += m_cbTargetVendor->currentText() + "."
			+ m_cbTargetProduct->currentText();

	while (type.endsWith('.'))
		type = type.mid(0, type.length() - 1);
	if (access("/dev/ttyUSB0", 0) != 0)
	{
		if (access(type.toStdString().c_str(), 2) != 0)//配置文件是否存在
		{
			QMessageBox::warning(this, trUtf8("信息"), trUtf8("无此设备信息！"));
			return;
		}
		else
		{
			type = "usb_modeswitch  -Q -c " + type;
			system(type.toStdString().c_str());
		}
	}
	m_iWaitCount = 0;
	m_pDialTimer->start(1000);

}
void Q3GModule::pbCancelClicked()
{
	system("killall pppd");
}
void Q3GModule::readFile()
{
	m_iReadLen = m_pFile->readLine(cData, sizeof(cData));
	if (m_iReadLen > 0)
	{
		m_pMsg->setPlainText(
				m_pMsg->toPlainText() + QString(cData).mid(0, m_iReadLen));
		QTextCursor cursor = m_pMsg->textCursor();
		cursor.movePosition(QTextCursor::End);
		m_pMsg->setTextCursor(cursor);
	}
}
void Q3GModule::isSwitchSuccess()
{
	//cout << "isSwitchSuccess_in" <<endl;
	m_iWaitCount++;
	if (access("/dev/ttyUSB0", 0) == 0)//文件是否存在
	{
		m_pDialTimer->stop();
		QString cmd = "pppd call ";
		if (m_cbCDMA->isChecked())
			cmd += "cdma2000 ";
		else
			cmd += "wcdma ";

		cmd += ">> /tmp/3g.txt &";
		m_pTimer->start(10);
		//cout << "isSwitchSuccess_star_10" <<endl;
		system(cmd.toStdString().c_str());
		//cout << "isSwitchSuccess" <<endl;
	}
	else
	{
		if (m_iWaitCount>=10)
		{
			m_pDialTimer->stop();
			QMessageBox::warning(this, trUtf8("信息"), trUtf8("转换设备失败！"));
		}
	}
}
