/*
 * u3GModule.h
 *
 *  Created on: 2012-7-12
 *      Author: lkp
 */

#ifndef U3GMODULE_H_
#define U3GMODULE_H_

#include <QWidget>
#include <QComboBox>
#include <QLineEdit>
#include <QLabel>
#include <QTextEdit>
#include <QPushButton>
#include <QFile>
#include <QTimer>
#include <QRadioButton>
#include <QGroupBox>
#include <sys/types.h>
class Q3GModule:public QWidget
{
	Q_OBJECT
public:
	Q3GModule(QWidget *parent=0);
	virtual ~Q3GModule();
private:
	QLabel *m_lbType;
	QLabel *m_lbDefaultVendor;
	QLabel *m_lbDefaultProduct;
	QLabel *m_lbTargetVendor;
	QLabel *m_lbTargetProduct;

	QComboBox *m_cbDefaultVendor;
	QComboBox *m_cbDefaultProduct;
	QComboBox *m_cbTargetVendor;
	QComboBox *m_cbTargetProduct;

	QRadioButton *m_cbCDMA;
	QRadioButton *m_cbWCDMA;

	QTextEdit *m_pMsg;
	QPushButton *m_pConfirm;
	QPushButton *m_pCancel;

	QGroupBox *m_gbType;
	QFile *m_pFile;
    QTimer *m_pTimer;
    QTimer *m_pDialTimer;
    int m_iReadLen;
    char cData[200];
    int m_iWaitCount;
private slots:
	void pbConfirmClicked();
	void pbCancelClicked();
	void readFile();
	void isSwitchSuccess();
};

#endif /* U3GMODULE_H_ */
