#include "uiInputFileName.h"
#include <QLabel>
#include<QGridLayout>
#include<iostream>
using namespace std;
QInputFileName::QInputFileName(QWidget *parent) :
	QWidget(parent, Qt::WindowStaysOnTopHint)
{
	setWindowTitle(trUtf8("安全设置"));
	//	setGeometry(100, 150, 300, 100);

	QLabel *labType = new QLabel(trUtf8("安全类型："), this);
	m_cbType = new QComboBox(this);
	m_cbType->addItem("WEP");
	m_cbType->addItem("WPA-PSK/WPA2-PSK");
	connect(m_cbType, SIGNAL(currentIndexChanged ( int)),
			SLOT(currentIndexChangedSlot(int)));

	QLabel *labSelect = new QLabel(trUtf8("安全选项："), this);
	m_cbSelect = new QComboBox(this);

	m_cbSelect->addItem("OPEN");
	m_cbSelect->addItem("SHARED");

	QLabel *labMethod = new QLabel(trUtf8("密钥格式选择："), this);
	m_cbMethod = new QComboBox(this);
	m_cbMethod->addItem(trUtf8("16进制"));

	QLabel *labKey = new QLabel(trUtf8("密钥："), this);
	m_leKey = new QLineEdit(this);
	m_leKey->setText("1234569870");
	m_leKey->setMaximumWidth(160);

	QLabel *labSaveKey = new QLabel(trUtf8("是否保存密码："), this);
	m_cbSaveKey = new QCheckBox(this);
	m_cbSaveKey->setChecked(1);

	m_pCancel = new QPushButton(trUtf8("取消"));
	m_pConfirm = new QPushButton(trUtf8("确认"));
	m_pCancel->setMaximumWidth(100);
	m_pConfirm->setMaximumWidth(100);

	QGridLayout *gridLayout = new QGridLayout();
	gridLayout->addWidget(labType, 0, 0);
	gridLayout->addWidget(m_cbType, 0, 1);
	gridLayout->addWidget(labSelect, 1, 0);
	gridLayout->addWidget(m_cbSelect, 1, 1);
	gridLayout->addWidget(labMethod, 2, 0);
	gridLayout->addWidget(m_cbMethod, 2, 1);
	gridLayout->addWidget(labKey, 3, 0);
	gridLayout->addWidget(m_leKey, 3, 1);
	gridLayout->addWidget(labSaveKey, 4, 0);
	gridLayout->addWidget(m_cbSaveKey, 4, 1);
	gridLayout->addWidget(m_pConfirm, 5, 0);
	gridLayout->addWidget(m_pCancel, 5, 1);

	setLayout(gridLayout);
	connect(m_pCancel, SIGNAL(clicked()), this, SLOT(pbCancelClicked()));
	connect(m_pConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));
}

QInputFileName::~QInputFileName()
{
	delete m_pCancel;
	delete m_pConfirm;
	delete m_leKey;
	delete m_cbType;
	delete m_cbSelect;
	delete m_cbMethod;
	delete m_cbSaveKey;

}

void QInputFileName::pbCancelClicked()
{
	//		done(-1);
	emit CancelSignal();
	close();

}
void QInputFileName::pbConfirmClicked()
{
	QString str;
	if (m_cbSaveKey->isChecked())
		str = "1";
	else
		str = "0";

	QStringList strList;
	strList << m_cbType->currentText() << m_cbSelect->currentText().remove(
			'-') << m_cbMethod->currentText() << m_leKey->text()
			<< str;

	//	cout<<"strList->"<<strList.at(1).toStdString().c_str()<<endl;

	emit ConfirmSignal(strList);
	//	if (str != "")
	//		done(0);
}
QString QInputFileName::getText()
{
	return m_leKey->text();
}
void QInputFileName::currentIndexChangedSlot(int index)
{
	if (index)
	{
		m_cbSelect->clear();

		m_cbSelect->addItem("WPA-PSK");
		m_cbSelect->addItem("WPA2-PSK");

		m_cbMethod->clear();

		m_cbMethod->addItem("TKIP");
		m_cbMethod->addItem("AES");
	}
	else
	{
		m_cbSelect->clear();

		m_cbSelect->addItem("OPEN");
		m_cbSelect->addItem("SHARED");

		m_cbMethod->clear();

		m_cbMethod->addItem(trUtf8("16进制"));

	}

}
