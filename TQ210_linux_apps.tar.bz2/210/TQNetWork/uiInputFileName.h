#ifndef UIINPUTFILENAME_H
#define UIINPUTFILENAME_H

#include <QtGui/QDialog>
#include <QLineEdit>
#include <QPushButton>
#include<QComboBox>
#include<QCheckBox>
#include<QStringList>

class QInputFileName: public QWidget
{
Q_OBJECT

public:
	QInputFileName(QWidget *parent = 0);
	~QInputFileName();
	QString getText();
	QLineEdit *m_leKey;
private:
	QComboBox *m_cbType;
	QComboBox *m_cbSelect;
	QComboBox *m_cbMethod;
	QCheckBox *m_cbSaveKey;

	QPushButton *m_pCancel;
	QPushButton *m_pConfirm;

signals:
	void ConfirmSignal(QStringList);
	void CancelSignal();

public slots:
	void pbCancelClicked();
	void pbConfirmClicked();
	void currentIndexChangedSlot(int);

};
#endif // UIINPUTFILENAME_H
