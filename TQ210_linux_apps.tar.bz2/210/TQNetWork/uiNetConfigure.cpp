#include "uiNetConfigure.h"
#include <QFile>
#include <QMessageBox>
#include "tqwifi.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <iostream>
using namespace std;

QNetConfigure::QNetConfigure(QWidget *parent, bool bShowKey) :
	QWidget(parent) {
	ui.setupUi(this);

	//	setAttribute(Qt::WA_DeleteOnClose);

	m_pTimer = new QTimer;

	m_leIp = new QLineEdit(this);
	m_leMac = new QLineEdit(this);
	m_leGateWay = new QLineEdit(this);
	m_leNetMask = new QLineEdit(this);
	m_leDns1 = new QLineEdit(this);
	m_leDns2 = new QLineEdit(this);

	ui.pbKey->setFixedSize(82, 32);
	ui.pbKey->setIconSize(QSize(82, 32));
	QPixmap pix("/opt/PDA/app/images/key.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbKey->setIcon(QIcon(pix));

	ui.pbClose->setFixedSize(82, 32);
	ui.pbClose->setIconSize(QSize(82, 32));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbClose->setIcon(QIcon(pix));

	ui.pbConfirm->setFixedSize(82, 32);
	ui.pbConfirm->setIconSize(QSize(82, 32));
	pix.load("/opt/PDA/app/images/confirm.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbConfirm->setIcon(QIcon(pix));

	ui.pbRead->setFixedSize(82, 32);
	ui.pbRead->setIconSize(QSize(82, 32));
	pix.load("/opt/PDA/app/images/read.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbRead->setIcon(QIcon(pix));

	ui.pbHelp->setFixedSize(82, 32);
	ui.pbHelp->setIconSize(QSize(82, 32));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbHelp->setIcon(QIcon(pix));

	connect(ui.pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));
	connect(ui.pbClose, SIGNAL(clicked()), this, SLOT(pbCloseClicked()));
	connect(ui.pbConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));
	connect(ui.pbRead, SIGNAL(clicked()), this, SLOT(pbReadClicked()));
	connect(ui.cbDhcp, SIGNAL(stateChanged(int )), this,
			SLOT(cbDhcpClicked()));
	connect(m_pTimer, SIGNAL(timeout()), this, SLOT(dhcpTimeOut()));
	connect(ui.cbWifi, SIGNAL(stateChanged(int)), this,
			SLOT(chWifiStateChanged()));


	QHBoxLayout *titleLayout = new QHBoxLayout();
	QVBoxLayout *lbLayout = new QVBoxLayout();
	QVBoxLayout *leLayout = new QVBoxLayout();
	QVBoxLayout *btnLayout = new QVBoxLayout();

	titleLayout->addWidget(ui.lbNetType);
	titleLayout->addWidget(ui.cbDhcp);
	titleLayout->addWidget(ui.cbWifi);

	lbLayout->addWidget(ui.lbIp);
	lbLayout->addWidget(ui.lbMac);
	lbLayout->addWidget(ui.lbGw);
	lbLayout->addWidget(ui.lbNetMask);
	lbLayout->addWidget(ui.lbDns1);
	lbLayout->addWidget(ui.lbDns2);

	leLayout->addWidget(m_leIp);
	leLayout->addWidget(m_leMac);
	leLayout->addWidget(m_leGateWay);
	leLayout->addWidget(m_leNetMask);
	leLayout->addWidget(m_leDns1);
	leLayout->addWidget(m_leDns2);

	btnLayout->addWidget(ui.pbKey);
	btnLayout->addWidget(ui.pbConfirm);
	btnLayout->addWidget(ui.pbRead);
	btnLayout->addWidget(ui.pbHelp);
	btnLayout->addWidget(ui.pbClose);


	QHBoxLayout *llLayout = new QHBoxLayout();
	llLayout->addLayout(lbLayout);
	llLayout->addLayout(leLayout);


	QVBoxLayout *vLayout = new QVBoxLayout();
	vLayout->addLayout(titleLayout);
	vLayout->addLayout(llLayout);
//	vLayout->addLayout(btnLayout);

	QHBoxLayout *hLayout = new QHBoxLayout();

	hLayout->addLayout(vLayout);
	hLayout->addLayout(btnLayout);
	setLayout(hLayout);
/*
	QFile f("/etc/nettype.conf");
	if (f.exists()) {
		if (f.open(QIODevice::ReadWrite)) {
			f.resize(0);
			QString str = "CDMAUSE=0\nNETTYPE=2\n";
			//				cout << "write to" << endl;
			if (f.write(str.toLocal8Bit().data())) {
				f.close();
			}
		}
	}
*/
	getIp();
	ui.pbKey->setEnabled(0);
	if (bShowKey) {

		ui.pbKey->setEnabled(1);
		connect(ui.pbKey, SIGNAL(clicked()), this, SLOT(pbKeyShowHide()));
		im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(false);

	}
}

QNetConfigure::~QNetConfigure() {
	delete m_pTimer;
	delete m_leIp;
	delete m_leMac;
	delete m_leGateWay;
	delete m_leNetMask;
	delete m_leDns1;
	delete m_leDns2;
}
void QNetConfigure::pbKeyShowHide() {
#ifdef ARM
	((TQInputMethod *) im)->setVisible(true);
#endif
}
void QNetConfigure::chWifiStateChanged() {
	if (ui.cbWifi->isChecked()) {
		g_pWiFi->tabWidget->addTab(new QWiFiList, trUtf8("WiFi"));
		g_pWiFi->tabWidget->setCurrentIndex(2);
	} else {
		g_pWiFi->tabWidget->removeTab(2);
	}
}
void QNetConfigure::pbCloseClicked() {
	g_pWiFi->close();
}
void QNetConfigure::pbReadClicked() {
	getIp();
}
void QNetConfigure::cbDhcpClicked() {
	if (ui.cbDhcp->isChecked()) {
		m_pTimer->start(1000 * 10);
		setCursor(Qt::WaitCursor);
		system("udhcpc -b -i eth0");
	} else {
		getIp();
	}
}
void QNetConfigure::dhcpTimeOut() {
	m_pTimer->stop();
	setCursor(Qt::ArrowCursor);
	getIp();
	system("killall udhcpc &");
}
//输入合法性判断
bool QNetConfigure::isInputValidate() {
	//IP地址判断
	QString str = m_leIp->text();
	if (str.length() > 0) {
		if (!isIpValidate(str)) {
			QMessageBox::information(this, trUtf8("信息"), trUtf8("IP地址非法"),
					QMessageBox::Ok);
			return false;
		}
	} else {
		QMessageBox::information(this, trUtf8("信息"), trUtf8("请输入IP地址"),
				QMessageBox::Ok);
		return false;
	}
	//MAC地址判断
	str = m_leMac->text();
	if (str.length() > 0) {
		if (!isMacValidate(str)) {
			QMessageBox::information(this, trUtf8("信息"), trUtf8("MAC地址非法"),
					QMessageBox::Ok);
			return false;
		}
	} else {
		QMessageBox::information(this, trUtf8("信息"), trUtf8("请输入MAC地址"),
				QMessageBox::Ok);
		return false;
	}
	//网关
	str = m_leGateWay->text();
	if (str.length() > 0) {
		if (!isIpValidate(str)) {
			QMessageBox::information(this, trUtf8("信息"), trUtf8("网关非法"),
					QMessageBox::Ok);
			return false;
		}
	} else {
		QMessageBox::information(this, trUtf8("信息"), trUtf8("请输入网关"),
				QMessageBox::Ok);
		return false;
	}
	//子网掩码
	str = m_leNetMask->text();
	if (str.length() > 0) {
		if (!isIpValidate(str)) {
			QMessageBox::information(this, trUtf8("信息"), trUtf8("子网掩码非法"),
					QMessageBox::Ok);
			return false;
		}
	} else {
		QMessageBox::information(this, trUtf8("信息"), trUtf8("请输入子网掩码"),
				QMessageBox::Ok);
		return false;
	}
	//DNS1
	str = m_leDns1->text();
	if (str.length() > 0) {
		if (!isIpValidate(str)) {
			QMessageBox::information(this, trUtf8("信息"), trUtf8("DNS1非法"),
					QMessageBox::Ok);
			return false;
		}
	} else {
		QMessageBox::information(this, trUtf8("信息"), trUtf8("请输入DNS1"),
				QMessageBox::Ok);
		return false;
	}
	//子网掩码
	str = m_leDns2->text();
	if (str.length() > 0) {
		if (!isIpValidate(str)) {
			QMessageBox::information(this, trUtf8("信息"), trUtf8("DNS2非法"),
					QMessageBox::Ok);
			return false;
		}
	}
	return true;
}
//IP合法性判断
bool QNetConfigure::isIpValidate(QString str) {
	bool bFlag = true;
	//是否包括三个.
	if (str.count(QChar('.'), Qt::CaseInsensitive) == 3) {
		QStringList list = str.split(QChar('.'));
		if (list.count() == 4) {
			for (int i = 0; i < 4; i++) {
				QString str1 = list.at(i);
				if (str1.toInt(NULL, 10) > 255) {
					bFlag = false;
					break;
				}
			}
		} else
			bFlag = false;
	} else
		bFlag = false;
	return bFlag;
}
//MAc合法性判断
bool QNetConfigure::isMacValidate(QString str) {
	bool bFlag = true;
	//是否包括5个:
	if (str.count(QChar(':'), Qt::CaseInsensitive) == 5) {
		QStringList list = str.split(QChar(':'));
		if (list.count() == 6) {
			for (int i = 0; i < 6; i++) {
				QString str1 = list.at(i);
				if (str1.length() == 2) {
					for (int j = 0; j < 2; j++) {
						if (!str1.at(j).isNumber() && (str1.at(j) > 'f'
								|| str1.at(j) < 'a')) {
							bFlag = false;
							break;
						}
					}
				} else
					bFlag = false;
			}
		} else
			bFlag = false;
	} else
		bFlag = false;
	return bFlag;
}
void QNetConfigure::pbConfirmClicked() {
	bool bFlag = true;

	QFile file("/etc/nettype.conf");
	if (file.exists()) {
		if (file.open(QIODevice::ReadWrite)) {
			QString str = "CDMAUSE=0\nNETTYPE=1\n";
			file.write(str.toLocal8Bit().data());
		}
	}
	file.close();
	//保存信息
	if (isInputValidate()) {
		QFile f("/etc/net.conf");
		if (f.open(QIODevice::ReadWrite)) {
			f.resize(0);
			QString str = "IPADDR=" + m_leIp->text() + "\n" + "NETMASK="
					+ m_leNetMask->text() + "\n" + "GATEWAY="
					+ m_leGateWay->text() + "\n" + "MAC=" + m_leMac->text()
					+ "\n";
			if (f.write(str.toStdString().c_str(), str.length())
					!= str.length()) {
				f.close();
				/*uiMyQMessageBox *box = new uiMyQMessageBox(NULL,"数据保存失败！");
				 box->show();
				 pbCancelClicked();*/

				//				cout << f.errorString().toStdString().c_str() << endl;
				bFlag = false;
			}
			f.close();
		} else {
			//			cout << f.errorString().toStdString().c_str() << endl;
			bFlag = false;
		}
	} else
		bFlag = false;
	if (bFlag) {
		QFile f("/etc/resolv.conf");
		if (f.open(QIODevice::ReadWrite)) {
			f.resize(0);
			QString str = "nameserver " + m_leDns1->text() + "\n"
					+ "nameserver " + m_leDns2->text();
			if (f.write(str.toStdString().c_str(), str.length())
					!= str.length()) {
				f.close();

				bFlag = false;
			}
			f.close();
		} else {
			//			cout << f.errorString().toStdString().c_str() << endl;
			bFlag = false;
		}
	}
	if (bFlag) {
		//system("/sbin/net_set &");
/*		QMessageBox::information(this, trUtf8("信息"), trUtf8("设置成功"),
				QMessageBox::Ok);*/
		QMessageBox question;
		question.setWindowTitle(trUtf8("提示"));
		question.setText(trUtf8("设置完成,重启才能生效"));
		question.setInformativeText(trUtf8("是否立即重启？"));

		question.addButton(trUtf8("是"), QMessageBox::YesRole);
		question.addButton(trUtf8("否"), QMessageBox::NoRole);

		question.setDefaultButton(QMessageBox::Yes);
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
		QIcon icon(pix);
		question .setWindowIcon(icon);

		int ret = question.exec();
		switch (ret) {
		case 0: {
			system("sync");
			system("reboot");
		}
			break;
		case 1: {
			setCursor(Qt::ArrowCursor);
			return;
		}
			break;
		default:
			break;
		}

	}
}
void QNetConfigure::getDns() {
	QFile f("/etc/resolv.conf");
	if (f.exists()) {
		if (f.open(QIODevice::ReadOnly)) {
			QString str;
			int iReadLen = 0;
			char cData[200];
			iReadLen = f.readLine(cData, sizeof(cData));
			if (iReadLen > 0) {
				int iIndex = 0;
				str = QString(cData).mid(0, iReadLen);
				str = str.remove('\r');
				str = str.remove('\n');
				iIndex = str.indexOf("NAMESERVER", 0, Qt::CaseInsensitive);
				if (iIndex >= 0) {
					m_leDns1->setText(str.mid(11, str.length() - 11));
				}
				iReadLen = f.readLine(cData, sizeof(cData));
				str = QString(cData).mid(0, iReadLen);
				str = str.remove('\r');
				str = str.remove('\n');
				iIndex = str.indexOf("NAMESERVER", 0, Qt::CaseInsensitive);
				if (iIndex >= 0) {
					m_leDns2->setText(str.mid(11, str.length() - 11));
				}
			}
			f.close();
		}
	}
}
void QNetConfigure::getIp() {
	//	if (m_iConnectType == 1 && ui.cbType->currentIndex() == 1)//有线网络通信
	//	if (1)
	//	{
	QFile f("/etc/net.conf");
	if (f.exists()) {
		if (f.open(QIODevice::ReadOnly)) {
			QString str;
			int iReadLen = 0;
			char cData[200];
			iReadLen = f.readLine(cData, sizeof(cData));
			if (iReadLen > 0) {
				int iIndex = 0;
				str = QString(cData).mid(0, iReadLen);
				str = str.remove('\r');
				str = str.remove('\n');
				iIndex = str.indexOf("IPADDR", 0, Qt::CaseInsensitive);
				if (iIndex >= 0) {
					g_strIP = str.mid(7, str.length() - 7);
					m_leIp->setText(g_strIP);
				}
				iReadLen = f.readLine(cData, sizeof(cData));
				str = QString(cData).mid(0, iReadLen);
				str = str.remove('\r');
				str = str.remove('\n');
				iIndex = str.indexOf("NETMASK", 0, Qt::CaseInsensitive);
				if (iIndex >= 0) {
					g_strNetMask = str.mid(8, str.length() - 8);
					m_leNetMask->setText(g_strNetMask);
				}
				iReadLen = f.readLine(cData, sizeof(cData));
				str = QString(cData).mid(0, iReadLen);
				str = str.remove('\r');
				str = str.remove('\n');
				iIndex = str.indexOf("GATEWAY", 0, Qt::CaseInsensitive);
				if (iIndex >= 0) {
					g_strGateWay = str.mid(8, str.length() - 8);
					m_leGateWay->setText(g_strGateWay);
				}
				iReadLen = f.readLine(cData, sizeof(cData));
				str = QString(cData).mid(0, iReadLen);
				str = str.remove('\r');
				str = str.remove('\n');
				iIndex = str.indexOf("MAC", 0, Qt::CaseInsensitive);
				if (iIndex >= 0) {
					m_leMac->setText(str.mid(4, str.length() - 4));
				}
				getDns();
			}
			f.close();
		}
	}
	//	}
}
void QNetConfigure::pbHelpClicked() {
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
