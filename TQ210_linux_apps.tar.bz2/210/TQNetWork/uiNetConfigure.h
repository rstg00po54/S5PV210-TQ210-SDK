#ifndef UINETCONFIGURE_H
#define UINETCONFIGURE_H

#include <QtGui/QWidget>
#include "ui_uiNetConfigure.h"
#include <QProgressDialog>
#include <QTimer>
#include<QLineEdit>
#include <qprocess.h>
#include "uiWiFiList.h"

#include "TQInputMethod.h"
#ifdef ARM
#include <QWSInputMethod>
#endif

class QNetConfigure: public QWidget
{
Q_OBJECT

public:
	QNetConfigure(QWidget *parent = 0,bool bKeyShow=0);
	~QNetConfigure();

private:
	Ui::QNetConfigureClass ui;
	QProgressDialog m_Progress;
	QTimer *m_pTimer;
	//QMessageBox m_MessageBox;
	void getIp();
	void getDns();
	bool isInputValidate();
	bool isIpValidate(QString str);
	bool isMacValidate(QString str);

	QLineEdit *m_leIp;
	QLineEdit *m_leMac;
	QLineEdit *m_leGateWay;
	QLineEdit *m_leNetMask;
	QLineEdit *m_leDns1;
	QLineEdit *m_leDns2;

	QProcess process;
#ifdef ARM
	QWSInputMethod* im;
#endif
public slots:
	void pbCloseClicked();
	void pbConfirmClicked();
	void pbReadClicked();
	void cbDhcpClicked();
	void dhcpTimeOut();
	void pbHelpClicked();
	void pbKeyShowHide();
	void chWifiStateChanged();

};

#endif // UINETCONFIGURE_H
