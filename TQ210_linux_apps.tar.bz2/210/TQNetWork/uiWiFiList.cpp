#include "uiWiFiList.h"
#include <QFile>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QLabel>
#include <QHeaderView>
#include <QInputDialog>
#include<QSettings>
#include <QDesktopWidget>
#include<QRect>
#include "tqwifi.h"
#include <iostream>
using namespace std;
bool bSetShow, bClickedItem;
QWiFiList::QWiFiList(QWidget *parent) :
	QWidget(parent) {
	bSetShow = true;
	bClickedItem = false;
	//	setAttribute(Qt::WA_DeleteOnClose);
	QRect screen_size = QApplication::desktop()->screenGeometry();

	m_iCurrentRow = 0;

	m_pMessageTimer = new QTimer;
	m_pDhcp = new QTimer;
	m_MessageBox.setGeometry(200, 100, 300, 200);
	m_MessageBox.addButton(new QPushButton(trUtf8("确认")), QMessageBox::YesRole);
	m_ptbWifiInfo = new QTableWidget(this);
	m_ptbWifiInfo->setColumnCount(6);
	m_ptbWifiInfo->setColumnWidth(0, 100);
	m_ptbWifiInfo->setColumnWidth(1, 108);
	m_ptbWifiInfo->setColumnWidth(2, 60);
	m_ptbWifiInfo->setColumnWidth(3, 40);
	m_ptbWifiInfo->setColumnWidth(4, 58);
	m_ptbWifiInfo->setColumnWidth(5, 90);
	m_ptbWifiInfo->setCurrentCell(0, 0);

	m_ifn = new QInputFileName();
	connect(m_ifn, SIGNAL(ConfirmSignal(QStringList)), this,
			SLOT(ifnSlot(QStringList)));
	connect(m_ifn, SIGNAL(CancelSignal()), this, SLOT(ifnSlotCancel()));
	//	m_ifn->move(screen_size.width() / 2 - m_ifn->width() / 2,
	//			screen_size.height() / 2 - m_ifn->height() / 2-40);

	QStringList header;
	header.append(trUtf8("网络名称(SSID)"));
	header.append(trUtf8("BSSID"));
	header.append(trUtf8("信号强度"));
	header.append(trUtf8("信道"));
	//header.append(trUtf8("类型"));
	header.append(trUtf8("数据加密"));
	//	header.append(trUtf8("网络身份验证"));
	header.append(trUtf8("网络模式"));
	m_ptbWifiInfo->setHorizontalHeaderLabels(header);
	m_ptbWifiInfo->setSelectionMode(QAbstractItemView::SingleSelection);
	/*	for (int i = 0; i < iRowCount; i++)
	 {
	 QTableWidgetItem *newItem = new QTableWidgetItem();
	 newItem->setCheckState(Qt::Unchecked);
	 m_ptbWifiInfo->setItem(i, 1, newItem);
	 }*/
	QHeaderView *hv = m_ptbWifiInfo->verticalHeader();
	hv->hide();

	QVBoxLayout *vLayout = new QVBoxLayout;

	QHBoxLayout *connectLayout = new QHBoxLayout;

	QLabel *lb = new QLabel(trUtf8("网络连接方式："));
	m_pcbDhcp = new QCheckBox(trUtf8("动态分配IP"));

	m_pbSet = new QPushButton(this);
	m_pbSet->setFixedSize(82, 32);
	m_pbSet->setIconSize(QSize(82, 32));
	QPixmap pix("/opt/PDA/app/images/setPara.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbSet->setIcon(QIcon(pix));
	connect(m_pbSet, SIGNAL(clicked()), this, SLOT(pbSetClicked()));

	m_pbSearch = new QPushButton(this);
	m_pbSearch->setFixedSize(82, 32);
	m_pbSearch->setIconSize(QSize(82, 32));
	pix.load("/opt/PDA/app/images/searchWeb.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbSearch->setIcon(QIcon(pix));
	connect(m_pbSearch, SIGNAL(clicked()), this, SLOT(pbSearchClicked()));

	m_pbConnect = new QPushButton(this);
	m_pbConnect->setFixedSize(82, 32);
	m_pbConnect->setIconSize(QSize(82, 32));
	pix.load("/opt/PDA/app/images/connect.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbConnect->setIcon(QIcon(pix));

	m_pbStop = new QPushButton(this);
	m_pbStop->setFixedSize(82, 32);
	m_pbStop->setIconSize(QSize(82, 32));
	pix.load("/opt/PDA/app/images/pause.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbStop->setIcon(QIcon(pix));
	connect(m_pbStop, SIGNAL(clicked()), this, SLOT(pbStopClicked()));

	m_pbClose = new QPushButton(this);
	m_pbClose->setFixedSize(82, 32);
	m_pbClose->setIconSize(QSize(82, 32));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbClose->setIcon(QIcon(pix));

	connectLayout->addSpacing(60);
	connectLayout->addWidget(lb);
	connectLayout->addWidget(m_pcbDhcp);
	connectLayout->addSpacing(130);

	QHBoxLayout *hLayout = new QHBoxLayout;
	hLayout->addWidget(m_pbSet);
	hLayout->addWidget(m_pbSearch);
	hLayout->addWidget(m_pbConnect);
	hLayout->addWidget(m_pbStop);
	hLayout->addWidget(m_pbClose);

	vLayout->addWidget(m_ptbWifiInfo);
	vLayout->addLayout(connectLayout);
	vLayout->addLayout(hLayout);
	setLayout(vLayout);

	m_pFile = new QFile;
	m_pFile->setFileName("/tmp/wifi.txt");

	m_pFileName = new QFile;
	m_pFileName->setFileName("/tmp/wifiName.txt");

	connect(m_pbClose, SIGNAL(clicked()), this, SLOT(pbCloseClicked()));
	connect(m_pbConnect, SIGNAL(clicked()), this, SLOT(pbConnectClicked()));
	connect(m_pMessageTimer, SIGNAL(timeout()), this, SLOT(messageTimeout()));
	connect(m_pDhcp, SIGNAL(timeout()), this, SLOT(dhcpTimeout()));
	system("ifconfig wlan0 up");
	system("net_set");


	//	if (system("ping 192.168.1.1 -q -c 1 -W 3 -s 8") == 0)
	//
	//	{
	//		QMessageBox::warning(this, trUtf8("提示"), trUtf8("连接成功"),
	//				QMessageBox::Ok);
	//	}
	//	else
	//	{
	//		QMessageBox::warning(this, trUtf8("提示"), trUtf8("连接失败"),
	//				QMessageBox::Ok);
	//	}
	/*
	 QFile file("/etc/nettype.conf");
	 if (file.exists())
	 {
	 if (file.open(QIODevice::ReadWrite))
	 {
	 QString str = "CDMAUSE=0\nNETTYPE=2\n";
	 file.write(str.toLocal8Bit().data());
	 }
	 }
	 */
	QTimer::singleShot(100, this, SLOT(searchAuto()));
//	searchAuto();
}

QWiFiList::~QWiFiList() {
	m_pFile->close();
	delete m_pFile;
	m_pMessageTimer->stop();
	delete m_pMessageTimer;
	m_pDhcp->stop();
	delete m_pDhcp;
	delete m_ptbWifiInfo;
	delete m_pbConnect;
	delete m_pbClose;
	delete m_pbSearch;
	delete m_pcbDhcp;
}
void QWiFiList::pbSearchClicked() {
	system("net_set");
	searchAuto();
}
void QWiFiList::searchAuto() {
	m_pFileName->resize(0);
	if (system("cat /proc/net/dev >> /tmp/wifiName.txt") == 0)//查询无线网卡名字
	{
		if (m_pFileName->open(QIODevice::ReadOnly)) {
			getWiName();
			m_pFileName->close();
		}
	}
	/*
	 QFile f("/etc/wifi.conf");
	 QString str;
	 if (f.open(QIODevice::ReadWrite))
	 {
	 if (m_strName.compare("wlan0") == 0)
	 str
	 = "NETNAME=EmbedSkyTest\nPASSWORD=123456790\nINTERFACE=wlan0\n";
	 else if (m_strName.compare("ra0") == 0)
	 str
	 = "NETNAME=EmbedSkyTest\nPASSWORD=123456790\nINTERFACE=ra0\n";

	 if (f.write(str.toLocal8Bit().data()))
	 {
	 f.close();
	 }
	 }
	 */
	m_pFile->resize(0);
	QString strCmd = "iwlist " + m_strName + " scanning >> /tmp/wifi.txt";
	cout << strCmd.toStdString().c_str() << endl;
	sleep(2);
	if (system(strCmd.toLocal8Bit().data()) == 0)//查询成功
	{
//		sleep(5);
		if (m_pFile->open(QIODevice::ReadOnly)) {
			getWiFiInfo();
			m_pFile->close();
		}
	}
	else
	{
		QMessageBox::warning(this, trUtf8("提示"), trUtf8("搜索失败"),
						QMessageBox::Ok);
	}

}

void QWiFiList::getWiName() {
	char cData[2048];
	memset(cData, 0x00, sizeof(cData));
	QString str;

	int iReadLen = m_pFileName->read(cData, sizeof(cData));
	str = QString(cData).mid(0, iReadLen);
	str = str.remove('\r');
	str = str.remove('\n');
	int iStart = str.indexOf("ra0", 0, Qt::CaseInsensitive);
	if (iStart > 0) {
		m_strName = "ra0";
				cout << "m_strName->" << m_strName.toStdString().c_str()
						<< endl;
		return;
	}
	iStart = str.indexOf("wlan0", 0, Qt::CaseInsensitive);
	if (iStart > 0) {
		m_strName = "wlan0";
				cout << "m_strName->" << m_strName.toStdString().c_str()
						<< endl;
	}

}
void QWiFiList::messageTimeout() {
	m_pMessageTimer->stop();
	connectToWiFi(m_strSSID, m_strPwd);
}
void QWiFiList::pbSetClicked() {
	m_pbSet->setEnabled(0);
	m_pbSearch->setEnabled(0);
	m_pbConnect->setEnabled(0);
	m_pbClose->setEnabled(0);
	m_pbStop->setEnabled(0);
	m_ifn->show();
}
void QWiFiList::ifnSlot(QStringList strList) {
	m_pbSet->setEnabled(1);
	m_pbSearch->setEnabled(1);
	m_pbConnect->setEnabled(1);
	m_pbStop->setEnabled(1);
	m_pbClose->setEnabled(1);
	if(m_ptbWifiInfo->currentItem()==NULL)
	{
		m_ifn->close();
		return;
	}
	bSetShow = false;
	strListInfo = strList;

	QString str_SSID = m_ptbWifiInfo->currentItem()->text().remove(" ");
	QString str_AuthMode = strList.at(1);
	QString str_EncrypType;
	QString strType;
	m_strPwd = m_ifn->m_leKey->text();
	if (strList.at(4) == "0")
		m_ifn->m_leKey->clear();

	if (strList.at(0).compare("WEP") == 0) {
		str_EncrypType = "WEP";
		strType = "2";
	} else if (strList.at(0).compare("WPA-PSK/WPA2-PSK") == 0) {
		str_EncrypType = strList.at(2);
		strType = "3";
	}
	//strType = "2";
	QFile file("/etc/nettype.conf");
	if (file.exists()) {
		if (file.open(QIODevice::ReadWrite)) {
			QString str = "CDMAUSE=0\nNETTYPE=" + strType + "\n";
			file.write(str.toLocal8Bit().data());
		}
		file.close();
	}

	//	cout << "strList[0]->" << str_SSID.toStdString().c_str() << endl;
	//	cout << "strList[1]->" << str_AuthMode.toStdString().c_str() << endl;
	//	cout << "strList[2]->" << str_EncrypType.toStdString().c_str() << endl;
	//	cout << "strList[3]->" << m_strPwd.toStdString().c_str() << endl;

	QFile fRT("/etc/Wireless/RT3070STA/RT3070STA.dat");
	if (fRT.exists()) {
		if (fRT.open(QIODevice::ReadWrite)) {
			QString str;
			int iReadLen = 0;
			char cData[2048];
			iReadLen = fRT.read(cData, sizeof(cData));
			str = QString(cData).mid(0, iReadLen);
			if (iReadLen > 0) {
				int iStart = str.indexOf("SSID", 0);
				int iEnd = str.indexOf("\n", iStart);
				str.replace(iStart + 5, iEnd - iStart - 5, str_SSID);

				iStart = str.indexOf("AuthMode", 0);
				iEnd = str.indexOf("\n", iStart);
				str.replace(iStart + 9, iEnd - iStart - 9, str_AuthMode);

				iStart = str.indexOf("EncrypType", 0);
				iEnd = str.indexOf("\n", iStart);
				str.replace(iStart + 11, iEnd - iStart - 11, str_EncrypType);

				iStart = str.indexOf("Key1Str", 0);
				iEnd = str.indexOf("\n", iStart);
				str.replace(iStart + 8, iEnd - iStart - 8, m_strPwd);

				fRT.resize(0);
				fRT.write(str.toLocal8Bit().data());
				fRT.close();
			}
		}
	}
	if (strList.at(0).compare("WEP") != 0) {
		QFile fwpa("/etc/wpa_supplicant.conf");
		if (fwpa.exists()) {
			if (fwpa.open(QIODevice::ReadWrite)) {
				QString str;
				int iReadLen = 0;
				char cData[1024];
				iReadLen = fwpa.read(cData, sizeof(cData));
				str = QString(cData).mid(0, iReadLen);
				if (iReadLen > 0) {
					int iStart = str.indexOf("ssid", 0);
					int iEnd = str.indexOf("\n", iStart);
					str.replace(iStart + 6, iEnd - iStart - 6 - 1, str_SSID);

					iStart = str.indexOf("psk", 0);
					iEnd = str.indexOf("\n", iStart);
					str.replace(iStart + 5, iEnd - iStart - 5 - 1, m_strPwd);

					fwpa.resize(0);
					fwpa.write(str.toLocal8Bit().data());
					fwpa.close();
				}
			}
		}
	}

	m_ifn->close();
	//	m_pMessageTimer->start(100);
}
void QWiFiList::ifnSlotCancel() {
	bSetShow = true;
	m_pbSet->setEnabled(1);
	m_pbSearch->setEnabled(1);
	m_pbConnect->setEnabled(1);
	m_pbStop->setEnabled(1);
	m_pbClose->setEnabled(1);
}
void QWiFiList::pbConnectClicked() {
	if (bSetShow) {
		m_pbSet->setEnabled(0);
		m_pbSearch->setEnabled(0);
		m_pbConnect->setEnabled(0);
		m_pbClose->setEnabled(0);
		m_pbStop->setEnabled(0);
		m_ifn->show();
		bSetShow = false;
		return;
	}
	QString str;
	if(m_ptbWifiInfo->currentItem()==NULL)
		return ;

	if (m_strName.compare("wlan0") == 0) {
		str = "NETNAME=" + m_ptbWifiInfo->currentItem()->text().remove(" ")
				+ "\n" + "PASSWORD=" + m_strPwd + "\n" + "INTERFACE=wlan0\n";
	} else if (m_strName.compare("ra0") == 0) {
		str = "NETNAME=" + m_ptbWifiInfo->currentItem()->text().remove(" ")
				+ "\n" + "PASSWORD=" + m_strPwd + "\n" + "INTERFACE=ra0\n";
	}

	QFile f("/etc/wifi.conf");
	if (f.open(QIODevice::ReadWrite)) {
		f.resize(0);
		QString str;
		str = "NETNAME=" + m_ptbWifiInfo->currentItem()->text().remove(" ")
				+ "\n" + "PASSWORD=" + m_strPwd + "\n" + "INTERFACE="
				+ m_strName;

		if (f.write(str.toLocal8Bit().data())) {
			f.close();
		} else {
			f.close();
			QMessageBox::warning(this, trUtf8("提示"),
					trUtf8("对/etc/wifi.conf操作失败，请检查权限"), QMessageBox::Ok);
		}
	}

	m_pMessageTimer->start(100);
}

///连接无线网络
void QWiFiList::connectToWiFi(QString ssid, QString pwd) {
	setCursor(Qt::WaitCursor);
	if(m_ptbWifiInfo->rowCount()<0)
		return ;
	for (int i = 0; i < m_ptbWifiInfo->rowCount(); i++) {
		if (m_ptbWifiInfo->cellWidget(i, 0)) {
			m_ptbWifiInfo->cellWidget(i, 0)->close();
		}
	}
	QString strCmd;
	if (m_pcbDhcp->isChecked()) {
		strCmd = "iwconfig " + m_strName + " essid ";
		strCmd += "\" " + m_ptbWifiInfo->currentItem()->text().remove(" ")
				+ "\" ";
		strCmd += "key \" " + m_strPwd + "\" ";

		cout << "strcmd->" << strCmd.toStdString().c_str() << endl;//guo
		system("net_set");
		system(strCmd.toStdString().c_str());
		//dhcp自动获取IP
		m_pDhcp->start(1000 * 10);
		strCmd = "udhcpc -b -i " + m_strName;

		system(strCmd.toStdString().c_str());
	} else {
		strCmd = "iwconfig " + m_strName + " essid ";
		strCmd += "\"" + m_ptbWifiInfo->currentItem()->text().remove(" ")
				+ "\" ";
		if (pwd != "") {
			strCmd += "key \" " + m_strPwd + "\" ";
		}
		system("ifconfig eth0 down");

		//IP地址
		QString str = "ifconfig " + m_strName + " " + g_strIP + " netmask "
				+ g_strNetMask + " up";
		system(str.toStdString().c_str());

		//网关
		str = "route add default gw " + g_strGateWay;

		system(str.toStdString().c_str());
	}

	QMessageBox question;
	question.setWindowTitle(trUtf8("提示"));
	question.setText(trUtf8("设置完成,重启才能生效"));
	question.setInformativeText(trUtf8("是否立即重启？"));

	question.addButton(trUtf8("是"), QMessageBox::YesRole);
	question.addButton(trUtf8("否"), QMessageBox::NoRole);

	question.setDefaultButton(QMessageBox::Yes);
	QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
	QIcon icon(pix);
	question .setWindowIcon(icon);

	int ret = question.exec();
	switch (ret) {
	case 0: {
		system("sync");
		system("reboot");
	}
		break;
	case 1: {
		setCursor(Qt::ArrowCursor);
		return;
	}
		break;
	default:
		break;
	}

	//reboot
#if 0
	system("net_set");
	if (system(strCmd.toStdString().c_str()) == 0)
	{
		//						if (system("ping www.baidu.com -q -c 1 -W 3 -s 8") == 0)
		//		if (system("ping 192.168.1.1 -q -c 1 -W 3 -s 8 -w 2000") == 0)//guo
		if (system("ping 192.168.1.1 -q -c 1 -W 3 -s 8") == 0)//guo

		{
			QLabel *label = new QLabel;
			label->setPixmap(QPixmap("connect.png"));
			m_ptbWifiInfo->setCellWidget(m_iCurrentRow, 0, label);
			m_MessageBox.setText(trUtf8("连接成功"));
			//break;
		}
		else
		{
			m_MessageBox.setText(trUtf8("连接失败"));
		}

	}
	//}
	setCursor(Qt::ArrowCursor);
#endif
}

void QWiFiList::dhcpTimeout() {
	m_pDhcp->stop();
	setCursor(Qt::ArrowCursor);
	system("killall udhcpc &");
	if (system("ping www.baidu.com -q -c 1 -W 3 -s 8") == 0) {
		QLabel *label = new QLabel;
		label->setPixmap(QPixmap("connect.png"));
		m_ptbWifiInfo->setCellWidget(m_iCurrentRow, 0, label);
		m_MessageBox.setText(trUtf8("连接失败"));
	} else
		m_MessageBox.done(0);
}

void QWiFiList::getWiFiInfo() {
	char cData[4096];
	memset(cData, 0x00, sizeof(cData));
	int iReadLen = 0;
	//int iIndex = 0;
	int iStart, iEnd;
	QString str;
	int iCount = 0;
	while (true) {
		iReadLen = m_pFile->read(cData, sizeof(cData));

		if (iReadLen > 0) {
			iStart = 0;
			str += QString(cData).mid(0, iReadLen);
			str = str.remove('\r');
			str = str.remove('\n');
			cout << "读取到的数据：" << str.toStdString().c_str() << endl;
			//if (str.contains("No scan results", Qt::CaseInsensitive) == 0)
			while (true) {
				//剩余部分
				str = str.mid(iStart, str.length() - iStart);
				iStart = str.indexOf("Cell", 0, Qt::CaseInsensitive);
				if (iStart > 0) {
					iEnd = str.indexOf("Cell", iStart + 1, Qt::CaseInsensitive)
							- 1;
					if (iEnd > 0) {
						QString strCell = str.mid(iStart, iEnd - iStart);
						if (explainWiFiInfo(strCell)) {
							addTabWidgetItem(iCount++);
						}
						iStart = iEnd;
					} else {

						QString strCell = str.mid(iStart, str.length() - iStart);
						if (explainWiFiInfo(strCell)) {
							addTabWidgetItem(iCount++);
						}
						break;
					}
				} else {
					break;
				}
			}
			//cout << "剩余数据：" << str.toStdString().c_str() << endl;

		} else
			break;
	}
}
//解析无线网络信息
bool QWiFiList::explainWiFiInfo(QString str) {
	int iEnd = 0;
	int iIndex = str.indexOf("Address", 0, Qt::CaseInsensitive);
	if (iIndex > 0) {
		m_strMac = str.mid(iIndex + 9, 17);
		//cout << "MAC:" << strMac.toStdString().c_str() << endl;
		//通道
		iIndex = str.indexOf("Channel", 0, Qt::CaseInsensitive);
		if (iIndex > 0) {
			iEnd = str.indexOf(" ", iIndex, Qt::CaseInsensitive);
			m_strChannel = str.mid(iIndex + 8, iEnd - iIndex - 8);
			//cout << "Channel:" << strChannel.toStdString().c_str() << endl;

			//信号强度
			iIndex = str.indexOf("Quality", 0, Qt::CaseInsensitive);
			if (iIndex > 0) {
				iEnd = str.indexOf(" ", iIndex, Qt::CaseInsensitive);
				m_strQuality = str.mid(iIndex + 8, iEnd - iIndex - 8);

				//是否加密
				iIndex = str.indexOf("Encryption key", 0, Qt::CaseInsensitive);
				if (iIndex > 0) {
					iEnd = str.indexOf(" ", iIndex + 15, Qt::CaseInsensitive);
					m_strEncryption = str.mid(iIndex + 15, iEnd - iIndex - 15);
					/*cout << "Encryption key:"
					 << strEncryption.toStdString().c_str() << endl;*/

					//网络标识
					iIndex = str.indexOf("ESSID", 0, Qt::CaseInsensitive);
					if (iIndex > 0) {
						iEnd = str.indexOf(" ", iIndex, Qt::CaseInsensitive);
						m_strSSID = "     " + str.mid(iIndex + 7,
								iEnd - iIndex - 8);
						//cout << "ESSID:" << strSSID.toStdString().c_str() << endl;

						//网络模式
						iIndex = str.indexOf("Mode", 0, Qt::CaseInsensitive);
						if (iIndex > 0) {
							iEnd
									= str.indexOf(" ", iIndex,
											Qt::CaseInsensitive);
							m_strMode = str.mid(iIndex + 5, iEnd - iIndex - 5);
							//cout << "Mode:" << strMode.toStdString().c_str()
							//	<< endl;
							return true;
						}
					}
				}
			}
		}

	}
	return false;
}

void QWiFiList::addTabWidgetItem(int iIndex) {
	//m_ptbWifiInfo->removeCellWidget(0, 0);
	m_ptbWifiInfo->setRowCount(iIndex + 1);
	m_ptbWifiInfo->setItem(iIndex, 0,
			new QTableWidgetItem(m_strSSID.toStdString().c_str()));
	m_ptbWifiInfo->setItem(iIndex, 1,
			new QTableWidgetItem(m_strMac.toStdString().c_str()));
	QStringList list = m_strQuality.split('/');
	//	if (list.at(0).)
	//cout<<list.at(0).toStdString().c_str()<<endl;
	//cout<<list.at(1).toStdString().c_str()<<endl;
	if (list.at(1).toInt() != 0)
		m_strQuality = QString::number(
				list.at(0).toInt() * 100 / list.at(1).toInt()) + "%";
	m_ptbWifiInfo->setItem(iIndex, 2,
			new QTableWidgetItem(m_strQuality.toStdString().c_str()));
	m_ptbWifiInfo->setItem(iIndex, 3,
			new QTableWidgetItem(m_strChannel.toStdString().c_str()));
	m_ptbWifiInfo->setItem(iIndex, 4,
			new QTableWidgetItem(m_strEncryption.toStdString().c_str()));

	m_ptbWifiInfo->setItem(iIndex, 5,
			new QTableWidgetItem(m_strMode.toStdString().c_str()));
}
void QWiFiList::pbStopClicked() {
	QString strCmd = "ifconfig " + m_strName + " down";
	system(strCmd.toLocal8Bit().data());
}
void QWiFiList::pbCloseClicked() {
	g_pWiFi->close();
}
