#ifndef UIWIFILIST_H
#define UIWIFILIST_H

#include <QtGui/QWidget>
#include <QTableWidget>
#include <QPushButton>
#include <QFile>
#include <QProgressDialog>
#include <QCheckBox>
#include <QMessageBox>
#include <QTimer>
#include "uiInputFileName.h"

class QWiFiList: public QWidget
{
Q_OBJECT

public:
	QWiFiList(QWidget *parent = 0);
	~QWiFiList();

private:
	QTableWidget *m_ptbWifiInfo;

	QPushButton *m_pbSet;//
	QPushButton *m_pbSearch;//
	QPushButton *m_pbConnect;//
	QPushButton *m_pbStop;//
	QPushButton *m_pbClose;//
	QFile *m_pFile;
	QFile *m_pFileName;
	QProgressDialog m_ProgessDlg;
	QString m_strMac;
	QString m_strChannel;
	QString m_strEncryption;
	QString m_strSSID;
	QString m_strMode;
	QString m_strQuality;
	QString m_strPwd;

	int 	m_iCurrentRow;
	QCheckBox *m_pcbDhcp;
	QMessageBox m_MessageBox;
	QTimer *m_pMessageTimer;
	QTimer *m_pDhcp;

	QInputFileName *m_ifn;

	QString m_strName;
	QStringList strListInfo;

	void getWiFiInfo();
	void getWiName();
	bool explainWiFiInfo(QString);
	void addTabWidgetItem(int iIndex);
	void connectToWiFi(QString ssid,QString pwd);

public slots:
	void searchAuto();
	void pbSetClicked();
	void pbConnectClicked();
	void messageTimeout();
	void dhcpTimeout();
	void ifnSlot(QStringList);
	void ifnSlotCancel();
	void pbSearchClicked();
	void pbStopClicked();
	void pbCloseClicked();
};

#endif // UIWIFILIST_H
