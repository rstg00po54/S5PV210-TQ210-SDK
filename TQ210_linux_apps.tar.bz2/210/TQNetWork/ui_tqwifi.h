/********************************************************************************
** Form generated from reading ui file 'tqwifi.ui'
**
** Created: Wed Sep 19 15:46:01 2012
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_TQWIFI_H
#define UI_TQWIFI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TQWiFiClass
{
public:

    void setupUi(QWidget *TQWiFiClass)
    {
        if (TQWiFiClass->objectName().isEmpty())
            TQWiFiClass->setObjectName(QString::fromUtf8("TQWiFiClass"));
        TQWiFiClass->resize(480, 272);

        retranslateUi(TQWiFiClass);

        QMetaObject::connectSlotsByName(TQWiFiClass);
    } // setupUi

    void retranslateUi(QWidget *TQWiFiClass)
    {
        TQWiFiClass->setWindowTitle(QApplication::translate("TQWiFiClass", "TQWiFi", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(TQWiFiClass);
    } // retranslateUi

};

namespace Ui {
    class TQWiFiClass: public Ui_TQWiFiClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TQWIFI_H
