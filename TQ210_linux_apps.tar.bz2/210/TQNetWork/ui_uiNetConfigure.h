/********************************************************************************
** Form generated from reading ui file 'uiNetConfigure.ui'
**
** Created: Wed Sep 19 15:46:01 2012
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_UINETCONFIGURE_H
#define UI_UINETCONFIGURE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QNetConfigureClass
{
public:
    QPushButton *pbClose;
    QPushButton *pbConfirm;
    QLabel *lbDns2;
    QLabel *lbDns1;
    QLabel *lbNetMask;
    QLabel *lbIp;
    QLabel *lbGw;
    QLabel *lbMac;
    QLabel *lbNetType;
    QCheckBox *cbDhcp;
    QPushButton *pbRead;
    QPushButton *pbHelp;
    QPushButton *pbKey;
    QCheckBox *cbWifi;

    void setupUi(QWidget *QNetConfigureClass)
    {
        if (QNetConfigureClass->objectName().isEmpty())
            QNetConfigureClass->setObjectName(QString::fromUtf8("QNetConfigureClass"));
        QNetConfigureClass->resize(480, 272);
        QNetConfigureClass->setMinimumSize(QSize(480, 0));
        pbClose = new QPushButton(QNetConfigureClass);
        pbClose->setObjectName(QString::fromUtf8("pbClose"));
        pbClose->setGeometry(QRect(340, 160, 92, 30));
        pbConfirm = new QPushButton(QNetConfigureClass);
        pbConfirm->setObjectName(QString::fromUtf8("pbConfirm"));
        pbConfirm->setGeometry(QRect(340, 40, 92, 30));
        lbDns2 = new QLabel(QNetConfigureClass);
        lbDns2->setObjectName(QString::fromUtf8("lbDns2"));
        lbDns2->setGeometry(QRect(70, 180, 50, 17));
        lbDns1 = new QLabel(QNetConfigureClass);
        lbDns1->setObjectName(QString::fromUtf8("lbDns1"));
        lbDns1->setGeometry(QRect(70, 151, 50, 17));
        lbNetMask = new QLabel(QNetConfigureClass);
        lbNetMask->setObjectName(QString::fromUtf8("lbNetMask"));
        lbNetMask->setGeometry(QRect(57, 123, 61, 17));
        lbIp = new QLabel(QNetConfigureClass);
        lbIp->setObjectName(QString::fromUtf8("lbIp"));
        lbIp->setGeometry(QRect(70, 30, 50, 17));
        lbGw = new QLabel(QNetConfigureClass);
        lbGw->setObjectName(QString::fromUtf8("lbGw"));
        lbGw->setGeometry(QRect(70, 93, 50, 17));
        lbMac = new QLabel(QNetConfigureClass);
        lbMac->setObjectName(QString::fromUtf8("lbMac"));
        lbMac->setGeometry(QRect(54, 64, 60, 17));
        lbNetType = new QLabel(QNetConfigureClass);
        lbNetType->setObjectName(QString::fromUtf8("lbNetType"));
        lbNetType->setGeometry(QRect(30, 5, 70, 22));
        cbDhcp = new QCheckBox(QNetConfigureClass);
        cbDhcp->setObjectName(QString::fromUtf8("cbDhcp"));
        cbDhcp->setGeometry(QRect(100, 5, 91, 22));
        pbRead = new QPushButton(QNetConfigureClass);
        pbRead->setObjectName(QString::fromUtf8("pbRead"));
        pbRead->setGeometry(QRect(340, 80, 92, 30));
        pbHelp = new QPushButton(QNetConfigureClass);
        pbHelp->setObjectName(QString::fromUtf8("pbHelp"));
        pbHelp->setGeometry(QRect(340, 120, 92, 30));
        pbKey = new QPushButton(QNetConfigureClass);
        pbKey->setObjectName(QString::fromUtf8("pbKey"));
        pbKey->setGeometry(QRect(340, 0, 92, 30));
        cbWifi = new QCheckBox(QNetConfigureClass);
        cbWifi->setObjectName(QString::fromUtf8("cbWifi"));
        cbWifi->setGeometry(QRect(210, 5, 121, 22));

        retranslateUi(QNetConfigureClass);

        QMetaObject::connectSlotsByName(QNetConfigureClass);
    } // setupUi

    void retranslateUi(QWidget *QNetConfigureClass)
    {
        QNetConfigureClass->setWindowTitle(QApplication::translate("QNetConfigureClass", "QNetConfigure", 0, QApplication::UnicodeUTF8));
        pbClose->setText(QString());
        pbConfirm->setText(QString());
        lbDns2->setText(QApplication::translate("QNetConfigureClass", " DNS2:", 0, QApplication::UnicodeUTF8));
        lbDns1->setText(QApplication::translate("QNetConfigureClass", " DNS1:", 0, QApplication::UnicodeUTF8));
        lbNetMask->setText(QApplication::translate("QNetConfigureClass", "\345\255\220\347\240\201\346\216\251\347\240\201:", 0, QApplication::UnicodeUTF8));
        lbIp->setText(QApplication::translate("QNetConfigureClass", "IP\345\234\260\345\235\200:", 0, QApplication::UnicodeUTF8));
        lbGw->setText(QApplication::translate("QNetConfigureClass", " \347\275\221  \345\205\263:", 0, QApplication::UnicodeUTF8));
        lbMac->setText(QApplication::translate("QNetConfigureClass", "MAC\345\234\260\345\235\200:", 0, QApplication::UnicodeUTF8));
        lbNetType->setText(QApplication::translate("QNetConfigureClass", "\347\275\221\347\273\234\346\226\271\345\274\217\357\274\232", 0, QApplication::UnicodeUTF8));
        cbDhcp->setText(QApplication::translate("QNetConfigureClass", "\345\212\250\346\200\201\350\216\267\345\217\226IP", 0, QApplication::UnicodeUTF8));
        pbRead->setText(QString());
        pbHelp->setText(QString());
        pbKey->setText(QString());
        cbWifi->setText(QApplication::translate("QNetConfigureClass", "\346\230\257\345\220\246\344\275\277\347\224\250Wifi", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(QNetConfigureClass);
    } // retranslateUi

};

namespace Ui {
    class QNetConfigureClass: public Ui_QNetConfigureClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UINETCONFIGURE_H
