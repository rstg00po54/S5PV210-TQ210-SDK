#include "tqping.h"
#include <QMessageBox>
#include<QHBoxLayout>
#include<QVBoxLayout>
#include<iostream>
using namespace std;
TQPing::TQPing(QWidget *parent, bool bKeyShow) :
	QWidget(parent)
{
	ui.setupUi(this);

	m_bPing = false;
	m_pTiemr = new QTimer;
	m_pFile = new QFile("/tmp/ping.txt");

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	ui.leIP->setText("www.baidu.com");

	ui.pbKey->setText("");
	ui.pbKey->setMaximumWidth(55);
	ui.pbKey->setMaximumHeight(26);
	ui.pbKey->setIconSize(QSize(55, 26));
	QPixmap pix("/opt/PDA/app/images/key.png", 0, Qt::AutoColor);
	pix = pix.scaled(55, 26, Qt::IgnoreAspectRatio);//图片大小
	ui.pbKey->setIcon(QIcon(pix));

	ui.pbStart->setFixedSize(55, 26);
	ui.pbStart->setIconSize(QSize(55, 26));
	pix.load("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
	pix = pix.scaled(55, 26, Qt::IgnoreAspectRatio);//图片大小
	ui.pbStart->setIcon(QIcon(pix));

	ui.pbClear->setFixedSize(55, 26);
	ui.pbClear->setIconSize(QSize(55, 26));
	pix.load("/opt/PDA/app/images/clearRec.png", 0, Qt::AutoColor);
	pix = pix.scaled(55, 26, Qt::IgnoreAspectRatio);//图片大小
	ui.pbClear->setIcon(QIcon(pix));

	ui.pbHelp->setFixedSize(55, 26);
	ui.pbHelp->setIconSize(QSize(55, 26));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(55, 26, Qt::IgnoreAspectRatio);//图片大小
	ui.pbHelp->setIcon(QIcon(pix));
	connect(ui.pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	ui.pbQuit->setFixedSize(55, 26);
	ui.pbQuit->setIconSize(QSize(55, 26));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(55, 26, Qt::IgnoreAspectRatio);//图片大小
	ui.pbQuit->setIcon(QIcon(pix));

	if (!m_pFile->open(QIODevice::ReadWrite))
	{
		QMessageBox::warning(this, trUtf8("警告"), trUtf8("创建临时文件失败！"),
				QMessageBox::Ok);
		ui.pbStart->setEnabled(false);
	}
	connect(m_pTiemr, SIGNAL(timeout()), this, SLOT(readFile()));
	connect(ui.pbQuit, SIGNAL(clicked()), this, SLOT(close()));
	connect(ui.pbStart, SIGNAL(clicked()), this, SLOT(pbStartClicked()));
	connect(ui.pbClear, SIGNAL(clicked()), this, SLOT(pbClearClicked()));

	ui.pbKey->setEnabled(0);

	QHBoxLayout *titleLayout = new QHBoxLayout();
	QHBoxLayout *hLayout = new QHBoxLayout();
	hLayout->addWidget(ui.label);
	hLayout->addWidget(ui.leIP);
	hLayout->addWidget(ui.pbKey);
	hLayout->addWidget(ui.pbStart);
	hLayout->addWidget(ui.pbClear);
	hLayout->addWidget(ui.pbHelp);
	hLayout->addWidget(ui.pbQuit);

	QVBoxLayout *vLayout = new QVBoxLayout();
	vLayout->addWidget(ui.lbTitle);
	vLayout->addLayout(hLayout);
	vLayout->addWidget(ui.teContent);

	setLayout(vLayout);
	if (bKeyShow)
	{
		ui.pbKey->setEnabled(1);
		connect(ui.pbKey, SIGNAL(clicked()), this,
				SLOT(pbKeyShowHide()));

		im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(false);
	}
}

TQPing::~TQPing()
{
	m_pFile->close();
	delete m_pFile;
	m_pTiemr->stop();
	delete m_pTiemr;

	delete ui.leIP;
	delete ui.pbHelp;
}
void TQPing::pbStartClicked()
{
	m_pFile->resize(0);
	if (!m_bPing)
	{
		if (ui.leIP->text() != "")
		{
			QString strCmd = "ping " + ui.leIP->text()
					+ " >> /tmp/ping.txt &";
			if (system(strCmd.toStdString().c_str()) == 0)
			{
				ui.pbStart->setFixedSize(55, 26);
				ui.pbStart->setIconSize(QSize(55, 26));
				QPixmap pix("/opt/PDA/app/images/pause.png", 0,
						Qt::AutoColor);
				pix = pix.scaled(55, 26, Qt::IgnoreAspectRatio);//图片大小
				ui.pbStart->setIcon(QIcon(pix));
				m_pTiemr->start(100);
			}
		}
	}
	else
	{
		system("killall ping");
		ui.pbStart->setFixedSize(55, 26);
		ui.pbStart->setIconSize(QSize(55, 26));
		QPixmap pix("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
		pix = pix.scaled(55, 26, Qt::IgnoreAspectRatio);//图片大小
		ui.pbStart->setIcon(QIcon(pix));
		m_pTiemr->stop();
	}
	m_bPing = !m_bPing;
}
void TQPing::pbClearClicked()
{
	ui.teContent->clear();
}
void TQPing::readFile()
{
//	/tmp/ping.txt

	QFile file("/tmp/ping.txt");

//	if(file.size()>)

//	cout<<"size->"<<file.size()<<endl;

	m_iReadLen = m_pFile->readLine(cData, sizeof(cData));
	if (m_iReadLen > 0)
	{
		ui.teContent->setPlainText(
				ui.teContent->toPlainText()
						+ QString(cData).mid(0,
								m_iReadLen));
		QTextCursor cursor = ui.teContent->textCursor();
		cursor.movePosition(QTextCursor::End);
		ui.teContent->setTextCursor(cursor);
	}
}
void TQPing::pbKeyShowHide()
{
	((TQInputMethod *) im)->setVisible(true);
}
void TQPing::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
