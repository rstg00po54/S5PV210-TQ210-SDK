#ifndef TQPING_H
#define TQPING_H
#include <QFile>
#include <QTimer>

#include <QtGui/QWidget>
#include "ui_tqping.h"
#include <qprocess.h>
#include<QLineEdit>
#include<QPushButton>

#include "TQInputMethod.h"
#ifdef ARM
#include <QWSInputMethod>
#endif

class TQPing : public QWidget
{
    Q_OBJECT

public:
    TQPing(QWidget *parent = 0,bool bKeyShow=0);
    ~TQPing();

private:
    Ui::TQPingClass ui;
    QFile *m_pFile;
    QTimer *m_pTiemr;
    int m_iReadLen;
    char cData[200];
    bool m_bPing;
    QLineEdit *m_lineEdit;
	QProcess process;
	QPushButton *m_pbHelp;

    QWSInputMethod* im;

    QPushButton *m_pbKey;

public slots:
	void pbStartClicked();
	void pbClearClicked();
	void readFile();
	void pbHelpClicked();
	void pbKeyShowHide();
};

#endif // TQPING_H
