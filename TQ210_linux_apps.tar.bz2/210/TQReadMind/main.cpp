#include "tqreadmind.h"

#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	TQReadMind w;
	w.showFullScreen();
	return a.exec();
}
