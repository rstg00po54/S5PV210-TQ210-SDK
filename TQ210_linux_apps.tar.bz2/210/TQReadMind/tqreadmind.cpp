#include "tqreadmind.h"
#include<QTime>
#include <QApplication>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include<iostream>
using namespace std;

QString str_PicPath1 = "/opt/PDA/pic/readmind_images/rm_1.png";
QString str_PicPath2 = "/opt/PDA/pic/readmind_images/rm_2.png";
QString str_PicPath3 = "/opt/PDA/pic/readmind_images/rm_7.png";
QString str_PicPath4 = "/opt/PDA/pic/readmind_images/rm_4.png";
QString str_PicPath5 = "/opt/PDA/pic/readmind_images/rm_15.png";
QString str_PicPath6 = "/opt/PDA/pic/readmind_images/rm_6.png";
QString str_PicPath7 = "/opt/PDA/pic/readmind_images/rm_7.png";
QString str_PicPath8 = "/opt/PDA/pic/readmind_images/rm_8.png";
QString str_PicPath9 = "/opt/PDA/pic/readmind_images/rm_9.png";
QString str_PicPath10 = "/opt/PDA/pic/readmind_images/rm_10.png";
QString str_PicPath11 = "/opt/PDA/pic/readmind_images/rm_11.png";
QString str_PicPath12 = "/opt/PDA/pic/readmind_images/rm_12.png";
QString str_PicPath13 = "/opt/PDA/pic/readmind_images/rm_13.png";
QString str_PicPath14 = "/opt/PDA/pic/readmind_images/rm_14.png";
QString str_PicPath15 = "/opt/PDA/pic/readmind_images/rm_15.png";
QString str_PicPath16 = "/opt/PDA/pic/readmind_images/rm_16.png";
QString str_PicPath17 = "/opt/PDA/pic/readmind_images/rm_17.png";
QString str_PicPath18 = "/opt/PDA/pic/readmind_images/rm_18.png";
QString str_PicPath19 = "/opt/PDA/pic/readmind_images/rm_19.png";
QString str_PicPath20 = "/opt/PDA/pic/readmind_images/rm_20.png";
QString str_PicPath21 = "/opt/PDA/pic/readmind_images/rm_21.png";
QString str_PicPath22 = "/opt/PDA/pic/readmind_images/rm_22.png";
QString str_PicPath23 = "/opt/PDA/pic/readmind_images/rm_23.png";
QString str_PicPath24 = "/opt/PDA/pic/readmind_images/rm_18.png";
QString str_PicPathNull = "/opt/PDA/pic/readmind_images/EmbedSky.png";

QString str_path[] =
{ str_PicPath1, str_PicPath2, str_PicPath3, str_PicPath4, str_PicPath5,
		str_PicPath6, str_PicPath7, str_PicPath8, str_PicPath9, str_PicPath10,
		str_PicPath11, str_PicPath12, str_PicPath13, str_PicPath14,
		str_PicPath15, str_PicPath16, str_PicPath17, str_PicPath18,
		str_PicPath19, str_PicPath20, str_PicPath21 };
int iRand;
TQReadMind::TQReadMind(QWidget *parent) :
	QWidget(parent)
{
	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	//ui.label_101->setAlignment(Qt::AlignCenter);

	m_pbConfirm = new QPushButton();
	m_pbRefresh = new QPushButton();
	m_pbExit = new QPushButton();
	m_pbHelp = new QPushButton();

	m_pbConfirm->setFixedSize(58, 58);
	m_pbConfirm->setIconSize(QSize(58, 58));
	QPixmap pix(str_PicPathNull, 0, Qt::AutoColor);
	pix = pix.scaled(58, 58, Qt::IgnoreAspectRatio);//图片大小
	m_pbConfirm->setIcon(QIcon(pix));

	QHBoxLayout *hLayout = new QHBoxLayout();
	QVBoxLayout *vLayout[10];
	QVBoxLayout *numLayout[10];
	for (int i = 0; i < 10; i++)
	{
		vLayout[i] = new QVBoxLayout();
		numLayout[i] = new QVBoxLayout();
		for (int j = 0; j < 10; j++)
		{
			m_lab[j][i] = new QLabel(this);
			vLayout[i]->addWidget(m_lab[j][i]);

			m_lbNum[j][i] = new QLabel(QString::number(j*10+i));
			numLayout[i]->addWidget(m_lbNum[j][i]);
		}
		hLayout->addLayout(numLayout[i]);
		hLayout->addLayout(vLayout[i]);
	}

	QVBoxLayout *btnLayout = new QVBoxLayout();
	btnLayout->addWidget(m_pbConfirm);
	btnLayout->addWidget(m_pbRefresh);
	btnLayout->addWidget(m_pbExit);
	btnLayout->addWidget(m_pbHelp);

	hLayout->addLayout(btnLayout);

	setLayout(hLayout);
	qsrand(QTime(0, 0, 0).secsTo(QTime::currentTime()));

	m_pbConfirm->setFixedSize(58, 58);
	m_pbConfirm->setIconSize(QSize(58, 58));//pbReFresh

	m_pbRefresh->setFixedSize(65, 32);
	m_pbRefresh->setIconSize(QSize(65, 32));
	pix.load("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbRefresh->setIcon(QIcon(pix));

	m_pbExit->setFixedSize(65,32);
	m_pbExit->setIconSize(QSize(65, 32));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbExit->setIcon(QIcon(pix));

	m_pbHelp->setFixedSize(65, 32);
	m_pbHelp->setIconSize(QSize(65, 32));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	connect(m_pbConfirm, SIGNAL(clicked()), this, SLOT(pbConfimClicked()));
	connect(m_pbExit, SIGNAL(clicked()), this, SLOT(close()));
	connect(m_pbRefresh, SIGNAL(clicked()), this, SLOT(pbRefreshClicked()));
	//pbRefreshClicked();
}

TQReadMind::~TQReadMind()
{
	for (int i = 0; i < 10; i++)
		for (int j = 0; j < 10; j++)
		{
			delete m_lab[i][j];
			delete m_lbNum[i][j];
		}
}
void TQReadMind::pbConfimClicked()
{
	pix.load(str_path[iRand], 0, Qt::AutoColor);
	pix = pix.scaled(58, 58, Qt::IgnoreAspectRatio);//图片大小
	m_pbConfirm->setIcon(QIcon(pix));
}
void TQReadMind::pbRefreshClicked()
{
	int i, j;
	for (i = 0; i < 10; i++)
	{
		for (j = 0; j < 10; j++)
		{
			iRand = qrand() % 21;
			pix.load(str_path[iRand]);
			pix = pix.scaled(16, 15, Qt::IgnoreAspectRatio);//图片大小
			m_lab[i][j]->setPixmap(pix);
		}
	}
	int ii;
	iRand = qrand() % 21;
	for (ii = 0; ii < 10; ii++)
	{
		pix.load(str_path[iRand]);
		pix = pix.scaled(16, 15, Qt::IgnoreAspectRatio);//图片大小
		m_lab[ii][9 - ii]->setPixmap(pix);
	}

	m_pbConfirm->setFixedSize(58, 58);
	m_pbConfirm->setIconSize(QSize(58, 58));
	QPixmap pix(str_PicPathNull, 0, Qt::AutoColor);
	pix = pix.scaled(58, 58, Qt::IgnoreAspectRatio);//图片大小
	m_pbConfirm->setIcon(QIcon(pix));
}

void TQReadMind::pbHelpClicked()
{
//	cout << "help" << endl;
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
