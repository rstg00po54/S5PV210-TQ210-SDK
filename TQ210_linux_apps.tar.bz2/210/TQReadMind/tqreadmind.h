#ifndef TQREADMIND_H
#define TQREADMIND_H

#include <QtGui/QWidget>
#include<QDateTime>
#include<QPixmap>
#include <qprocess.h>
#include <QPushButton>
#include <QLabel>
class TQReadMind : public QWidget
{
    Q_OBJECT

public:
    TQReadMind(QWidget *parent = 0);
    ~TQReadMind();

public slots:
    void pbConfimClicked();
    void pbRefreshClicked();
	void pbHelpClicked();

private:
	QPushButton *m_pbConfirm;
	QPushButton *m_pbRefresh;
	QPushButton *m_pbExit;
	QPushButton *m_pbHelp;
    QDateTime time;
    QPixmap pix;
    QLabel *m_lab[10][10];
    QLabel *m_lbNum[10][10];
    QProcess process;
};

#endif // TQREADMIND_H
