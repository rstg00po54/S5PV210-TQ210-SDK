/*
 *     公司名:    	广州天嵌计算机科技有限公司
 *     项目名:     	PDA
 *     文件名:     	TQSoundDevice.cpp
 *    文件描述:      音频播放控制线程
 *    创建日期:      2011-12-20
 *    创 建 人:      lkp
 *     文档:
 *    运行平台:      linux
 *     其他:         www.armbbs.net
 */
#include "TQSoundDevice.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <iostream>
using namespace std;
#include <sys/ioctl.h>
#include <linux/soundcard.h>/*for OSS style sound programing */
#define FMT8BITS AFMT_U8 /*unsigned 8 bits(for almost PC) */
#define FMT16BITS AFMT_S16_LE /*signed 16 bits,little endian */
#define FMT8K    8000 /*default sampling rate */
#define FMT11K   11025 /*11,22,44,48 are three pop rate */
#define FMT22K   22050
#define FMT44K   44100
#define FMT48K  48000
#define MONO     1
#define STEREO   2
#define ACT_RECORD 0
#define ACT_PLAY 1
#define DFT_SND_DEV  "/dev/sound/dsp"
#define DFT_SND_FMT  FMT8BITS
#define DFT_SND_SPD  FMT8K
#define DFT_SND_CHN  MONO
#define DFT_LEN  10
#define BUFF_SIZE  100 /*buffer size:512 Bytes */
bool bStop = false;
/************** function prototype ********************/
void Usage(void);
int OpenDevice(const char *, unsigned int);
int OpenFile(const char *, unsigned int);
int CloseDevice(unsigned int);
int CloseFile(unsigned int);
int SetFormat(unsigned int fd, unsigned int bits, unsigned int chn,
		unsigned int hz);
/************** function implementation **************/

unsigned int snd_fmt = DFT_SND_FMT; /*sound format,bits */
unsigned int snd_chn = DFT_SND_CHN; /*sound channel number */
unsigned int snd_spd = DFT_SND_SPD; /*sound speed,frequency */
char *snd_device = DFT_SND_DEV; /*sound device */
unsigned char buff[BUFF_SIZE]; /*sound buffer */
unsigned long len = DFT_LEN * 1024; /*record or play length(k) */
TQSoundDevice::TQSoundDevice()
{
	moveToThread(this);
	m_bStop = true;
}

TQSoundDevice::~TQSoundDevice()
{
	// TODO Auto-generated destructor stub
}
void TQSoundDevice::run()
{
	while (true)
	{
		if (!m_bStop)
		{
			if (m_bPlay)
			{
				play(m_strFileName);
			}
			else
			{
				record(m_strFileName);
			}
			m_bStop = true;
		}
		usleep(100);
	}
}
void TQSoundDevice::playSound(QString name)
{
	m_bStop = false;
	m_bPlay = true;
	m_strFileName = name;
}
void TQSoundDevice::recordSound(QString name)
{
	m_bStop = false;
	m_bPlay = false;
	m_strFileName = name;
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：play
 ** 创建日期：2011-12-20
 ** 创 建 人： lkp
 ** 函数功能：播放音频文件
 ** 参    数：
 	 filename [in] : 文件名
 ** 返    回：运行结果
 ** 数 据 库：无
 ** 其它说明：无
 */
int TQSoundDevice::play(QString filename)
{
	//printf("开始播放\r\n");
	m_bStop = false;
	char *s_file = (char *) filename.toStdString().c_str(); /*file hold sound data */
	unsigned int recd_or_play = ACT_PLAY; /*flag(default play) */

	int snd_fd; /*sound device descriptor */
	int s_fd; /*sound data file descrit */
	ssize_t n; /*bytes already in or out */
	ssize_t nRD; /*bytes readin */
	ssize_t nWR; /*bytes write out */
	//unsigned int opt_chr; /*hold cli option */
	//unsigned int opt_err = FALSE; /*indicate whether parse option error */
	/*parse cli option via getopt routine */
	optind = 0; /*set optindex to 0 */

	/*open device */
	if ((snd_fd = OpenDevice(snd_device, recd_or_play)) < 0)
	{
		fprintf(stderr, "cannot open device %s:%s\n", snd_device,
				strerror(errno));
		emit
		playStop(-1);
		return (-1);
	}
	/*open sound data file */
	if ((s_fd = OpenFile(s_file, recd_or_play)) < 0)
	{
		fprintf(stderr, "cannot open sound file %s:%s\n", s_file,
				strerror(errno));
		emit
		playStop(-2);
		return (-2);
	}
	/*set sound format */
	if (SetFormat(snd_fd, snd_fmt, snd_chn, snd_spd) < 0)
	{
		fprintf(stderr, "cannot set %s in bit %d, channel %d, speed %d\n",
				snd_device, snd_fmt, snd_chn, snd_spd);
		emit
		playStop(-3);
		return (-3);
	}
	while (!m_bStop)
	{
		/*do real action:record or playback */
		nRD = 0L; /*read amount from sound device */
		if ((nRD = read(s_fd, buff, BUFF_SIZE)) < 0)
		{
			perror("read sound data file failed");
			emit
			playStop(-4);
			return (-4);
		}
		else if (nRD == 0)
		{ /*nRD == 0 means all sound stream output */
			//printf("sound data play complete!\n");
			break;
		}
		cout<<"read:"<<nRD<<endl;
		nWR = nRD;
		while (nWR > 0 && !m_bStop)
		{ /*write into device*/
			if ((n = write(snd_fd, buff, nWR)) < 0)
			{
				perror("write sound device file failed");
				emit
				playStop(-1);
				return (-3);
			}
			cout<<"write:"<<n<<endl;
			nWR -= n;
		}
		usleep(100);
	}
	//printf("播放结束\r\n");
	emit playStop(0);
	/*close sound device and sound data file*/
	CloseDevice(snd_fd);
	CloseFile(s_fd);
	return 0;
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：record
 ** 创建日期：2011-12-20
 ** 创 建 人： lkp
 ** 函数功能：录音
 ** 参    数：
 	 filename [in] : 文件名
 ** 返    回：运行结果
 ** 数 据 库：无
 ** 其它说明：无
 */
int TQSoundDevice::record(QString name)
{
	//printf("开始录音\r\n");
	//int ret = 0;
	m_bStop = false;
	char *s_file = (char *) name.toStdString().c_str(); /*file hold sound data */
	unsigned int recd_or_play = ACT_RECORD; /*flag(default play) */
	int snd_fd; /*sound device descriptor */
	int s_fd; /*sound data file descrit */
	//ssize_t n; /*bytes already in or out */
	ssize_t nRD; /*bytes readin */
	//ssize_t nWR; /*bytes write out */
	//unsigned int opt_chr; /*hold cli option */
	//unsigned int opt_err = FALSE; /*indicate whether parse option error */
	/*parse cli option via getopt routine */
	optind = 0; /*set optindex to 0 */

	/*open device */
	if ((snd_fd = OpenDevice(snd_device, recd_or_play)) < 0)
	{
		fprintf(stderr, "cannot open device %s:%s\n", snd_device,
				strerror(errno));
		emit
		recordStop(-1);
		return (-1);
	}
	/*open sound data file */
	if ((s_fd = OpenFile(s_file, recd_or_play)) < 0)
	{
		fprintf(stderr, "cannot open sound file %s:%s\n", s_file,
				strerror(errno));
		emit
		recordStop(-2);
		return (-2);
	}
	/*set sound format */
	if (SetFormat(snd_fd, snd_fmt, snd_chn, snd_spd) < 0)
	{
		fprintf(stderr, "cannot set %s in bit %d, channel %d, speed %d\n",
				snd_device, snd_fmt, snd_chn, snd_spd);
		emit
		recordStop(-3);
		return (-3);
	}
	/*do real action:record or playback */
	/*record sound into data file*/
	while (!m_bStop)
	{
		//n = 0;
		//len = DFT_LEN * 1024;
		//while (n < len && !bStop)
		//{
		nRD = 0; /*amount read from sound device */
		if ((nRD = read(snd_fd, buff, BUFF_SIZE)) < 0)
		{
			perror("read sound device failed");
			return (-3);
		}
		//if (n + nRD <= len) /*the len is not full */
		//	nWR = nRD; /*write amount to sound data file */
		//else
		//	nWR = len - n; /*len will be overflow */
		//unsigned long old_nWR = nWR; /*s hold nWR's old value */
		unsigned long t = 0L; /*temp counter */

		while (nRD > 0)
		{
			if ((t = write(s_fd, buff, nRD)) < 0)
			{
				perror("write sound data file failed");
				emit
				recordStop(-4);
				return (-4);
			}
			nRD -= t;
		}
		//n += old_nWR;
		//}
	}
	/*close sound device and sound data file*/
	CloseDevice(snd_fd);
	CloseFile(s_fd);
	//printf("record finish\r\n");
	emit recordStop(0);
	return 0;
}

//---------------------------------------------------------------------------
/*
 ** 函数名称：OpenDevice
 ** 创建日期：2011-12-20
 ** 创 建 人： lkp
 ** 函数功能：打开音频设备
 ** 参    数：
 	 dev_name [in] : 文件名
 	 flag     [in] : 打开标志
 ** 返    回：打开结果，成功/设备句柄，失败/－1
 ** 数 据 库：无
 ** 其它说明：无
 */
int OpenDevice(const char *dev_name, unsigned int flag)
{
	int dev_fd;
	/*open sound device */
	if (flag == ACT_RECORD)
	{
		if ((dev_fd = open(dev_name, O_RDONLY)) < 0)
		{
			return (-1);
		}
	}
	else if (flag == ACT_PLAY)
	{
		if ((dev_fd = open(dev_name, O_WRONLY)) < 0)
		{
			return (-1);
		}
	}
	return (dev_fd);
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：CloseDevice
 ** 创建日期：2011-12-20
 ** 创 建 人： lkp
 ** 函数功能：打开音频设备
 ** 参    数：
 	 dev_fd [in] : 设备句柄
 ** 返    回：打开结果，成功/0，失败/－1
 ** 数 据 库：无
 ** 其它说明：无
 */
int CloseDevice(unsigned int dev_fd)
{
	return (close(dev_fd));
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：OpenFile
 ** 创建日期：2011-12-20
 ** 创 建 人： lkp
 ** 函数功能：打开音频文件
 ** 参    数：
 	 file_name [in] : 文件名
 	 flag [in] : 打开标志 ACT_RECORD or ACT_PLAY
 ** 返    回：打开结果，成功/文件句柄，失败/－1
 ** 数 据 库：无
 ** 其它说明：无
 */
int OpenFile(const char *file_name, unsigned int flag)
{
	int file_fd;
	/*open sound data file */
	if (flag == ACT_RECORD)
	{
		if ((file_fd = open(file_name, O_CREAT | O_WRONLY)) < 0)
		{
			return (-1);
		}
	}
	else if (flag == ACT_PLAY)
	{
		if ((file_fd = open(file_name, O_RDONLY)) < 0)
		{
			return (-1);
		}
	}
	return (file_fd);
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：CloseFile
 ** 创建日期：2011-12-20
 ** 创 建 人： lkp
 ** 函数功能：关闭音频文件
 ** 参    数：
 	 file_fd [in] : 文件句柄
 ** 返    回：关闭结果，成功/0，失败/－1
 ** 数 据 库：无
 ** 其它说明：无
 */
int CloseFile(unsigned int file_fd)
{
	return (close(file_fd));
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：SetFormat
 ** 创建日期：2011-12-20
 ** 创 建 人： lkp
 ** 函数功能：设置音频设备属性
 ** 参    数：
 	 fd   [in] : 设备句柄
 	 bits [in] : 采样位 FMT8BITS(8bits), FMT16BITS(16bits)
 	 chn  [in] : 通道 mono or stereo
 	 hz   [in] : 采样频率 FMT8K(8000HZ), FMT16K(16000HZ), FMT22K(22000HZ),
 *  FMT44K(44000HZ),FMT48K(48000HZ)
 ** 返    回：设置结果，成功/0，失败/－1
 ** 数 据 库：无
 ** 其它说明：无
 */
int SetFormat(unsigned int fd, unsigned int bits, unsigned int chn,
		unsigned int hz)
{
	int ioctl_val;
	/* set bit format */
	ioctl_val = bits;
	if (ioctl(fd, SNDCTL_DSP_SETFMT, &ioctl_val) == -1)
	{
		fprintf(stderr, "Set fmt to bit %d failed:%s\n", bits, strerror(errno));
		return (-1);
	}
	if (ioctl_val != bits)
	{
		fprintf(stderr, "do not support bit %d, supported %d\n", bits,
				ioctl_val);
		return (-1);
	}
	/*set channel */
	ioctl_val = chn;
	if ((ioctl(fd, SNDCTL_DSP_CHANNELS, &ioctl_val)) == -1)
	{
		fprintf(stderr, "Set Audio Channels %d failed:%s\n", chn,
				strerror(errno));
		return (-1);
	}
	if (ioctl_val != chn)
	{
		fprintf(stderr, "do not support channel %d,supported %d\n", chn,
				ioctl_val);
		return (-1);
	}
	/*set speed */
	ioctl_val = hz;
	if (ioctl(fd, SNDCTL_DSP_SPEED, &ioctl_val) == -1)
	{
		fprintf(stderr, "Set speed to %d failed:%s\n", hz, strerror(errno));
		return (-1);
	}
	if (ioctl_val != hz)
	{
		fprintf(stderr, "do not support speed %d,supported is %d\n", hz,
				ioctl_val);
		return (-1);
	}
	return (0);
}
//结束播放或录音
void TQSoundDevice::stop()
{
	m_bStop = true;
}
