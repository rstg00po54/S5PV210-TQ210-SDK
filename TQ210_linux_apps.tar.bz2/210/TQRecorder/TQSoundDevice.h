/*
 * TQSoundDevice.h
 *
 *  Created on: Dec 19, 2011
 *      Author: root
 */

#ifndef TQSOUNDDEVICE_H_
#define TQSOUNDDEVICE_H_
#include <QObject>
#include <QThread>
class TQSoundDevice:public QThread
{
	Q_OBJECT
public:
	TQSoundDevice();
	virtual ~TQSoundDevice();
	void run();
	void playSound(QString name);
	void recordSound(QString name);
	void stop();
private:
	bool m_bStop;
	bool m_bPlay;
	bool m_bRecord;
	QString m_strFileName;
	int play(QString name);
	int record(QString name);
signals:
	void playStop(int);
	void recordStop(int);
};

#endif /* TQSOUNDDEVICE_H_ */
