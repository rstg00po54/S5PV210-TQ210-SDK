#include "tqrecorder.h"

#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	TQRecorder w;
	w.showFullScreen();
	return a.exec();
}


