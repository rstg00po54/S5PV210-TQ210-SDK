/*
 *     公司名:    	广州天嵌计算机科技有限公司
 *     项目名:     	PDA
 *     文件名:     	tqrecorder.cpp
 *    文件描述:      音频播放主界面
 *    创建日期:      2011-12-20
 *    创 建 人:      lkp
 *     文档:
 *    运行平台:      linux
 *     其他:         www.armbbs.net
 */
#include "tqrecorder.h"
#include <QLayout>
#include <QDesktopWidget>
#include <QMessageBox>
#include <QThread>
#include <QApplication>
#include <QFile>
#include <QFileDialog>
#include <iostream>
using namespace std;

TQRecorder* g_pRecord;
//---------------------------------------------------------------------------
/*
 ** 函数名称：TQRecorder
 ** 创建日期：2011-12-20
 ** 创 建 人： lkp
 ** 函数功能：构造函数
 ** 参    数：
 	 parent [in] : 父界面
 ** 返    回：无
 ** 数 据 库：无
 ** 其它说明：无
 */
TQRecorder::TQRecorder(QWidget *parent) :
	QWidget(parent)
{
	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	QRect screen_size = QApplication::desktop()->screenGeometry();
	m_iWidth = screen_size.width();
	m_iHeight = screen_size.height();

	m_ptwRecord = new QTableWidget;
	m_ptwRecord->setRowCount(1);
	m_ptwRecord->setColumnCount(2);
	m_ptwRecord->setColumnWidth(0, m_iWidth - 200);
	m_ptwRecord->setColumnWidth(1, 160);

	QPixmap pix;
	m_pbHelp = new QPushButton(trUtf8("帮助"), this);
	m_pbHelp->setText("");
	m_pbHelp->setMaximumWidth(60);
	m_pbHelp->setMaximumHeight(32);
	m_pbHelp->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));

	m_pbStartPlay = new QPushButton(trUtf8("开始播放"));

	m_pbStartPlay->setText("");
	m_pbStartPlay->setMaximumWidth(60);
	m_pbStartPlay->setMaximumHeight(32);
	m_pbStartPlay->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/startplay.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbStartPlay->setIcon(QIcon(pix));

	m_pbStopPlay = new QPushButton(trUtf8("结束播放"));

	m_pbStopPlay->setText("");
	m_pbStopPlay->setMaximumWidth(60);
	m_pbStopPlay->setMaximumHeight(32);
	m_pbStopPlay->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/stopplay.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbStopPlay->setIcon(QIcon(pix));

	m_pbStartRecord = new QPushButton(trUtf8("开始录音"));

	m_pbStartRecord->setText("");
	m_pbStartRecord->setMaximumWidth(60);
	m_pbStartRecord->setMaximumHeight(32);
	m_pbStartRecord->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/startrecord.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbStartRecord->setIcon(QIcon(pix));

	m_pbStopRecord = new QPushButton(trUtf8("结束录音"));

	m_pbStopRecord->setText("");
	m_pbStopRecord->setMaximumWidth(60);
	m_pbStopRecord->setMaximumHeight(32);
	m_pbStopRecord->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/stoprecord.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbStopRecord->setIcon(QIcon(pix));

	m_pbDelete = new QPushButton(trUtf8("删除"));
	m_pbDelete->setText("");
	m_pbDelete->setMaximumWidth(60);
	m_pbDelete->setMaximumHeight(32);
	m_pbDelete->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/delete.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbDelete->setIcon(QIcon(pix));

	m_pbSelectDir = new QPushButton(trUtf8("选择存放目录"));
	m_pbSelectDir->setText("");
	m_pbSelectDir->setMaximumWidth(60);
	m_pbSelectDir->setMaximumHeight(32);
	m_pbSelectDir->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/dir.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbSelectDir->setIcon(QIcon(pix));

	m_pbClose = new QPushButton(trUtf8("关闭"));
	m_pbClose->setText("");
	m_pbClose->setMaximumWidth(60);
	m_pbClose->setMaximumHeight(32);
	m_pbClose->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/quit.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbClose->setIcon(QIcon(pix));



	QVBoxLayout *vLayout = new QVBoxLayout;
	vLayout->addWidget(m_ptwRecord);

	QHBoxLayout *hLayout = new QHBoxLayout();
	hLayout->setMargin(0);//设置间距
	hLayout->addWidget(m_pbHelp);
	hLayout->addWidget(m_pbStartPlay);
	hLayout->addWidget(m_pbStopPlay);
	hLayout->addWidget(m_pbStartRecord);
	hLayout->addWidget(m_pbStopRecord);
	hLayout->addWidget(m_pbSelectDir);
	hLayout->addWidget(m_pbDelete);
	hLayout->addWidget(m_pbClose);

	vLayout->addLayout(hLayout);
	setLayout(vLayout);

	connect(m_pbStartRecord, SIGNAL(clicked()), this, SLOT(pbRecordClicked()));
	connect(m_pbStartPlay, SIGNAL(clicked()), this, SLOT(pbPlayClicked()));
	connect(m_pbStopPlay, SIGNAL(clicked()), this, SLOT(pbStopClicked()));
	connect(m_pbStopRecord, SIGNAL(clicked()), this, SLOT(pbStopClicked()));
	connect(m_pbSelectDir, SIGNAL(clicked()), this, SLOT(pbSelctDirClicked()));
	connect(m_pbDelete, SIGNAL(clicked()), this, SLOT(pbDeleteClicked()));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));
	connect(m_pbClose, SIGNAL(clicked()), this, SLOT(pbCloseClicked()));

	m_pThread = new TQSoundDevice;
	connect(m_pThread, SIGNAL(recordStop(int)), this, SLOT(recordStop(int)));
	connect(m_pThread, SIGNAL(playStop(int)), this, SLOT(playStop(int)));
	m_pThread->start();

	m_iReplaceColumn = -1;
	m_strDir = "/root/Documents/";
	initRecord();
}
//---------------------------------------------------------------------------
/*
 ** 函数名称： ~TQRecorder
 ** 创建日期： 2011-12-20
 ** 创 建 人： lkp
 ** 函数功能： 析构函数
 ** 参    数： 无
 ** 返    回： 无
 ** 数 据 库： 无
 ** 其它说明： 无
 */
TQRecorder::~TQRecorder()
{
	m_pThread->terminate();
	delete m_pThread;
}
void TQRecorder::pbCloseClicked()
{
	close();
}
//帮助
void TQRecorder::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
//---------------------------------------------------------------------------
/*
 ** 函数名称： initRecord
 ** 创建日期： 2011-12-20
 ** 创 建 人： lkp
 ** 函数功能： 初始化播放列表
 ** 参    数： 无
 ** 返    回： 无
 ** 数 据 库： 无
 ** 其它说明： 无
 */
void TQRecorder::initRecord()
{
	m_ptwRecord->clear();
	QStringList header;
	header.append(trUtf8("音频文件名称"));
	header.append(trUtf8("文件大小(kb)"));

	m_ptwRecord->setHorizontalHeaderLabels(header);
	m_ptwRecord->setRowCount(1);
	m_iRowCount = 0;
	QDir dir(m_strDir);
	QFileInfoList list = dir.entryInfoList(QDir::Files);
	QFileInfo info;
	foreach(info,list)
		{
			if (info.fileName().endsWith(".wav", Qt::CaseInsensitive))
			{
				m_ptwRecord->setItem(
						m_iRowCount,
						0,
						new QTableWidgetItem(
								trUtf8(info.filePath().toStdString().c_str())));
				m_ptwRecord->setItem(
						m_iRowCount,
						1,
						new QTableWidgetItem(
								QString::number(info.size() / 1024)));
				m_iRowCount++;
				m_ptwRecord->setRowCount(m_iRowCount + 1);
			}
		}
}
//播放
void TQRecorder::pbPlayClicked()
{
	if (m_ptwRecord->rowCount() > 1 && m_ptwRecord->currentRow() != m_ptwRecord->rowCount()-1)
	{
		QString str = m_ptwRecord->item(m_ptwRecord->currentRow(), 0)->text();
//		cout << str.toStdString().c_str() << endl;
		if (str.endsWith(".wav", Qt::CaseInsensitive))
		{
			m_pThread->playSound(str);

			m_pbDelete->setEnabled(false);
			m_pbStartRecord->setEnabled(false);
			m_pbStopRecord->setEnabled(false);
			m_pbStartPlay->setEnabled(false);
			m_pbStopPlay->setEnabled(true);
			m_pbSelectDir->setEnabled(false);
		}
	}
}
//录音
void TQRecorder::pbRecordClicked()
{
	m_strFileName = m_strDir + QString::number(m_iCount++) + ".wav";
	QFile f(m_strFileName);
	if (f.exists())
	{
		QString strPompt = "文件：" + m_strFileName + " 已存在，是否覆盖？";
		if (QMessageBox::Ok != QMessageBox::warning(this, trUtf8("警告"),
				trUtf8(strPompt.toStdString().c_str()),
				QMessageBox::Ok | QMessageBox::Cancel))
			return;
		else
		{
			for (int i = 0; i < m_ptwRecord->rowCount(); i++)
			{
				QString str =
						m_ptwRecord->item(m_ptwRecord->currentRow(), 0)->text();
				if (str.compare(m_strFileName) == 0)
				{
					m_iReplaceColumn = i;
					break;
				}
			}
		}
	}

	m_pThread->recordSound(m_strFileName);

	m_pbDelete->setEnabled(false);
	m_pbStartRecord->setEnabled(false);
	m_pbStopRecord->setEnabled(true);
	m_pbStartPlay->setEnabled(false);
	m_pbStopPlay->setEnabled(false);
	m_pbSelectDir->setEnabled(false);
}
//暂停录音
void TQRecorder::recordStop(int status)
{
	if (status == -1)
	{
		QMessageBox::warning(this, trUtf8("警告"), trUtf8("音频设备打开失败！"),
				QMessageBox::Ok);
	}
	else if (status == -2)
	{
		QMessageBox::warning(this, trUtf8("警告"), trUtf8("音频文件打开失败！"),
				QMessageBox::Ok);
	}
	else if (status == -3)
	{
		QMessageBox::warning(this, trUtf8("警告"), trUtf8("音频设备故障！"),
				QMessageBox::Ok);
	}
	else if (status == -4)
	{
		QMessageBox::warning(this, trUtf8("警告"), trUtf8("音频文件写入失败！"),
				QMessageBox::Ok);
	}
	else if (status == 0)
	{
		if (m_iReplaceColumn != -1)
		{
			QFile f(m_strFileName);
			m_ptwRecord->setItem(m_iReplaceColumn, 1,
					new QTableWidgetItem(QString::number(f.size() / 1024)));
		}
		else
		{
			m_ptwRecord->setItem(m_ptwRecord->rowCount() - 1, 0,
					new QTableWidgetItem(m_strFileName));

			QFile f(m_strFileName);
			m_ptwRecord->setItem(m_ptwRecord->rowCount() - 1, 1,
					new QTableWidgetItem(QString::number(f.size() / 1024)));
		}
		m_ptwRecord->setRowCount(m_ptwRecord->rowCount() + 1);
		QMessageBox::warning(this, trUtf8("信息"), trUtf8("录音结束！"),
				QMessageBox::Ok);
	}
	m_pbDelete->setEnabled(true);
	m_pbStartRecord->setEnabled(true);
	m_pbStopRecord->setEnabled(false);
	m_pbStartPlay->setEnabled(true);
	m_pbStopPlay->setEnabled(false);
	m_pbSelectDir->setEnabled(true);
}
//结束播放事件
void TQRecorder::playStop(int status)
{
	if (status == -1)
	{
		QMessageBox::warning(this, trUtf8("警告"), trUtf8("音频设备打开失败！"),
				QMessageBox::Ok);
	}
	else if (status == -2)
	{
		QMessageBox::warning(this, trUtf8("警告"), trUtf8("音频文件打开失败！"),
				QMessageBox::Ok);
	}
	else if (status == -3)
	{
		QMessageBox::warning(this, trUtf8("警告"), trUtf8("音频设备故障！"),
				QMessageBox::Ok);
	}
	else if (status == -4)
	{
		QMessageBox::warning(this, trUtf8("警告"), trUtf8("音频文件读取失败！"),
				QMessageBox::Ok);
	}
	else
	{
		QMessageBox::warning(this, trUtf8("信息"), trUtf8("播放结束！"),
				QMessageBox::Ok);
	}
	m_pbDelete->setEnabled(true);
	m_pbStartRecord->setEnabled(true);
	m_pbStopRecord->setEnabled(false);
	m_pbStartPlay->setEnabled(true);
	m_pbStopPlay->setEnabled(false);
	m_pbSelectDir->setEnabled(true);
}
//结束录音或播放
void TQRecorder::pbStopClicked()
{
	m_pThread->stop();
	m_pbDelete->setEnabled(true);
	m_pbStartRecord->setEnabled(true);
	m_pbStopRecord->setEnabled(false);
	m_pbStartPlay->setEnabled(true);
	m_pbStopPlay->setEnabled(false);
	m_pbSelectDir->setEnabled(true);
}
//选择音频文件所在目录和保存目录
void TQRecorder::pbSelctDirClicked()
{
	QFileDialog *fd = new QFileDialog();
	fd->setGeometry(0, 0, m_iWidth, m_iHeight);
	fd->setWindowTitle(trUtf8("请选择音频文件存放的目录"));
	fd->setDirectory(m_strDir);
	fd->setOptions(QFileDialog::ShowDirsOnly);
	fd->setFileMode(QFileDialog::Directory);
	fd->setNameFilter("*.wav");
	QString strFilePath = "";
	if (fd->exec() == QDialog::Accepted)
	{
		m_strDir = fd->selectedFiles()[0] + "/";
	}
	delete fd;
}
//删除音频文件
void TQRecorder::pbDeleteClicked()
{
	if (m_ptwRecord->rowCount() > 1 && m_ptwRecord->currentRow() != m_ptwRecord->rowCount()-1)
	{
		QString str = m_ptwRecord->item(m_ptwRecord->currentRow(), 0)->text();
//		cout << str.toStdString().c_str() << endl;
		QString strPrompt = "请确认是否删除音频文件：" + str + " ?";
		if (QMessageBox::Ok == QMessageBox::warning(this, trUtf8("信息"),
				trUtf8(strPrompt.toStdString().c_str()),
				QMessageBox::Ok | QMessageBox::Cancel))
		{
			QFile f(str);
			f.remove(str);
			initRecord();
		}
	}

}

