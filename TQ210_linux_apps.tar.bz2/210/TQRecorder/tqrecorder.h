#ifndef TQRECORDER_H
#define TQRECORDER_H

#include <QtGui/QWidget>
#include <QPushButton>
#include <QTableWidget>
#include <QProcess>
#include "TQSoundDevice.h"
class TQRecorder : public QWidget
{
    Q_OBJECT

public:
    TQRecorder(QWidget *parent = 0);
    ~TQRecorder();

private:

    QTableWidget *m_ptwRecord;
    QPushButton *m_pbHelp;
    QPushButton *m_pbStartPlay;
    QPushButton *m_pbStopPlay;
    QPushButton *m_pbStartRecord;
    QPushButton *m_pbStopRecord;
    QPushButton *m_pbSelectDir;
    QPushButton *m_pbDelete;
    QPushButton *m_pbClose;
    QString m_strFileName;
    QString m_strDir;
    int m_iCount;
    int m_iWidth;
    int m_iHeight;
    int m_iRowCount;
    int m_iReplaceColumn;
    TQSoundDevice *m_pThread;
    QProcess process;
    void initRecord();
public slots:
    void pbRecordClicked();
    void pbStopClicked();
    void pbPlayClicked();
    void pbSelctDirClicked();
    void pbDeleteClicked();
    void pbHelpClicked();
    void pbCloseClicked();
    void recordStop(int status);
    void playStop(int status);
};
extern TQRecorder* g_pRecord;
#endif // TQRECORDER_H
