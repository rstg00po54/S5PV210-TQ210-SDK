#include "tqsetautorun.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QDesktopWidget>
#include <QtXml>
#include<iostream>
#include<QPixmap>
#include<QHBoxLayout>
#include<QVBoxLayout>
#include<QMessageBox>
#include<QMessageBox>
using namespace std;
QStringList list_name, list_path;
TQSetAutoRun::TQSetAutoRun(QWidget *parent) :
	QWidget(parent)
{
	ui.setupUi(this);
	/*
	QLabel *labelTitle = new QLabel(trUtf8("天嵌科技开机运行测试程序"), this);
	labelTitle -> setFixedHeight(20);
	labelTitle -> setMinimumHeight(10);
	labelTitle -> setMaximumHeight(40);
	labelTitle -> setAlignment(Qt::AlignCenter);

	QLabel *labelProgranName = new QLabel(trUtf8("程序名字：")，this);

*/
	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	ui.pbCancel->setFixedSize(70, 32);
	ui.pbCancel->setIconSize(QSize(70, 32));
	QPixmap pix("/opt/PDA/app/images/cancel.png", 0, Qt::AutoColor);
	pix = pix.scaled(70, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbCancel->setIcon(QIcon(pix));
	connect(ui.pbCancel, SIGNAL(clicked()), this, SLOT(pbCancelClicked()));

	ui.pbHelp->setFixedSize(70, 32);
	ui.pbHelp->setIconSize(QSize(70, 32));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(70, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbHelp->setIcon(QIcon(pix));
	connect(ui.pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	ui.pbClose->setFixedSize(70, 32);
	ui.pbClose->setIconSize(QSize(70, 32));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(70, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbClose->setIcon(QIcon(pix));

	ui.pbConfirm->setFixedSize(70, 32);
	ui.pbConfirm->setIconSize(QSize(70, 32));
	pix.load("/opt/PDA/app/images/confirm.png", 0, Qt::AutoColor);
	pix = pix.scaled(70, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbConfirm->setIcon(QIcon(pix));

	connect(ui.pbClose, SIGNAL(clicked()), this, SLOT(close()));
	connect(ui.pbConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));

	ui.label_3->setMaximumWidth(200);
	ui.label_3->setMaximumHeight(30);
	ui.comboBox->setMaximumWidth(110);
	ui.comboBox->setMaximumHeight(30);

	ui.label_2->setMaximumWidth(105);
	ui.label_2->setMaximumHeight(30);
	ui.cbBackGround->setMaximumWidth(100);
	ui.cbBackGround->setMaximumHeight(22);

	QHBoxLayout *titleLayout = new QHBoxLayout();
	titleLayout->addStretch(0);
	titleLayout -> addWidget(ui.label_3);
	titleLayout->addStretch(0);

	QHBoxLayout *hLayoutPro = new QHBoxLayout();
	hLayoutPro->addStretch(0);
	hLayoutPro->addWidget(ui.label);
	hLayoutPro->addWidget(ui.comboBox);
	hLayoutPro->addStretch(0);

	QHBoxLayout *hLayoutRun = new QHBoxLayout();
	hLayoutRun->addStretch(0);
	hLayoutRun->addWidget(ui.label_2);
	hLayoutRun->addWidget(ui.cbBackGround);
	hLayoutRun->addStretch(0);

	QHBoxLayout *hLayoutBuntton = new QHBoxLayout();
	hLayoutBuntton->addWidget(ui.pbHelp);
	hLayoutBuntton->addWidget(ui.pbCancel);
	hLayoutBuntton->addWidget(ui.pbConfirm);
	hLayoutBuntton->addWidget(ui.pbClose);

	QVBoxLayout *vLayout = new QVBoxLayout();
	vLayout->addLayout(titleLayout);
	vLayout->addLayout(hLayoutPro);
	vLayout->addLayout(hLayoutRun);
	vLayout->addLayout(hLayoutBuntton);

	setLayout(vLayout);


	initXml();
}

TQSetAutoRun::~TQSetAutoRun()
{

}
void TQSetAutoRun::initXml()
{
	addXml("/opt/PDA/configs/app.xml");
	addXml("/opt/PDA/configs/file.xml");
	addXml("/opt/PDA/configs/game.xml");
	addXml("/opt/PDA/configs/test.xml");

	ui.comboBox->addItems(list_name);
}
void TQSetAutoRun::addXml(QString strXml)
{
	QFile xmlFile(strXml);
	if (!xmlFile.exists() || (xmlFile.error() != QFile::NoError))
	{
		qDebug() << "ERROR: Unable to open config file " << endl;
		return;
	}
	QDomDocument xmlDoc;
	xmlDoc.setContent(&xmlFile, true);
	xmlFile.close();
	QDomElement rootElement = xmlDoc.documentElement();
	QDomNodeList
			demoNodes =
					rootElement.firstChildElement("demos").elementsByTagName(
							"example");
	for (int i = 0; i < demoNodes.size(); i++)
	{
		QDomElement element = demoNodes.item(i).toElement();
		if (element.hasAttribute("filename"))
		{
			list_name
					<< trUtf8(
							element.attribute(
									"name").toStdString().c_str());
			list_path
					<< trUtf8(
							element.attribute(
									"filename").toStdString().c_str());
		}
	}

}
void TQSetAutoRun::pbConfirmClicked()
{
	QFile f("/etc/autorun.conf");
	if (f.open(QIODevice::ReadWrite))
	{
		f.resize(0);//清空文件

		QString str = list_path.at(ui.comboBox->currentIndex());
		str = str + " EmbedSky -qws";

		if (ui.cbBackGround->isChecked())
		{
			str += " &";
		}

		if (f.write(str.toStdString().c_str(), str.length())
				== str.length())
		{
			QMessageBox question;
			question.setWindowTitle(trUtf8("提示"));
			question.setText(trUtf8("设置完成,马上重启确保生效"));
			question.setInformativeText(trUtf8("是否立即重启？"));

			question.addButton(trUtf8("OK"), QMessageBox::YesRole);
			question.addButton(trUtf8("否"), QMessageBox::NoRole);

			question.setDefaultButton(QMessageBox::Yes);
			QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
			QIcon icon(pix);
			question .setWindowIcon(icon);

			int ret = question.exec();
			switch (ret) {
			case 0: {
				system("sync");
				sleep(1);
				system("sync");
				sleep(1);
				system("reboot");
			}
				break;
			case 1: {
				setCursor(Qt::ArrowCursor);
				return;
			}
				break;
			default:
				break;
			}
/*			QMessageBox::information(this, trUtf8("信息"),
					trUtf8("配置成功"), QMessageBox::Ok);*/
			return;
		}
	}

	QMessageBox warn;
	warn.setWindowTitle(trUtf8("信息"));
	warn.setText(trUtf8(f.errorString().toStdString().c_str()));
	QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
	QIcon icon(pix);
	warn .setWindowIcon(icon);
	warn.exec();
}
void TQSetAutoRun::pbCancelClicked()
{
	system("rm -f /etc/autorun.conf");

	QMessageBox warn;
	warn.setWindowTitle(trUtf8("提示"));
	warn.setText(trUtf8("取消开机运行成功！"));
	warn.setStandardButtons(QMessageBox::Ok);
	QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
	QIcon icon(pix);
	warn .setWindowIcon(icon);
	warn.exec();
}
void TQSetAutoRun::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
