#ifndef TQSETAUTORUN_H
#define TQSETAUTORUN_H

#include <QtGui/QWidget>
#include "ui_tqsetautorun.h"
#include <qprocess.h>
#include <QLabel>

class TQSetAutoRun: public QWidget
{
Q_OBJECT

public:
	TQSetAutoRun(QWidget *parent = 0);
	~TQSetAutoRun();
	void initXml();
	void addXml(QString);

private:
	Ui::TQSetAutoRunClass ui;
	QString m_strRootDir;
	int m_iWidth;
	int m_iHeight;
	QProcess process;
public slots:
	//	void pbCloseClicked();
	void pbConfirmClicked();
	void pbCancelClicked();
	void pbHelpClicked();
};

#endif // TQSETAUTORUN_H
