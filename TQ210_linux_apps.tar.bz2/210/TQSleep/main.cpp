#include "tqwait.h"

#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	g_Thread = new Thread();
	g_Thread->start();

	QRect screen_size = QApplication::desktop()->screenGeometry();
	g_wait = new TQWait();
	g_wait->setGeometry(0, 0, screen_size.width(), screen_size.height());
	g_wait->hide();
	return a.exec();
}
