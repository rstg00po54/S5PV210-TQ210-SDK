/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		GpsThread
 *    文件名:     	 GpsThread.cpp
 *    文件描述:  		gps读取数据线程
 *    创建日期:      2011-06-27
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */
#include "Thread.h"
#include <fcntl.h>
#include <math.h>
//#include<iostream>
//using namespace std;

static int fd;

Thread *g_Thread;
Thread::Thread()
{
	fd = open("/dev/tq6410-button", O_RDWR);
	if (fd < 0)
	{
		exit(1);
	}
}
Thread::~Thread()
{
}
//线程函数
void Thread::run()
{
	while (1)
	{
		int ibuffer=0;
		int len = read(fd, &ibuffer, sizeof(ibuffer));//读ad转换后的数据

		emit Readdata(ibuffer);
		msleep(100);
	}
}
