/*
 * uIDReaderThread.h
 *
 *  Created on: 2011-6-27
 *      Author: root
 */

#ifndef UIDREADERTHREAD_H_
#define UIDREADERTHREAD_H_
#include <QThread>
#include <QObject>

class Thread: public QThread
{
	Q_OBJECT
public:
	Thread();
	virtual ~Thread();
	void run();



	signals:
	void Readdata(int);

};
extern Thread *g_Thread;
#endif /* UIDREADERTHREAD_H_ */
