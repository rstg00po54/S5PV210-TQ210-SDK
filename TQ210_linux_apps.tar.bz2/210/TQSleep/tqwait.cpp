#include "tqwait.h"
#include <QMessageBox>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/fs.h>
#include <errno.h>
#include<QTimer>
#include<iostream>
#include<QHBoxLayout>
using namespace std;
#define APM_IOC_SUSPEND  _IO('A',2)
static int fd_sleep;
static int fd_shutdown;
bool bShowSleep;
TQWait *g_wait;
TQWait::TQWait(QWidget *parent) :
	QWidget(parent)
{
	ui.setupUi(this);

	bShowSleep = true;

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);
	setWindowFlags(Qt::WindowStaysOnTopHint);

	m_pbShutDown = new QPushButton(this);
	m_pbShutDown->setFixedSize(38, 52);
	m_pbShutDown->setIconSize(QSize(38, 52));
	QPixmap pix("/opt/PDA/app/images/shutdown.png", 0, Qt::AutoColor);
	pix = pix.scaled(38, 52, Qt::IgnoreAspectRatio);//图片大小
	m_pbShutDown->setIcon(QIcon(pix));

	m_pbReStart = new QPushButton(this);
	m_pbReStart->setFixedSize(38, 52);
	m_pbReStart->setIconSize(QSize(38, 52));
	pix.load("/opt/PDA/app/images/restart.png", 0, Qt::AutoColor);
	pix = pix.scaled(38, 52, Qt::IgnoreAspectRatio);//图片大小
	m_pbReStart->setIcon(QIcon(pix));

	m_pbSleep = new QPushButton(this);
	m_pbSleep->setFixedSize(38, 52);
	m_pbSleep->setIconSize(QSize(38, 52));
	pix.load("/opt/PDA/app/images/sleep.png", 0, Qt::AutoColor);
	pix = pix.scaled(38, 52, Qt::IgnoreAspectRatio);//图片大小
	m_pbSleep->setIcon(QIcon(pix));

	m_pbCancel = new QPushButton(this);
	m_pbCancel->setFixedSize(38, 52);
	m_pbCancel->setIconSize(QSize(38, 52));
	pix.load("/opt/PDA/app/images/cancelShutSleep.png", 0, Qt::AutoColor);
	pix = pix.scaled(38, 52, Qt::IgnoreAspectRatio);//图片大小
	m_pbCancel->setIcon(QIcon(pix));

	QHBoxLayout *nameLayout = new QHBoxLayout;
	nameLayout->addSpacing(99);//
	nameLayout->addWidget(m_pbReStart);
	nameLayout->addWidget(m_pbSleep);
	nameLayout->addWidget(m_pbCancel);
	nameLayout->addWidget(m_pbShutDown);
	nameLayout->addSpacing(99);

	setLayout(nameLayout);

connect(g_Thread, SIGNAL(Readdata(int)), this, SLOT(ReaddataSlot(int)));

}

TQWait::~TQWait()
{

}
void TQWait::ReaddataSlot(int data)
{
	if (data > 0)
	{
		bShowSleep = !bShowSleep;
		if (bShowSleep == false)
		{
			g_wait->show();

			connect(m_pbShutDown, SIGNAL(clicked()), this,
					SLOT(ShutDownClicked()));
			connect(m_pbSleep, SIGNAL(clicked()), this,
					SLOT(SleepClicked()));
			connect(m_pbCancel, SIGNAL(clicked()), this,
					SLOT(CancelClicked()));
			connect(m_pbReStart, SIGNAL(clicked()), this,
					SLOT(ReStartClicked()));

			fd_shutdown = open("/dev/tq6410-shutdown", O_RDWR);
			if (fd_shutdown < 0)
			{
				QMessageBox question;
				question.setWindowTitle(trUtf8("警告"));
				question.setText(trUtf8("未找到关机驱动"));
				QPixmap pix("/opt/PDA/app/images/EmbedSky.png",
						0, Qt::AutoColor);
				QIcon icon(pix);
				question .setWindowIcon(icon);
				question.exec();
				g_wait->hide();
			}
			else
				ioctl(fd_shutdown, 1, 0);
		}
		else
		{
			g_wait->hide();
			ioctl(fd_shutdown, 0, 0);
			disconnect(m_pbShutDown, SIGNAL(clicked()), 0, 0);
			disconnect(m_pbSleep, SIGNAL(clicked()), 0, 0);
			disconnect(m_pbCancel, SIGNAL(clicked()), 0, 0);
			disconnect(m_pbReStart, SIGNAL(clicked()), 0, 0);
		}
	}
}
void TQWait::ReStartClicked()
{
	g_wait->hide();
	system("sync");
	system("reboot");
}
void TQWait::ShutDownClicked()
{
	if (system("sync") == 0)
	{
		ioctl(fd_shutdown, 1, 0);
	}
	else
	{
		QMessageBox question;
		question.setWindowTitle(trUtf8("警告"));
		question.setText(trUtf8("关机未成功"));
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0,
				Qt::AutoColor);
		QIcon icon(pix);
		question .setWindowIcon(icon);
		question.exec();
	}

}
void TQWait::SleepClicked()
{
	disconnect(m_pbShutDown, SIGNAL(clicked()), 0, 0);
	disconnect(m_pbSleep, SIGNAL(clicked()), 0, 0);
	disconnect(m_pbCancel, SIGNAL(clicked()), 0, 0);
	disconnect(m_pbReStart, SIGNAL(clicked()), 0, 0);

	fd_sleep = open("/dev/apm_bios", O_RDWR);

	if (fd_sleep < 0)
	{
		QMessageBox question;
		question.setWindowTitle(trUtf8("警告"));
		question.setText(trUtf8("未找到休眠驱动"));
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0,
				Qt::AutoColor);
		QIcon icon(pix);
		question .setWindowIcon(icon);
		question.exec();

		g_wait->hide();
	}
	else
	{
		g_wait->hide();
		bShowSleep = true;
//		system("killall mplayer");
//		system("killall tqmediaplayer");
		system("sync");
		ioctl(fd_sleep, APM_IOC_SUSPEND);
	}
}
void TQWait::CancelClicked()
{
	bShowSleep = true;
	g_wait->hide();
	ioctl(fd_shutdown, 0, 0);
	::close(fd_shutdown);
	::close(fd_sleep);
	disconnect(m_pbShutDown, SIGNAL(clicked()), 0, 0);
	disconnect(m_pbSleep, SIGNAL(clicked()), 0, 0);
	disconnect(m_pbCancel, SIGNAL(clicked()), 0, 0);//
	disconnect(m_pbReStart, SIGNAL(clicked()), 0, 0);
}
