#ifndef TQWAIT_H
#define TQWAIT_H

#include <QtGui/QWidget>
#include "ui_tqwait.h"
#include "thread/Thread.h"
#include<QPushButton>

class TQWait: public QWidget
{
	Q_OBJECT

public:
	TQWait(QWidget *parent = 0);
	~TQWait();
	//	void show();

	//public slots:
	//	void init();

public	slots:
	void ReaddataSlot(int);
	void ReStartClicked();
	void ShutDownClicked();
	void SleepClicked();
	void CancelClicked();

private:
	Ui::TQWaitClass ui;

	QPushButton *m_pbReStart;
	QPushButton *m_pbShutDown;
	QPushButton *m_pbSleep;
	QPushButton *m_pbCancel;
};
extern TQWait *g_wait;
#endif // TQWAIT_H
