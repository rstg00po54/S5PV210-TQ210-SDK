/********************************************************************************
** Form generated from reading UI file 'tqwait.ui'
**
** Created: Thu Jun 14 15:59:44 2012
**      by: Qt User Interface Compiler version 4.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TQWAIT_H
#define UI_TQWAIT_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TQWaitClass
{
public:

    void setupUi(QWidget *TQWaitClass)
    {
        if (TQWaitClass->objectName().isEmpty())
            TQWaitClass->setObjectName(QString::fromUtf8("TQWaitClass"));
        TQWaitClass->resize(400, 300);

        retranslateUi(TQWaitClass);

        QMetaObject::connectSlotsByName(TQWaitClass);
    } // setupUi

    void retranslateUi(QWidget *TQWaitClass)
    {
        TQWaitClass->setWindowTitle(QApplication::translate("TQWaitClass", "TQWait", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class TQWaitClass: public Ui_TQWaitClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TQWAIT_H
