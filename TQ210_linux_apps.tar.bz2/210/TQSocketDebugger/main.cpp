#include "tqsocketdebugger.h"

#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));

	bool bShowKey = false;
	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "EmbedSky") == 0)
		{
			g_tqsocketdebugger = new TQSocketDebugger(0, 1);
			bShowKey = true;
			break;
		}
	}
	if (!bShowKey)
		g_tqsocketdebugger = new TQSocketDebugger(0, 0);

	g_tqsocketdebugger->showFullScreen();

	return a.exec();
}
