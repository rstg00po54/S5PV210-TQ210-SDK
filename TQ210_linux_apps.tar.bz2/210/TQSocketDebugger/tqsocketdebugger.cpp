#include "tqsocketdebugger.h"
#include <QRegExp>
#include <QMessageBox>
#include <iostream>
using namespace std;

#include <QVBoxLayout>
#include <QHBoxLayout>

int str2Hex(unsigned char *buf, unsigned char *hex, int sLen);

char *ByteToStr(const unsigned char *pIn, char *pOut, int len);
TQSocketDebugger *g_tqsocketdebugger;

TQSocketDebugger::TQSocketDebugger(QWidget *parent, bool bShowKey) :
	QWidget(parent)
{
	setAttribute(Qt::WA_DeleteOnClose);

	m_bFlg = false;
	m_pClient = new QTcpSocket;
	m_pSrv = new QTcpServer;
	m_pConnClient = NULL;

	m_lbMessage = new QLabel(this);
	//m_lb = QLabel(this);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	//标题
	m_titlelabel = new QLabel(trUtf8("天嵌科技网络数据"), this);
	m_titlelabel->setAlignment(Qt::AlignCenter);

	m_pbKey = new QPushButton(this);
	m_pbKey->setFixedSize(60, 25);
	m_pbKey->setIconSize(QSize(60, 25));
	QPixmap pix("/opt/PDA/app/images/key.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 25, Qt::IgnoreAspectRatio);//图片大小
	m_pbKey->setIcon(QIcon(pix));

	m_pAutoSend = new QTimer;
	connect(m_pAutoSend, SIGNAL(timeout()), this, SLOT(autoSend()));

	//	m_tabWidget->setGeometry(0, 0, 800, 600);
	//	m_tabWidget->widget(0)->setGeometry(0, 0, 800, 600);
	//	m_tabWidget->widget(1)->setGeometry(0, 0, 800, 600);
	m_tabWidget	= new QTabWidget();
	m_tabWidget->setTabPosition(QTabWidget::West);
	m_tabWidget->addTab(new QWidget, trUtf8("客户端"));
	m_tabWidget->addTab(new QWidget, trUtf8("服务器"));
	m_tabWidget->setCurrentIndex(0);

	m_teSend		= new QTextEdit(m_tabWidget->widget(0));
	m_teSend_Srv	= new QTextEdit(m_tabWidget->widget(1));

	//m_teSend = new QTextEdit();
	//m_teSend_Srv = new QTextEdit();
	//m_teSend_Srv->show();

	//127.0.0.1
	m_lbIp = new QLabel(trUtf8("服务器IP:"), this);
	m_leIP = new QLineEdit(m_tabWidget->widget(0));
	m_leIP->setText("127.0.0.1");

	m_lbPort = new QLabel(trUtf8("端口:"), this);
	m_lePort = new QLineEdit(m_tabWidget->widget(0));
	m_lePort->setText("5001");

	m_lbSrvPort = new QLabel(trUtf8("端口:"), this);
	m_lePort_Srv = new QLineEdit(m_tabWidget->widget(1));
	m_lePort_Srv->setText("5001");

	m_pbClearRecv = new QPushButton(this);
	m_pbClearRecv->setFixedSize(65, 30);
	m_pbClearRecv->setIconSize(QSize(65, 30));
	pix.load("/opt/PDA/app/images/clearRec.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbClearRecv->setIcon(QIcon(pix));

	m_pbClearSend = new QPushButton(this);
	m_pbClearSend->setFixedSize(65, 30);
	m_pbClearSend->setIconSize(QSize(65, 30));
	pix.load("/opt/PDA/app/images/clearSend.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbClearSend->setIcon(QIcon(pix));

	m_pbConnect = new QPushButton(this);
	m_pbConnect->setFixedSize(65, 30);
	m_pbConnect->setIconSize(QSize(65, 30));
	pix.load("/opt/PDA/app/images/connect.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbConnect->setIcon(QIcon(pix));

	m_pbSend = new QPushButton(this);
	m_pbSend->setFixedSize(65, 30);
	m_pbSend->setIconSize(QSize(65, 30));
	pix.load("/opt/PDA/app/images/send.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbSend->setIcon(QIcon(pix));

	m_pbClose = new QPushButton(this);
	m_pbClose->setFixedSize(65, 30);
	m_pbClose->setIconSize(QSize(65, 30));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbClose->setIcon(QIcon(pix));

	m_pbStart = new QPushButton(this);
	m_pbStart->setFixedSize(60, 25);
	m_pbStart->setIconSize(QSize(60, 25));
	pix.load("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 25, Qt::IgnoreAspectRatio);//图片大小
	m_pbStart->setIcon(QIcon(pix));
	bStartSrv = 1;

	m_pbClearRecv_Srv = new QPushButton(this);
	m_pbClearRecv_Srv->setFixedSize(60, 25);
	m_pbClearRecv_Srv->setIconSize(QSize(60, 25));
	pix.load("/opt/PDA/app/images/clearRec.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 25, Qt::IgnoreAspectRatio);//图片大小
	m_pbClearRecv_Srv->setIcon(QIcon(pix));

	m_pbClearSend_Srv = new QPushButton(this);
	m_pbClearSend_Srv->setFixedSize(60, 25);
	m_pbClearSend_Srv->setIconSize(QSize(60, 25));
	pix.load("/opt/PDA/app/images/clearSend.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 25, Qt::IgnoreAspectRatio);//图片大小
	m_pbClearSend_Srv->setIcon(QIcon(pix));

	m_pbExit = new QPushButton(this);
	m_pbExit->setFixedSize(60, 25);
	m_pbExit->setIconSize(QSize(60, 25));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 25, Qt::IgnoreAspectRatio);//图片大小
	m_pbExit->setIcon(QIcon(pix));

	m_pbHelp = new QPushButton(this);
	m_pbHelp->setFixedSize(60, 25);
	m_pbHelp->setIconSize(QSize(60, 25));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 25, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	m_leTimeInterval = new QLineEdit(this);
	m_leTimeInterval->setText("1000");

	m_lbMessage_Srv = new QLabel(trUtf8("未启动服务"), this);

	m_teRecv 		= new QTextEdit(trUtf8(""), this);
	m_teRecv_Srv 	= new QTextEdit(trUtf8(""), this);

	m_cbRecvHex 		= new QCheckBox(this);
	m_lbRecvHex 		= new QLabel(trUtf8("Hex接收"), this);
	m_cbSendHex 		= new QCheckBox(this);
	m_lbSendHex			= new QLabel(trUtf8("Hex发送"), this);
	m_cbAutoSend 		= new QCheckBox(this);
	m_lbAutoSend 		= new QLabel(trUtf8("自动发送"), this);

	m_lbms				= new QLabel(trUtf8("ms"), this);

	m_cbRecvHex_Srv 	= new QCheckBox(this);
	m_lbRecvHex_Srv		= new QLabel(trUtf8("Hex接收"), this);
	m_cbSendHex_Srv 	= new QCheckBox(this);
	m_lbSendHex_Srv		= new QLabel(trUtf8("Hex发送"), this);
	m_cbAutoReturn		= new QCheckBox(this);
	m_lbAutoReturn 		= new QLabel(trUtf8("自动回复"), this);

	m_cbLongSck			= new QCheckBox(this);
	m_lbLongSck	 		= new QLabel(trUtf8("保持连接"), this);

	QRegExp rx("-?\\d{0,9}");
	QRegExpValidator *exp = new QRegExpValidator(rx, this);
	m_lePort->setValidator(exp);
	m_lePort_Srv->setValidator(exp);
	m_leTimeInterval->setValidator(exp);
	//m_leTimeInterval_Srv->setValidator(exp);



	connect(m_teSend, SIGNAL(textChanged()), this, SLOT(textChanged()));
	connect(m_teSend_Srv, SIGNAL(textChanged()), this, SLOT(textChanged()));

	connect(m_cbAutoSend, SIGNAL(stateChanged(int)), this,
			SLOT(autoSendStateChanged()));

	connect(m_pbClose, SIGNAL(clicked()), this, SLOT(pbExitClicked()));
	connect(m_pbExit, SIGNAL(clicked()), this, SLOT(pbExitClicked()));
	connect(m_pbStart, SIGNAL(clicked()), this, SLOT(pbStartClicled()));
	connect(m_pbConnect, SIGNAL(clicked()), this, SLOT(pbConnectClicked()));
	connect(m_pbSend, SIGNAL(clicked()), this, SLOT(pbSendClicked()));

	connect(m_pbClearRecv, SIGNAL(clicked()), this, SLOT(pbClearRecvClicked()));
	connect(m_pbClearRecv_Srv, SIGNAL(clicked()), this,
			SLOT(pbClearRecvClicked()));

	connect(m_pbClearSend, SIGNAL(clicked()), this, SLOT(pbClearSendClicked()));
	connect(m_pbClearSend_Srv, SIGNAL(clicked()), this,
			SLOT(pbClearSendClicked()));

	connect(m_pClient, SIGNAL(stateChanged(QAbstractSocket::SocketState)),
			this, SLOT(stateChanged(QAbstractSocket::SocketState)));

	connect(m_pClient, SIGNAL(readyRead()), this, SLOT(readFromServer()));
	connect(m_pSrv, SIGNAL(newConnection()), this, SLOT(newConnection()));

	connect(m_cbRecvHex, SIGNAL(stateChanged(int)), this, SLOT(cbDisplayStateChanged()));
	connect(m_cbSendHex, SIGNAL(stateChanged(int)), this,
			SLOT(cbSendStateChanged()));///////////////////////////////

	connect(m_cbRecvHex_Srv, SIGNAL(stateChanged(int)), this,
			SLOT(cbSrvDisplayStateChanged()));

	connect(m_cbSendHex_Srv, SIGNAL(stateChanged(int)), this,
			SLOT(cbSrvSendStateChanged()));////////////////////////////////////////////////

	m_pbKey->setEnabled(0);
	if (bShowKey)
	{
		m_pbKey->setEnabled(1);
		connect(m_pbKey, SIGNAL(clicked()), this, SLOT(pbKeyShowHide()));

		im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(false);

	}

	QHBoxLayout *cHeadLayout = new QHBoxLayout();
	cHeadLayout->addWidget(m_lbIp);
	cHeadLayout->addWidget(m_leIP);
	cHeadLayout->addWidget(m_lbPort);
	cHeadLayout->addWidget(m_lePort);


	QHBoxLayout *cMidLayout = new QHBoxLayout();
	cMidLayout->addWidget(m_cbSendHex);
	cMidLayout->addWidget(m_lbSendHex);
	cMidLayout->addWidget(m_cbRecvHex);
	cMidLayout->addWidget(m_lbRecvHex);
	cMidLayout->addWidget(m_cbAutoSend);
	cMidLayout->addWidget(m_lbAutoSend);
	cMidLayout->addWidget(m_leTimeInterval);
	cMidLayout->addWidget(m_lbms);
	cMidLayout->addWidget(m_pbKey);

	QHBoxLayout *cBtnLayout = new QHBoxLayout();
	cBtnLayout->addWidget(m_pbConnect);
	cBtnLayout->addWidget(m_pbSend);
	cBtnLayout->addWidget(m_pbClearRecv);
	cBtnLayout->addWidget(m_pbClearSend);
	cBtnLayout->addWidget(m_pbHelp);
	cBtnLayout->addWidget(m_pbClose);

	QVBoxLayout *cvMidLayout = new QVBoxLayout();
	cvMidLayout->addLayout(cHeadLayout);
	cvMidLayout->addWidget(m_teRecv);
	cvMidLayout->addLayout(cMidLayout);
	cvMidLayout->addWidget(m_teSend);
	cvMidLayout->addLayout(cBtnLayout);
	cvMidLayout->addWidget(m_lbMessage);

	m_teSend->setText("This is test text!");
	m_tabWidget->widget(0)->setLayout(cvMidLayout);


	QHBoxLayout *sHeadLayout = new QHBoxLayout();
	sHeadLayout->addWidget(m_lbSrvPort);
	sHeadLayout->addWidget(m_lePort_Srv);
	sHeadLayout->addWidget(m_cbLongSck);
	sHeadLayout->addWidget(m_lbLongSck);
	sHeadLayout->addWidget(m_pbStart);
	sHeadLayout->addWidget(m_pbClearRecv_Srv);
	sHeadLayout->addWidget(m_pbClearSend_Srv);
	sHeadLayout->addWidget(m_pbExit);

	QHBoxLayout *sMidLayout = new QHBoxLayout();
	sMidLayout->addWidget(m_cbSendHex_Srv);
	sMidLayout->addWidget(m_lbSendHex_Srv);
	sMidLayout->addWidget(m_cbRecvHex_Srv);
	sMidLayout->addWidget(m_lbRecvHex_Srv);
	sMidLayout->addWidget(m_cbAutoReturn);
	sMidLayout->addWidget(m_lbAutoReturn);

	QVBoxLayout *svMidLayout = new QVBoxLayout();
	svMidLayout->addLayout(sHeadLayout);
	svMidLayout->addWidget(m_teRecv_Srv);
	svMidLayout->addLayout(sMidLayout);
	svMidLayout->addWidget(m_teSend_Srv);
	svMidLayout->addWidget(m_lbMessage_Srv);

	m_tabWidget->widget(1)->setLayout(svMidLayout);

	QVBoxLayout *vLayout = new QVBoxLayout();
	vLayout->addWidget(m_titlelabel);
	vLayout->addWidget(m_tabWidget);
	setLayout(vLayout);

}
TQSocketDebugger::~TQSocketDebugger()
{
	delete m_pClient;
	delete m_pSrv;
	delete m_pAutoSend;
}
//自动发送
void TQSocketDebugger::autoSendStateChanged()
{

	if (m_cbAutoSend->isChecked())
	{
/*		m_cbRecvHex_Srv->setEnabled(false);
		m_cbRecvHex->setEnabled(false);
		m_lbRecvHex_Srv->setEnabled(false);
		m_lbRecvHex->setEnabled(false);
		m_lbSendHex->setEnabled(false);
		m_lbSendHex_Srv->setEnabled(false);
		m_cbSendHex->setEnabled(false);
		m_cbSendHex_Srv->setEnabled(false);*/

		if (m_leTimeInterval->text().length() > 0)
			m_pAutoSend->start(m_leTimeInterval->text().toInt());
	}
	else
	{
		m_pAutoSend->stop();
/*		m_cbRecvHex_Srv->setEnabled(true);
		m_cbRecvHex->setEnabled(true);
		m_lbRecvHex_Srv->setEnabled(true);
		m_lbRecvHex->setEnabled(true);
		m_lbSendHex->setEnabled(true);
		m_lbSendHex_Srv->setEnabled(true);
		m_cbSendHex->setEnabled(true);
		m_cbSendHex_Srv->setEnabled(true);*/
	}
}
//限制发送数据的长度
void TQSocketDebugger::textChanged()
{
	QTextEdit *te = qobject_cast<QTextEdit *> (sender());
	if (te->toPlainText().length() > 2048)
	{
		te->setText(te->toPlainText().mid(0, te->toPlainText().length() - 1));
		QTextCursor cursor = te->textCursor();
		cursor.movePosition(QTextCursor::End);
		te->setTextCursor(cursor);
	}
}
//启动监听
void TQSocketDebugger::pbStartClicled()
{
	//	if (strcmp(m_pbStart->text().toUtf8().data(), "启动") == 0)
	if (bStartSrv == 1)
	{
		if (m_lePort_Srv->text() == "")
		{
			QMessageBox::warning(this, trUtf8("信息"), trUtf8("请输入端口号!"),
					QMessageBox::Ok);
			return;
		}
		if (!m_pSrv->listen(QHostAddress::Any, m_lePort_Srv->text().toInt()))
		{
			QMessageBox::warning(this, trUtf8("信息"),
					trUtf8("服务启动失败，请检查端口是否被占用!"), QMessageBox::Ok);
			return;
		}
		connect(m_pSrv, SIGNAL(newConnection()), this, SLOT(newConnection()));
		m_lbMessage_Srv->setText(trUtf8("服务启动"));
		m_pbStart->setFixedSize(60, 25);
		m_pbStart->setIconSize(QSize(60, 25));
		QPixmap pix("/opt/PDA/app/images/pause.png", 0, Qt::AutoColor);
		pix = pix.scaled(60, 25, Qt::IgnoreAspectRatio);//图片大小
		m_pbStart->setIcon(QIcon(pix));
		bStartSrv = 0;
	}
	else
	{
		m_pSrv->close();
		if (m_pConnClient)
			m_pConnClient->close();
		m_pbStart->setFixedSize(60, 25);
		m_pbStart->setIconSize(QSize(60, 25));
		QPixmap pix("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
		pix = pix.scaled(60, 25, Qt::IgnoreAspectRatio);//图片大小
		m_pbStart->setIcon(QIcon(pix));
		bStartSrv = 1;
		m_lbMessage_Srv->setText(trUtf8("服务停止"));
	}
}
//定时器发送

void TQSocketDebugger::autoSend()
{
	if (bStartSrv == 0)
		pbSendClicked();
}
//有客户端连接
void TQSocketDebugger::pbConnectClicked()
{
	if (m_pClient->state() == QAbstractSocket::ConnectedState)
	{
		m_pClient->disconnectFromHost();

		m_pbConnect->setFixedSize(65, 30);
		m_pbConnect->setIconSize(QSize(65, 30));
		QPixmap pix("/opt/PDA/app/images/connect.png", 0, Qt::AutoColor);
		pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
		m_pbConnect->setIcon(QIcon(pix));
		m_bFlg = false;

	}
	else
	{
		m_pClient->connectToHost(m_leIP->text(), m_lePort->text().toInt());
		m_bFlg = true;
		m_pbConnect->setFixedSize(65, 30);
		m_pbConnect->setIconSize(QSize(65, 30));
		QPixmap pix("/opt/PDA/app/images/pause.png", 0, Qt::AutoColor);
		pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
		m_pbConnect->setIcon(QIcon(pix));
	}
}
void TQSocketDebugger::stateChanged(QAbstractSocket::SocketState socketState)
{


	switch (socketState)
	{
	case QAbstractSocket::UnconnectedState:
	{
		m_lbMessage->setText(trUtf8("连接失败"));
		m_pbConnect->setFixedSize(65, 30);
		m_pbConnect->setIconSize(QSize(65, 30));
		QPixmap pix("/opt/PDA/app/images/connect.png", 0, Qt::AutoColor);
		pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
		m_pbConnect->setIcon(QIcon(pix));
		if(m_bFlg)
		{
			if(m_cbAutoReturn->isChecked())
			{
				m_pClient->connectToHost(m_leIP->text(), m_lePort->text().toInt());
				if (m_pClient->state() == QAbstractSocket::ConnectedState)
				{
					m_pbConnect->setFixedSize(65, 30);
					m_pbConnect->setIconSize(QSize(65, 30));
					QPixmap pix("/opt/PDA/app/images/pause.png", 0, Qt::AutoColor);
					pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
					m_pbConnect->setIcon(QIcon(pix));
				}
				else
				{
					m_pbConnect->setFixedSize(65, 30);
					m_pbConnect->setIconSize(QSize(65, 30));
					QPixmap pix("/opt/PDA/app/images/connect.png", 0, Qt::AutoColor);
					pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
					m_pbConnect->setIcon(QIcon(pix));
				}
			}
		}
	}
		break;
	case QAbstractSocket::HostLookupState:
	case QAbstractSocket::BoundState:
		break;
	case QAbstractSocket::ConnectingState:
		m_lbMessage->setText(trUtf8("正在连接"));
		break;
	case QAbstractSocket::ConnectedState:
	{
		m_lbMessage->setText(trUtf8("连接成功"));
		m_pbConnect->setFixedSize(65, 30);
		m_pbConnect->setIconSize(QSize(65, 30));
		QPixmap pix("/opt/PDA/app/images/cancel.png", 0, Qt::AutoColor);
		pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
	}
		break;
	case QAbstractSocket::ClosingState:
	{
		m_lbMessage->setText(trUtf8("连接关闭"));
		m_pbConnect->setFixedSize(65, 30);
		m_pbConnect->setIconSize(QSize(65, 30));
		QPixmap pix("/opt/PDA/app/images/connect.png", 0, Qt::AutoColor);
		pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
		m_pbConnect->setIcon(QIcon(pix));
	}
		break;
	default:
		break;
	}
}
//发送数据
void TQSocketDebugger::pbSendClicked()
{
	//pbConnectClicked();
	if (m_pClient->state() == QAbstractSocket::ConnectedState)
	{
		if (m_teSend->toPlainText().length() > 0)
		{
			QString str = m_teSend->toPlainText();
			str = str.remove(' ');
			if (m_cbSendHex->isChecked())
			{
				char cData[4096];
				char *p_str = str.toLocal8Bit().data();
				int iCount = 0;
				printf("*****%s*******\n",p_str);
				iCount = str2Hex((unsigned char *) p_str,
						(unsigned char *) cData, str.toUtf8().length());
				printf("*****%s*******\n",cData);
				m_pClient->write(cData, iCount);
			}
			else
			{
				m_pClient->write(str.toStdString().c_str(),
						str.toUtf8().length());
			}
		}
	}
	else
	{
		m_lbMessage->setText(trUtf8("请先连接服务器！"));
	}
}

//有客户端连接
void TQSocketDebugger::newConnection()
{
	//cout<<"33333333333333"<<endl;
	if (m_pSrv->hasPendingConnections())
	{
		m_pConnClient = m_pSrv->nextPendingConnection();
		//cout << m_pConnClient->peerAddress().toString().toStdString().c_str()
		//		<< endl;
		//		cout << m_pConnClient->peerPort() << endl;
		QString str = "客户端：" + m_pConnClient->peerAddress().toString()
				+ " 连接，端口：" + QString::number(m_pConnClient->peerPort());
		m_lbMessage_Srv->setText(trUtf8(str.toStdString().c_str()));

		connect(m_pConnClient, SIGNAL(readyRead()), this, SLOT(readClient()));
	}
}
//服务器返回数据
void TQSocketDebugger::readFromServer()
{
	char cData[4096];
	int iCount = 0;
	//回复
	memset(cData, 0x00, sizeof(cData));
	if ((iCount = m_pClient->read(cData, 2048)) > 0)
	{
		if (m_cbRecvHex->isChecked())
		{
			char cTemp[4096];
			ByteToStr((const unsigned char*) cData, cTemp, iCount);
			m_teRecv->setText(
					m_teRecv->toPlainText() + QString(cTemp).mid(0,
							sizeof(cTemp)));
		}
		else
			m_teRecv->setText(m_teRecv->toPlainText() + cData);
	}
	//	cout << "读取到的回复：" << iCount << endl;
	//长连接
	if (!m_cbLongSck->isChecked())
	{
		m_pClient->disconnectFromHost();
	}
}
//读取客户端数据
void TQSocketDebugger::readClient()
{
	char cData[2048];
	memset(cData, 0x00, sizeof(cData));
	int iReadLen = m_pConnClient->read(cData, sizeof(cData));
	//	cout << "读取到的长度：" << iReadLen << endl;
	if (iReadLen > 0)
	{
		if (m_teRecv_Srv->toPlainText().length() > 20000)
			m_teRecv_Srv->clear();
		if (m_cbRecvHex_Srv->isChecked())
		{
			char cTemp[4096];
			ByteToStr((const unsigned char*) cData, cTemp, iReadLen);
			m_teRecv_Srv->setText(
					m_teRecv_Srv->toPlainText() + QString(cTemp).mid(0,
							sizeof(cTemp)));
		}
		else
		{
			QString str_Recv_Srv(cData);

			m_teRecv_Srv->setText(
					m_teRecv_Srv->toPlainText() + str_Recv_Srv.toUtf8().data());
		}

		//自动回复
		if (m_cbAutoReturn->isChecked())
		{
			//			cout<<"zidong fasong"<<endl;
			if (m_teSend_Srv->toPlainText().length() > 0)
			{
				QString str = m_teSend_Srv->toPlainText();
				//cout << "自动回复" << str.length() << endl;
				if (m_cbSendHex_Srv->isChecked())
				{
					str = str.remove(' ');
					char cData[4096];
					char *p_str = str.toLocal8Bit().data();
					printf("@@@@@@@@@%s@@@@@@@22\n",p_str);
					int iCount = 0;
					iCount = str2Hex((unsigned char *) p_str,
							(unsigned char *) cData, str.toUtf8().length());
					printf("#######%s#######333\n",cData);
					m_pConnClient->write(cData, iCount);
				}
				else
					m_pConnClient->write(str.toStdString().c_str(),
							str.toUtf8().length());
			}
		}
	}
}
//清空接收
void TQSocketDebugger::pbClearRecvClicked()
{
	QPushButton *btn = qobject_cast<QPushButton *> (sender());
	if (btn == m_pbClearRecv)
	{
		m_teRecv->clear();
	}
	else if (btn == m_pbClearRecv_Srv)
	{
		m_teRecv_Srv->clear();
	}
}
void TQSocketDebugger::pbClearSendClicked()
{
	QPushButton *btn = qobject_cast<QPushButton *> (sender());
	if (btn == m_pbClearSend)
	{
		m_teSend->clear();
	}
	else if (btn == m_pbClearSend_Srv)
	{
		m_teSend_Srv->clear();
	}
}
//hex显示

//hex显示
void TQSocketDebugger::cbSendStateChanged()
{

	if  (!m_cbSendHex->isChecked())
	{
		QString str = m_teSend->toPlainText();
		str = str.remove(' ');
		char cData[str.toUtf8().length()];
		int iCount = str2Hex((unsigned char *) str.toUtf8().data(),
				(unsigned char *) cData, str.toUtf8().length());

		m_teSend->clear();
		m_teSend->setPlainText(
				trUtf8(QString(cData).mid(0, iCount).toStdString().c_str()));
	}
	else
	{
		//hex 显示
		QString str = m_teSend->toPlainText();
		cout << "lenth->" << str.toUtf8().length() << endl;
		//		str=str.remove('\n');
		char cTemp[str.toUtf8().length() * 3];
		ByteToStr((const unsigned char*) str.toUtf8().data(), cTemp,
				str.toUtf8().length());
		m_teSend->clear();
		m_teSend->append(QString(cTemp).mid(0, str.toUtf8().length() * 3));

	}
}

void TQSocketDebugger::cbDisplayStateChanged()
{
	if  (!m_cbRecvHex->isChecked())
	{
		QString str = m_teRecv->toPlainText();
		str = str.remove(' ');
		char cData[str.toUtf8().length()];
		int iCount = str2Hex((unsigned char *) str.toUtf8().data(),
				(unsigned char *) cData, str.toUtf8().length());

		m_teRecv->clear();
		m_teRecv->setPlainText(
				trUtf8(QString(cData).mid(0, iCount).toStdString().c_str()));

	}
	else
	{
		//hex 显示
		QString str = m_teRecv->toPlainText();
		char cTemp[str.toUtf8().length() * 3];
		ByteToStr((const unsigned char*) str.toUtf8().data(), cTemp,
				str.toUtf8().length());
		m_teRecv->clear();
		m_teRecv->append(QString(cTemp).mid(0, str.toUtf8().length() * 3));
	}

}
//hex显示
void TQSocketDebugger::cbSrvDisplayStateChanged()
{
	//	cout<<"hex rec"<<endl;
	//	connect(m_pConnClient, SIGNAL(readyRead()), this, SLOT(readClient()));

	if  (!m_cbRecvHex_Srv->isChecked())
	{
		QString str = m_teRecv_Srv->toPlainText();
		str = str.remove(' ');
		char cData[str.toUtf8().length()];
		int iCount = str2Hex((unsigned char *) str.toUtf8().data(),
				(unsigned char *) cData, str.toUtf8().length());

		m_teRecv_Srv->clear();
		m_teRecv_Srv->setPlainText(
				trUtf8(QString(cData).mid(0, iCount).toStdString().c_str()));
	}
	else
	{
		//hex 显示
		QString str = m_teRecv_Srv->toPlainText();
		char cTemp[str.toUtf8().length() * 3];
		ByteToStr((const unsigned char*) str.toUtf8().data(), cTemp,
				str.toUtf8().length());
		m_teRecv_Srv->clear();
		m_teRecv_Srv->setPlainText(QString(cTemp).mid(0, str.toUtf8().length() * 3));
	}
}
//hex显示
void TQSocketDebugger::cbSrvSendStateChanged()
{
	if (!m_cbSendHex_Srv->isChecked())
	{
		QString str = m_teSend_Srv->toPlainText();
		str = str.remove(' ');
		char cData[str.toUtf8().length()];
		int iCount = str2Hex((unsigned char *) str.toUtf8().data(),
				(unsigned char *) cData, str.toUtf8().length());

		m_teSend_Srv->clear();
		m_teSend_Srv->setPlainText(
				trUtf8(QString(cData).mid(0, iCount).toStdString().c_str()));
	}
	else
	{
		QString str = m_teSend_Srv->toPlainText();
		char cTemp[str.toUtf8().length() * 3];
		ByteToStr((const unsigned char*) str.toUtf8().data(), cTemp,
				str.toUtf8().length());
		m_teSend_Srv->clear();
		m_teSend_Srv->setPlainText(QString(cTemp).mid(0, str.toUtf8().length() * 3));
	}
}

void TQSocketDebugger::pbKeyShowHide()
{
	((TQInputMethod *) im)->setVisible(true);
}
//字符转Hex
int str2Hex(unsigned char *buf, unsigned char *hex, int sLen)
{
	unsigned char tHex = 0x00;
	unsigned char *tBuf = (unsigned char *) malloc(sizeof(unsigned char) * 8);
	memset(tBuf, '\0', 8);
	int i = 0;
	for (i = 0; i < sLen; i += 2)
	{
		memcpy(tBuf, &buf[i], 2);
		tHex = (unsigned char) strtol((char *) tBuf, NULL, 16);
		hex[i / 2] = tHex;
	}
	return sLen / 2;
}
char *ByteToStr(const unsigned char *pIn, char *pOut, int len)
{
	char *pstr = pOut;
	unsigned char *p = (unsigned char *) pIn;

	int i = 0;
	for (i = 0; i < len; i++, pstr += 3)
		sprintf(pstr, "%02x ", *p++);

	return pOut;
}

void TQSocketDebugger::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
void TQSocketDebugger::pbExitClicked()
{
	g_tqsocketdebugger->close();
}
