#ifndef TQSOCKETDEBUGGER_H
#define TQSOCKETDEBUGGER_H

#include <QtGui/QWidget>
#include <QLabel>
#include <QTcpSocket>
#include <QTcpServer>
#include <QTimer>
#include <qprocess.h>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QTabWidget>
#include <QRegExpValidator>
#include <QCheckBox>



#include "TQInputMethod.h"
#ifdef ARM
#include <QWSInputMethod>
#endif

class TQSocketDebugger: public QWidget
{
Q_OBJECT

public:
	TQSocketDebugger(QWidget *parent = 0,bool bKeyShow=0);
	~TQSocketDebugger();

private:
	QLabel *m_titlelabel;
	QLabel *m_lbIp;
	QLabel *m_lbPort;
	QLabel *m_lbSrvPort;
	QLabel *m_lbMessage_Srv;
	QLabel *m_lbMessage;
	QLabel *m_lbSendHex;
	QLabel *m_lbRecvHex;
	QLabel *m_lbAutoSend;
	QLabel *m_lbRecvHex_Srv;
	QLabel *m_lbSendHex_Srv;
	QLabel *m_lbAutoReturn;
	QLabel *m_lbLongSck;
	QLabel *m_lbms;
	QLabel *m_lbms_Srv;
	QTcpSocket *m_pClient;
	QTcpServer *m_pSrv;
	QTcpSocket *m_pConnClient;
	QTimer *m_pAutoSend;
	QTextEdit *m_teSend;
	QTextEdit *m_teSend_Srv;
	QTextEdit *m_teRecv;
	QTextEdit *m_teRecv_Srv;
	QLineEdit *m_leIP;
	QLineEdit *m_lePort;
	QLineEdit *m_lePort_Srv;
	QLineEdit *m_leTimeInterval;
	//QLineEdit *m_leTimeInterval_Srv
	QPushButton *m_pbClearRecv;
	QPushButton *m_pbClearSend;
	QPushButton *m_pbConnect;
	QPushButton *m_pbSend;
	QPushButton *m_pbClose;
	QPushButton *m_pbStart;
	QPushButton *m_pbClearRecv_Srv;
	QPushButton *m_pbClearSend_Srv;
	QPushButton *m_pbExit;
	QPushButton *m_pbHelp;
	QTabWidget *m_tabWidget;
	QCheckBox *m_cbRecvHex;
	QCheckBox *m_cbSendHex;
	QCheckBox *m_cbRecvHex_Srv;
	QCheckBox *m_cbSendHex_Srv;
	QCheckBox *m_cbLongSck;
	QCheckBox *m_cbAutoSend;
	QCheckBox *m_cbAutoReturn;


	bool bStartSrv;
	bool m_bFlg;
	QProcess process;

    QWSInputMethod* im;
    QPushButton *m_pbKey;

public slots:
	void pbSendClicked();//发送数据
	void pbStartClicled();//启动服务
	void pbClearRecvClicked();//清空接收数据
	void pbClearSendClicked();//清空发送数据
	void pbConnectClicked();//连接服务器
	void stateChanged(QAbstractSocket::SocketState socketState);//客户端状态
	void newConnection();//有客户端连接
	void readClient();//读取客户端发送的数据
	void readFromServer();//从服务器读取回复数据
	void autoSend();//自动发送
	void autoSendStateChanged();//开始，停止自动发送
	void textChanged();//发送数据改变，用于限制发送或回复的数据长度
	void cbDisplayStateChanged();
	void cbSendStateChanged();

	void cbSrvDisplayStateChanged();
	void cbSrvSendStateChanged();

	void pbExitClicked();
	void pbHelpClicked();

	void pbKeyShowHide();
};
extern TQSocketDebugger *g_tqsocketdebugger;
#endif // TQSOCKETDEBUGGER_H
