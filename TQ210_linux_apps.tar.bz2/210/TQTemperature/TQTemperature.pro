TEMPLATE = app
TARGET = tqtemperature
QT += core \
    gui
HEADERS += ThreadTemper.h \
    tqtemperature.h
SOURCES += ThreadTemper.cpp \
    main.cpp \
    tqtemperature.cpp
FORMS += 
RESOURCES += 
