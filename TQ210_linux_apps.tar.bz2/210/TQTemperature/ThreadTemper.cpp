#include "ThreadTemper.h"
#include <fcntl.h>
#include <math.h>
#include<iostream>
#include <QString>
#include <QFile>
#include <QMessageBox>
#include <sys/ioctl.h>
using namespace std;
static int fd_dev;
double test;

ThreadTemper::ThreadTemper()
{
	isError = false;
}
ThreadTemper::~ThreadTemper()
{

}

//线程函数
void ThreadTemper::run()
{

	while(1)
	{
		usleep(100000);
		readTemper();
		if(isError)
			break;
	}
}
void ThreadTemper::stop()
{

}
void ThreadTemper::readTemper()
{
	unsigned int tmp = 0;
	int i = 12;
	QFile f("/dev/ds18b20");
	//cout<<"11111 open!"<<endl;

	if(f.exists())
	{
		fd_dev = open("/dev/ds18b20",O_RDWR);
		if(fd_dev<0)
		{
			isError = true;
			perror("error open ds18b20\n");
			emit openError();
		}
		else
		{
			isError = false;
			int rtn = ioctl(fd_dev,IOCTL_DS18B20_S_BIT,&i);
			if(rtn < 0)
			{
				return ;
			}
			read(fd_dev,&tmp,4);
			test = tmp;
			test /= 100;
			QString str=QString::number(test,'f',2);
			emit readTemperature(str);
		}
	}
	else
	{
		isError = true;
		perror("/dev/ds18b20 not exist\n");
		emit existError();
	}
}
