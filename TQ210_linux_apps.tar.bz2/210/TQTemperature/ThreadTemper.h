#ifndef THREADTEMPER_H
#define THREADTEMPER_H

#include <QThread>
#include <QObject>
#include <QString>
#include <QTimer>
#define IOCTL_DS18B20_S_RESET			0x10002
#define IOCTL_DS18B20_S_START			0x10003
#define IOCTL_DS18B20_S_BIT				0x10004
#define IOCTL_DS18B20_G_TEMPERATURE	0x10001

class ThreadTemper: public QThread
{
	Q_OBJECT
public:
	ThreadTemper();
	virtual ~ThreadTemper();
	void run();
public slots:
	void readTemper();
	void stop();
	signals:
	void readTemperature(QString);
	void existError();
	void openError();

private:
	bool isError;
};

#endif // THREADTEMPER_H
