/*************************************
*
* 文件名:tqtemperature.cpp
* 版权:广州天嵌计算机科技有限公司
* 作者:tq_lih
* 功能:温度检测模块
* 修改历史:2012/07/18
时间:xxxx-xx-xx,作者:xxx
原因:xxxxxxxxxxxxxxxxx
*
*************************************/
#include "tqtemperature.h"
#include <QFile>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <stdio.h>
#include<QApplication>
#include<QRect>
#include <QDesktopWidget>
#include <QFont>
#include <iostream>
#include <QMessageBox>

using namespace std;

//static int fd_dev;
//static int key;
//double test;

TQTemperature::TQTemperature(QWidget *parent)
    : QWidget(parent)
{
	QRect screen_size = QApplication::desktop()->screenGeometry();//取窗体大小尺寸
	sign_x = screen_size.width() / 5 ;//100;
	sign_y = screen_size.height() / 2 ;

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	m_lbmiantitle = new QLabel(this);
	m_lbmiantitle->setText(trUtf8("温度传感器测试程序"));
	m_lbmiantitle->setAlignment(Qt::AlignCenter);
	m_lbmiantitle->setFixedHeight(30);

	m_lcdnumtemp = new QLCDNumber;
	m_lcdnumtemp ->setSegmentStyle(QLCDNumber::Filled);



	m_lbsign = new QLabel(this);
	m_lbsign -> setFixedSize(sign_x,sign_y);
	QPixmap pix("/opt/PDA/app/images/c.png", 0, Qt::AutoColor);
	pix = pix.scaled(sign_x,sign_y, Qt::IgnoreAspectRatio);//图片大小
	m_lbsign -> setPixmap(pix);

	m_pbStartStop = new QPushButton(this);
	m_pbStartStop->setFixedSize(75, 30);//图片大小
	m_pbStartStop->setIconSize(QSize(75, 30));//图片大小
	pix.load("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
	pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbStartStop->setIcon(QIcon(pix));

	m_pbExit = new QPushButton(this);
	m_pbExit->setFixedSize(75, 30);
	m_pbExit->setIconSize(QSize(75, 30));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbExit->setIcon(QIcon(pix));

	m_pbPause = new QPushButton(this);
	m_pbPause->setFixedSize(75, 30);
	m_pbPause->setIconSize(QSize(75, 30));
	pix.load("/opt/PDA/app/images/pause.png", 0, Qt::AutoColor);
	pix = pix.scaled(75, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbPause->setIcon(QIcon(pix));

	connect(m_pbStartStop, SIGNAL(clicked()), this,SLOT(pbStartStopClicked()));
	connect(m_pbPause, SIGNAL(clicked()), this,SLOT(pbPauseClicked()));
	connect(m_pbExit, SIGNAL(clicked()), this, SLOT(pbExitClicked()));

	hMidLayout = new QHBoxLayout();
	hMidLayout->addWidget(m_lcdnumtemp);
	hMidLayout->addWidget(m_lbsign);


	hGroudLayout = new QHBoxLayout();
	hGroudLayout->addWidget(m_pbStartStop);
	hGroudLayout->addWidget(m_pbPause);
	hGroudLayout->addWidget(m_pbExit);

	GroupBox = new QGroupBox(this);
	GroupBox->setGeometry( QRect( 90, 10, 140, 60 ) );
//	GroupBox->setMaximumSize( QSize( 320, 240 ) );
	GroupBox->setTitle( trUtf8( "当前检测到的温度" ) );
	GroupBox->setLayout(hMidLayout);
	GroupBox->setAlignment(Qt::AlignLeft);

	vMainLayout = new QVBoxLayout();
	vMainLayout->addWidget(m_lbmiantitle);
	vMainLayout->addWidget(GroupBox);
	vMainLayout->addLayout(hGroudLayout);

	setLayout(vMainLayout);

}

TQTemperature::~TQTemperature()
{
	delete threadTemper;
}
void TQTemperature::pbExitClicked()
{
	close();
}

void TQTemperature::pbStartStopClicked()
{
	threadTemper = new ThreadTemper();

	connect(threadTemper,SIGNAL(readTemperature(QString)),this,SLOT(readtemp(QString)));
	connect(threadTemper,SIGNAL(openError()),this,SLOT(openError()));
	connect(threadTemper,SIGNAL(existError()),this,SLOT(existError()));
	threadTemper->start();
}

void TQTemperature::pbPauseClicked()
{
	disconnect(threadTemper, 0, 0, 0);
	threadTemper->quit();
}

void TQTemperature::openError()
{
	disconnect(threadTemper, 0, 0, 0);
	threadTemper->quit();
	QMessageBox::information(this,trUtf8("警告"),trUtf8("error open ds18b20!!"));
}

void TQTemperature::existError()
{
	disconnect(threadTemper, 0, 0, 0);
	threadTemper->quit();
	QMessageBox::information(this,trUtf8("警告"),trUtf8("/dev/ds18b20 not exist!!"));
}

void TQTemperature::readtemp(QString str)
{
	m_lcdnumtemp->display(str);
}
