/*************************************
*
* 文件名:tqtemperature.cpp
* 版权:广州天嵌计算机科技有限公司
* 作者:tq_lih
* 功能:温度检测模块
* 修改历史:2012/07/18
时间:xxxx-xx-xx,作者:xxx
原因:xxxxxxxxxxxxxxxxx
*
*************************************/
#ifndef TQTEMPERATURE_H
#define TQTEMPERATURE_H

#include <QtGui/QWidget>
#include <QLabel>
#include <QLCDNumber>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QGroupBox>
#include <QTimer>
#include "ThreadTemper.h"

/*#define IOCTL_DS18B20_S_RESET			0x10002
#define IOCTL_DS18B20_S_START			0x10003
#define IOCTL_DS18B20_S_BIT				0x10004
#define IOCTL_DS18B20_G_TEMPERATURE	0x10001*/

class TQTemperature : public QWidget
{
    Q_OBJECT

public:
    TQTemperature(QWidget *parent = 0);
    ~TQTemperature();



public	slots:
	void pbStartStopClicked();
	void pbExitClicked();
	void readtemp(QString);
	void pbPauseClicked();
	void openError();
	void existError();

private:
	int sign_x;
	int sign_y;

    QLabel *m_lbmiantitle;
 //   QLabel *m_lbtmp;
	QLabel *m_lbsign;

    QPushButton *m_pbStartStop;
    QPushButton *m_pbPause;
    QPushButton *m_pbExit;

    QLCDNumber *m_lcdnumtemp;

    QGroupBox *GroupBox;

    QHBoxLayout *hMidLayout;
    QVBoxLayout *vMainLayout;
    QHBoxLayout *hGroudLayout;

    ThreadTemper *threadTemper;
//    QTimer *timer;
};

#endif // TQTEMPERATURE_H
