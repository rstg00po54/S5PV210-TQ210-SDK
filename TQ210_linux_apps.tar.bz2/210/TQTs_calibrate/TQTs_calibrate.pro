TEMPLATE = app
TARGET = tqts_calibrate
QT += core \
    gui
HEADERS += 
SOURCES += main.cpp
FORMS += 
RESOURCES += 
