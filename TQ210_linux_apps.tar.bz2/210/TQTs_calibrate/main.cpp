//#include "ts_calibrate.h"
#include <stdlib.h>
int main(int argc, char *argv[])
{

	system("killall tqpda");
	system("/bin/ts_calibrate");
	system("tqpda -qws");

	return 0;
}

/*int aa = mplayerProcess->waitForFinished(10000);
 if (aa == 1)
 close();

 int aa = mplayerProcess->waitForFinished(10000);
 if (aa == 1)
 close();*/

///sbin/ts_calibrate
