/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		adc应用程序
 *    文件名:     	ledtst.cpp
 *    文件描述:  		led测试程序主界面
 *    创建日期:      2011-06-28
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */

#include "ledtest.h"
#include <sys/ioctl.h>
#include<stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include<QTimer>
static int fb;
ledtest::ledtest(QWidget *parent) :
	QWidget(parent)
{
//	ui.setupUi(this);

	QRect screen_size = QApplication::desktop()->screenGeometry();//取窗体大小尺寸
	m_iWidth = 80*screen_size.width()/800; //比率换算
	m_iHeight = 38* screen_size.height()/480; //比率换算

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	fb = open("/dev/led", QIODevice::ReadWrite);//打开设备
	if (fb < 0)
	{
		perror("open device leds fail");
	}

	pbHelp = new QPushButton();
	pbHelp->setFixedSize(m_iWidth, m_iHeight);
	pbHelp->setIconSize(QSize(m_iWidth, m_iHeight));
	QPixmap pix("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(m_iWidth, m_iHeight, Qt::IgnoreAspectRatio);//图片大小
	pbHelp->setIcon(QIcon(pix));
	connect(pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	pbExit = new QPushButton();
	pbExit->setFixedSize(m_iWidth, m_iHeight);
	pbExit->setIconSize(QSize(m_iWidth, m_iHeight));
	QPixmap pix1("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix1 = pix1.scaled(m_iWidth, m_iHeight, Qt::IgnoreAspectRatio);//图片大小
	pbExit->setIcon(QIcon(pix1));

	Cb0 = new QCheckBox(trUtf8("LED1"));
	Cb1 = new QCheckBox(trUtf8("LED2"));
	Cb2 = new QCheckBox(trUtf8("LED3"));
	Cb3 = new QCheckBox(trUtf8("LED4"));

	all_off = new QRadioButton(trUtf8("All Off"));
	all_off->setChecked(0);

	all_on = new QRadioButton(trUtf8("All On"));
	all_on->setChecked(0);

	QHBoxLayout *hQCheckBox = new QHBoxLayout;
	hQCheckBox->addStretch(1);
	hQCheckBox->addWidget(Cb0);
	hQCheckBox->addStretch(1);
	hQCheckBox->addWidget(Cb1);
	hQCheckBox->addStretch(1);
	hQCheckBox->addWidget(Cb2);
	hQCheckBox->addStretch(1);
	hQCheckBox->addWidget(Cb3);
	hQCheckBox->addStretch(1);

	QHBoxLayout *hQRadioButton = new QHBoxLayout;
	hQRadioButton->addStretch(1);
	hQRadioButton->addWidget(all_off);
	hQRadioButton->addStretch(1);
	hQRadioButton->addWidget(all_on);
	hQRadioButton->addStretch(1);

	QHBoxLayout *hQPushButton = new QHBoxLayout;
	hQPushButton->addStretch(1);
	hQPushButton->addWidget(pbHelp);
	hQPushButton->addStretch(1);
	hQPushButton->addWidget(pbExit);
	hQPushButton->addStretch(1);

	QVBoxLayout *vLayoutAll = new QVBoxLayout;
	vLayoutAll->addStretch(1);
	vLayoutAll->addLayout(hQCheckBox);
	vLayoutAll->addStretch(1);
	vLayoutAll->addLayout(hQRadioButton);
	vLayoutAll->addStretch(1);
	vLayoutAll->addLayout(hQPushButton);
	vLayoutAll->addStretch(1);

	setLayout(vLayoutAll);

	connect(pbExit, SIGNAL(clicked()), this, SLOT(close()));//退出按钮建立关联

	connect(all_on, SIGNAL(toggled(bool)), this, SLOT(toggleLed()));
	connect(all_off, SIGNAL(toggled(bool)), this, SLOT(toggleLed()));

/*	connect(all_on, SIGNAL(stateChanged(int)), this, SLOT(toggleLed()));
	connect(all_off, SIGNAL(stateChanged(int)), this, SLOT(toggleLed()));*/

/*	connect(Cb0, SIGNAL(stateChanged()), this, SLOT(oper()));
	connect(Cb1, SIGNAL(stateChanged()), this, SLOT(oper()));
	connect(Cb2, SIGNAL(stateChanged()), this, SLOT(oper()));
	connect(Cb3, SIGNAL(stateChanged()), this, SLOT(oper()));*/


	QTimer *timer = new QTimer(parent);//定时器
	connect(timer, SIGNAL(timeout()), this, SLOT(oper()));//定时器关联
	timer->start(44);//开启定时器

}

ledtest::~ledtest()
{

}
//控制主函数
void ledtest::oper()
{
	if (Cb0->isChecked())//如果选中，checkbox0
		ioctl(fb, 1, 0);//控制灯亮
	else
		ioctl(fb, 0, 0);

	if (Cb1->isChecked())//如果选中，checkbox1
		ioctl(fb, 1, 1);//
	else
		ioctl(fb, 0, 1);//

	if (Cb2->isChecked())//如果选中，checkbox0
		ioctl(fb, 1, 2);//控制灯亮
	else
		ioctl(fb, 0, 2);

	if (Cb3->isChecked())//如果选中，checkbox1
		ioctl(fb, 1, 3);//
	else
		ioctl(fb, 0, 3);//

}

void ledtest::toggleLed()
{
	if (all_on->isChecked())//如果选中，checkbox1
	{
		Cb0->setChecked(true);
		Cb1->setChecked(true);
		Cb2->setChecked(true);
		Cb3->setChecked(true);

	}

	if (all_off->isChecked())//如果选中，checkbox1
	{
		Cb0->setChecked(false);
		Cb1->setChecked(false);
		Cb2->setChecked(false);
		Cb3->setChecked(false);
	}

}

void ledtest::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
