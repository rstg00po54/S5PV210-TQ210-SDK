#ifndef LEDTEST_H
#define LEDTEST_H

#include <QtGui/QWidget>
//#include "ui_ledtest.h"
#include <qprocess.h>
#include<QDirectPainter>
#include<QFile>
#include <QWindowsXPStyle>
#include <QSpinBox>
#include <QPushButton>
#include <QSlider>
#include <QCheckBox>
#include <QDial>
#include <QGroupBox>
#include <QLabel>
#include <QVBoxLayout>
#include <QApplication>
#include <QDesktopWidget>
#include <QRadioButton>

class ledtest: public QWidget
{
Q_OBJECT

public:
	ledtest(QWidget *parent = 0);
	~ledtest();
public slots:
	void oper();//对led灯操作主函数
	void pbHelpClicked();
	void toggleLed();

private:
//	Ui::ledtestClass ui;
	QProcess process;

	int m_iWidth;
	int m_iHeight;

	QPushButton *pbHelp;
	QPushButton *pbExit;
	QCheckBox *Cb0;
	QCheckBox *Cb1;
	QCheckBox *Cb2;
	QCheckBox *Cb3;
	QRadioButton *all_off;
	QRadioButton *all_on;
};

#endif // LEDTEST_H
