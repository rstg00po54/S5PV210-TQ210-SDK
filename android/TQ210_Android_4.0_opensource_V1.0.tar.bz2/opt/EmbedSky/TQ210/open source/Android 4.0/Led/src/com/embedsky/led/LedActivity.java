package com.embedsky.led;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;

public class LedActivity extends Activity {
	/** Called when the activity is first created. */

	//加载libled.so库，必须放在最前面
	static {
		System.loadLibrary("led");
	}

	//初始化led
	public static native boolean ledInit();
	//关闭led
	public static native boolean ledClose();
	//点亮led
	private static native boolean ledSetOn(int number);
	//灭掉led
	private static native boolean ledSetOff(int number);

	//CheckBox数组，用来存放1-8个led灯控件
	CheckBox[] cb = new CheckBox[8];
	//全选
	CheckBox cbAll;
	//退出按钮
	Button btnQuit;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		//获取xml中对应的控件
		cb[0] = (CheckBox) findViewById(R.id.cbLed1);
		cb[1] = (CheckBox) findViewById(R.id.cbLed2);
		cb[2] = (CheckBox) findViewById(R.id.cbLed3);
		cb[3] = (CheckBox) findViewById(R.id.cbLed4);
		cb[4] = (CheckBox) findViewById(R.id.cbLed5);
		cb[5] = (CheckBox) findViewById(R.id.cbLed6);
		cb[6] = (CheckBox) findViewById(R.id.cbLed7);
		cb[7] = (CheckBox) findViewById(R.id.cbLed8);
		cbAll = (CheckBox) findViewById(R.id.cbLedAll);
		btnQuit = (Button) findViewById(R.id.btnQuit);
		//初始化点击事件对象
		MyClickListener myClickListern = new MyClickListener();

		// LED1-LED8选中/取消事件
		for (int i = 0; i < 8; i++) {
			cb[i].setOnClickListener(myClickListern);
		}
		// 全选选中/取消事件
		cbAll.setOnClickListener(myClickListern);

		// 退出按钮点击事件处理
		btnQuit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		// led初始化
		if (!ledInit()) {
			new AlertDialog.Builder(this).setTitle("init led fail").show();
			//led初始化失败，则使控件不可点击
			for (int i = 0; i < 8; i++)
				cb[i].setEnabled(false);
			cbAll.setEnabled(false);
		}
	}

	// 自定义的事件监听器类，用来处理CheckBox选中和取消事件
	public class MyClickListener implements OnClickListener {
		@Override
		public void onClick(View v) {
			//遍历数组，判断是哪个led控件被选中
			for (int i = 0; i < 8; i++) {
				if (v == cb[i]) {
					//根据选中/取消状态来控制led灯的亮/灭
					controlLed(i + 1, cb[i].isChecked());
					return;
				}
			}

			//全选按钮，遍历数组，对所有led灯做控制
			if (v == cbAll) {
				for (int i = 0; i < 8; i++) {
					controlLed(i + 1, cbAll.isChecked());
					cb[i].setChecked(cbAll.isChecked());
				}
			}
		}
	}

	/*******************************************/
	// 功能：LED亮/灭处理
	// 参数：
	// number :灯编号
	// on :true，亮;fase,灭
	/*******************************************/
	private void controlLed(int number, boolean on) {
		if (on) {
			ledSetOn(number);
		} else {
			ledSetOff(number);
		}
	}
}