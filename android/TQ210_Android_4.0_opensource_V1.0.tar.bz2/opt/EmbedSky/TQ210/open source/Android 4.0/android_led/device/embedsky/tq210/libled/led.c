/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define LOG_TAG "led"
#include <cutils/log.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <hardware/led.h>

char const * const LED_DEVICE = "/dev/led";
static int fd = -1;

static int open_led() {
	if ((fd = open(LED_DEVICE, O_RDWR)) == -1) {
		LOGV("open %s fail\n", LED_DEVICE);
		return -1;
	}
	LOGV("led_open success\n");
	return 1;
}

static int close_led(struct hw_device_t *dev) {
	LOGV("close_light is called");
	if (fd != -1) {
		close(fd);
		fd = -1;
		if (dev)
			free(dev);
	}
	return 0;
}
int led_on(struct led_control_device_t* dev, int32_t number) {

	if (fd == -1)
		return -1;

	return ioctl(fd, IOCTL_GPIO_ON, number);
}

int led_off(struct led_control_device_t* dev, int32_t number) {
	if (fd == -1)
		return -1;
	return ioctl(fd, IOCTL_GPIO_OFF, number);
}

static int led_init(const struct hw_module_t *module, char const *name,
		struct hw_device_t **device) {

	struct led_control_device_t *dev;
	dev = (struct led_control_device_t *) malloc(
			sizeof(struct led_control_device_t));

	if (dev == NULL)
		return 0;

	memset(dev, 0, sizeof(*dev));
	dev->common.tag = HARDWARE_DEVICE_TAG;
	dev->common.version = 0;
	dev->common.module =  module;
	dev->common.close = (int (*)(struct hw_device_t *)) close_led;
	*device = (struct hw_device_t *) &dev->common;

	dev->set_on = led_on;
	dev->set_off = led_off;

	if (open_led() == -1) {
		free(dev);
		dev = NULL;
		return -1;
	}
	return 0;
}

static struct hw_module_methods_t led_module_methods = {
		open : led_init
};

const struct led_module_t HAL_MODULE_INFO_SYM =
{
	common:
    {
        tag: HARDWARE_MODULE_TAG,
        version_major: 1,
        version_minor: 0,
        id: LED_HARDWARE_MODULE_ID,
        name: "led Stub",
        author: "embedsky",
        methods: &led_module_methods,
    }

};
