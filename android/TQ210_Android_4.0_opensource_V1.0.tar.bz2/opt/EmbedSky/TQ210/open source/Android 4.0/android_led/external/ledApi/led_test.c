#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <asm/types.h>
#include <linux/fb.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <fcntl.h>
#include<string.h>
#include<unistd.h>
#include<sys/mman.h>
#include <sys/poll.h>

#define DEV_FILE_NAME		"/dev/led"	//驱动提供
/* 应用程序执行ioctl(fd, cmd, arg)时的第2个参数 */
#define IOCTL_GPIO_ON	1		//驱动提供,表示亮
#define IOCTL_GPIO_OFF	0		//驱动提供，表示灭

#define LED1		1			//对应硬件上的led1，驱动提供
#define LED2		2			//对应硬件上的led2，驱动提供

int main(void)
{
	int devfd;
	int i,err;
	
	devfd = open(DEV_FILE_NAME,O_RDWR);		//打开设备，权限是谱写，对应会调用驱动跌tq210_gpio_open
	if(devfd < 0)			//失败返回小于0,成功返回大于0,这只是一个句柄，无须太多关心它的实际意义
	{
		printf("can't open dev (%s)",DEV_FILE_NAME);
		return 0;
	}
	for(i=0;i<10;++i)
	{
		err = ioctl(devfd,IOCTL_GPIO_ON,LED2);//控制LED1亮，ioctl与tq210_gpio_ioctl中的第2,3个参数是对应的
		if(err<0)
			printf("GPIO_ON faild! (%d)\n",err);			
		sleep(1);	//休眠1S
		err = ioctl(devfd,IOCTL_GPIO_OFF,LED2);//关闭LED1。
		if(err<0)
			printf("GPIO_OFF faild! (%d)\n",err);			
		sleep(1);	//休眠1S
	}
	close(devfd);//关闭设备。对应驱动中的tq210_gpio_close
	return 0;
}


