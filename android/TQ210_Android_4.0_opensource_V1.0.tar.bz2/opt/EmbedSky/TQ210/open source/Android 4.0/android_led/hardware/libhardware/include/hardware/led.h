/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef ANDROID_LED_INTERFACE_H
#define ANDROID_LED_INTERFACE_H

#include <stdint.h>
#include <sys/cdefs.h>
#include <sys/types.h>

#include <hardware/hardware.h>

__BEGIN_DECLS

/**
 * The id of this module
 */
#define LED_HARDWARE_MODULE_ID "led"
struct led_module_t
{
	struct hw_module_t common;
};

/* 应用程序执行ioctl(fd, cmd, arg)时的第2个参数 */
#define IOCTL_GPIO_ON	1
#define IOCTL_GPIO_OFF	0

/* 应用程序执行ioctl(fd, cmd, arg)时的第3个参数 */
#define LED_NUMBER1	1
#define LED_NUMBER2	2

struct led_control_device_t {
    struct hw_device_t common;

    int (*set_on)(struct led_control_device_t* dev,
            int32_t number);
    int (*set_off)(struct led_control_device_t* dev,
                int32_t number);
};
__END_DECLS

#endif  // ANDROID_LED_INTERFACE_H

