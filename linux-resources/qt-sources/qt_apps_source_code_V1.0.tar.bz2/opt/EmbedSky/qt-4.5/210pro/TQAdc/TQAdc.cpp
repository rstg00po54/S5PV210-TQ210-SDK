/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		adc应用程序
 *    文件名:     	adc.cpp
 *    文件描述:  		主界面
 *    创建日期:      2011-06-28
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */
#include "TQAdc.h"
#include<QtGui>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/fs.h>
#include <errno.h>
#include <string.h>
#include<iostream>
#include<QHBoxLayout>
#include<QVBoxLayout>
#include<QPainter>
#include<QPixmap>

#include<QApplication>

using namespace std;

int fd;//设备号
#define CMD_PORT_SELECTED 0x0C
#define CMD_BIT_SELECTED 0x0D

adc::adc(QWidget *parent) :
	QWidget(parent)
{
	//	setAttribute(Qt::WA_DeleteOnClose);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	QTimer *time = new QTimer(parent);
	connect(time, SIGNAL(timeout()), this, SLOT(oper_adc()));

	QFile f("/dev/adc");
	if (f.exists())
	{
		fd = open("/dev/adc", O_RDWR);//打开设备tq6410-adc
		if (fd < 0)
		{
			perror("open ADC device !");
		}
	}

	QLabel *labelTitle = new QLabel(trUtf8("天嵌科技ad转换测试程序"), this);

	labelTitle -> setFixedHeight(20);
	labelTitle -> setMinimumHeight(10);
	labelTitle -> setMaximumHeight(40);

	labelTitle -> setAlignment(Qt::AlignCenter);

	QVBoxLayout *vlayout = new QVBoxLayout;
	QHBoxLayout *hlayout[MAX_CHANNEL];// = new QHBoxLayout;
	for (int i = 0; i < MAX_CHANNEL; i++)
	{
		hlayout[i] = new QHBoxLayout();
		QString str = "通道" + QString::number(i);
		m_cbChannel[i] = new QCheckBox();
		m_cbChannel[i]->setText(trUtf8(str.toStdString().c_str()));

		m_cbAccuracy[i] = new QCheckBox(trUtf8("十二位"), this);
		m_cbAccuracy[i]->setChecked(true);
		m_cbAccuracy[i]->setEnabled(false);

		str = "通道" + QString::number(i) + "电压";
		m_lbPrompt[i] = new QLabel(trUtf8(str.toStdString().c_str()), this);

		m_lbVotage[i] = new QLabel(trUtf8("0.0000V"), this);

		/*		m_pDial[i] = new QDial(this);
		 m_pDial[i]->setFixedSize(44, 44);
		 m_pDial[i]->setRange(0, 5);
		 */
		hlayout[i]->addWidget(m_cbChannel[i]);
		hlayout[i]->addWidget(m_cbAccuracy[i]);
		hlayout[i]->addWidget(m_lbPrompt[i]);
		hlayout[i]->addWidget(m_lbVotage[i]);

		//		hlayout[i]->addWidget(m_pDial[i]);

		vlayout->addLayout(hlayout[i]);

	}

	m_pbExit = new QPushButton();
	m_pbExit->setFixedSize(65, 30);
	m_pbExit->setIconSize(QSize(65, 30));
	QPixmap pix;
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbExit->setIcon(QIcon(pix));
	connect(m_pbExit, SIGNAL(clicked()), this, SLOT(close()));

	m_pbHelp = new QPushButton();
	m_pbHelp->setFixedSize(65, 30);
	m_pbHelp->setIconSize(QSize(65, 30));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(65, 30, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	QHBoxLayout *exitLayout = new QHBoxLayout;
	exitLayout->addStretch(33);
	exitLayout->addWidget(m_pbHelp);
	exitLayout->addWidget(m_pbExit);

	m_groupbox = new QGroupBox(this);
	m_groupbox->setLayout(vlayout);

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addWidget(labelTitle);
	mainLayout->addWidget(m_groupbox);
	mainLayout->addLayout(exitLayout);

	this->setLayout(mainLayout);
	time->start(500);//定时器，500毫秒扫描一次，如果太快速了看不清楚数字
}

adc::~adc()
{
	for (int i = 0; i < MAX_CHANNEL; i++)
	{
		//		delete m_pDial[i];//通道电压表盘显示
		delete m_cbAccuracy[i];//精度选择
		delete m_cbChannel[i];//通道选择
		delete m_lbVotage[i];//通道电压
		delete m_lbPrompt[i];//通道电压显示
	}
	delete m_pbHelp;
	delete m_pbExit;
	delete m_groupbox;
	::close(fd);
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：pb_startClicked
 ** 创建日期：2011-07-04
 ** 创 建 人： gxx
 ** 函数说明： 开始ad转换
 ** 其他：无
 ** 参    数：无
 ** 返    回：无
 ** 数 据 库：无
 ** 其它说明：无
 */
void adc::oper_adc()
{

	int len;
	double dValue;
	char cData[10];
	double Value;
	double Value12 = 3.3 / 4095;
	double Value10 = 3.3 / 1023;

	for (int i = 0; i < MAX_CHANNEL; i++)
	{
		if (m_cbChannel[i]->isChecked())
		{
			m_cbAccuracy[i]->setEnabled(true);

			ioctl(fd, CMD_PORT_SELECTED, i);//设置通道

			if (m_cbAccuracy[i]->isChecked())
			{
				ioctl(fd, CMD_BIT_SELECTED, 12);//设置12位数据
				Value = Value12;
			}
			else
			{
				ioctl(fd, CMD_BIT_SELECTED, 10);//设置10位数据
				Value = Value10;
			}

			int ibuffer;
			len = read(fd, &ibuffer, sizeof(ibuffer));//读ad转换后的数据
//			cout << ibuffer << endl;
			if (len > 0)//如果读出来的数据有效
			{
				dValue = (float) ibuffer * Value;//模数换算

				//	m_pDial[i]->setValue(int(dValue));
				sprintf(cData, "%.4f", dValue);
				str = QString(cData);
				str.append('V');
				m_lbVotage[i]->setText(str);
			}
			else
			{
				perror("read ADC device !");

			}
		}
	}
}
void adc::paintEvent(QPaintEvent *)
{
	QPainter painter(this);
	m_groupbox->size().height();

	for (int i = 1; i < MAX_CHANNEL; i++)
		painter.drawLine(
				QPoint(
						m_groupbox->pos().x(),
						(m_groupbox->pos().y() + m_groupbox->size().height()
								* i / MAX_CHANNEL)),
				QPoint(
						m_groupbox->pos().x() + m_groupbox->size().width(),
						m_groupbox->pos().y() + m_groupbox->size().height() * i
								/ MAX_CHANNEL));
}

void adc::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
