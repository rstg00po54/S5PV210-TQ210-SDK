#ifndef ADC_H
#define ADC_H

#include <QtGui/QWidget>
#include<QtGui>
#include<QGroupBox>
#include <QDial>
#include <qprocess.h>
#include<QCheckBox>

#define MAX_CHANNEL 6
class adc: public QWidget
{
Q_OBJECT

public:
	adc(QWidget *parent = 0);
	~adc();
public slots:
	void oper_adc();
	void paintEvent(QPaintEvent *);
	void pbHelpClicked();

private:

	QString str;//转换
	int start_flag;//开始标志
	QPushButton *m_pbExit;//退出按钮
	QPushButton *m_pbHelp;//帮助按钮
	QProcess process;//
	QGroupBox *m_groupbox;//控件群，包含所有控件，外围显示方框

	//QDial *m_pDial[MAX_CHANNEL];//通道电压表盘显示
	QCheckBox *m_cbAccuracy[MAX_CHANNEL];//精度选择
	QCheckBox *m_cbChannel[MAX_CHANNEL];//通道选择
	QLabel *m_lbVotage[MAX_CHANNEL];//通道电压
	QLabel *m_lbPrompt[MAX_CHANNEL];//通道电压显示

/*	QDial *m_dial_0;//通道0电压表盘显示
	QDial *m_dial_1;//通道1电压表盘显示
	QDial *m_dial_2;//通道2电压表盘显示
	QDial *m_dial_3;//通道3电压表盘显示
*/
	QCheckBox *m_cbBox_0;//通道0选择
	QCheckBox *m_cbBox_1;//通道1选择
	QCheckBox *m_cbBox_2;//通道2选择
	QCheckBox *m_cbBox_3;//通道3选择

	QCheckBox *m_cb0;//通道0十位、十二位选择
	QCheckBox *m_cb1;//通道1十位、十二位选择
	QCheckBox *m_cb2;//通道2十位、十二位选择
	QCheckBox *m_cb3;//通道3十位、十二位选择

	QLabel *m_lab0;//通道0十位、十二位显示
	QLabel *m_lab1;//通道1十位、十二位显示
	QLabel *m_lab2;//通道2十位、十二位显示
	QLabel *m_lab3;//通道3十位、十二位显示

	QLabel *labch0;//通道0电压
	QLabel *labch1;//通道1电压
	QLabel *labch2;//通道2电压
	QLabel *labch3;//通道3电压

	QLabel *labValue0;//通道0电压显示
	QLabel *labValue1;//通道1电压显示
	QLabel *labValue2;//通道2电压显示
	QLabel *labValue3;//通道3电压显示

};

#endif // ADC_H
