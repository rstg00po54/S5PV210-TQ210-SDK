#include "TQAdc.h"

#include <QtGui>
#include <QApplication>

#include<QTextCodec>
#include <QWindowsStyle>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	//		QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
	//		QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
	//		QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));

//	QApplication::setStyle(new QWindowsXPStyle);
//	a.setStyle(new QWindowsStyle);

	QTextCodec *codec = QTextCodec::codecForName("UTF-8");
	QTextCodec::setCodecForLocale(codec);
	QTextCodec::setCodecForCStrings(codec);
	QTextCodec::setCodecForTr(codec);
//	QFont font("wenquanyi", 16);
//	a.setFont(font);

	adc w;
	w.showFullScreen();
	return a.exec();
}
