#include "tqbeep.h"
#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	TQBeep w;
	w.showFullScreen();
	return a.exec();
}
