/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		奉命起应用程序
 *    文件名:     	beep.cpp
 *    文件描述:  		主界面
 *    创建日期:      2011-06-28
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */

#include "tqbeep.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include<string.h>
#include <sys/ioctl.h>
#include<sys/stat.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<QDirectPainter>
#include<QFile>
#include <QWindowsXPStyle>
//#include<iostream>
//using namespace std;
static int beep_fb;
TQBeep::TQBeep(QWidget *parent) :
	QWidget(parent)
{
	ui.setupUi(this);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	ui.pbHelp->setFixedSize(77, 32);
	ui.pbHelp->setIconSize(QSize(77, 32));
	QPixmap pix("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(77, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbHelp->setIcon(QIcon(pix));
	connect(ui.pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

//	ui.horizontalSlider_beep->setFocusPolicy(Qt::StrongFocus);
//	ui.horizontalSlider_beep->setTickPosition(QSlider::TicksBothSides);
//	ui.horizontalSlider_beep->setTickInterval(100);
	ui.horizontalSlider_beep->setSingleStep(1);
//	ui.dial_beep->setFocusPolicy(Qt::StrongFocus);
	ui.spinBox_val->setRange(1, 100);
	ui.spinBox_val->setSingleStep(1);
	ui.radioButton_off->setChecked(1);

	ui.dial_beep->setStyle(new QWindowsStyle());
	ui.groupBox_on_off->setTitle(trUtf8("开关"));

	ui.pbExit->setFixedSize(77, 32);
	ui.pbExit->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出案件图标
	ui.pbExit->setIconSize(QSize(77, 32));

	connect(ui.horizontalSlider_beep, SIGNAL(valueChanged(int)),
			ui.spinBox_val, SLOT(setValue(int
					)));
	connect(ui.spinBox_val, SIGNAL(valueChanged(int)), ui.dial_beep,
			SLOT(setValue(int)));
	connect(ui.dial_beep, SIGNAL(valueChanged(int)), ui.horizontalSlider_beep,
			SLOT(setValue(int)));

	connect(ui.spinBox_val, SIGNAL(valueChanged(int)), this, SLOT(setBeep(int)));
	connect(ui.radioButton_off, SIGNAL(toggled(bool)), this, SLOT(toggleBeep()));
	connect(ui.radioButton_on, SIGNAL(toggled(bool)), this, SLOT(toggleBeep()));

	connect(ui.pbExit, SIGNAL(clicked()), this, SLOT(closeClicked()));
	this->toggleSliderGroup(0);

	QFile f("/dev/beep");
	if (f.exists())
	{
		beep_fb = open("/dev/beep", O_RDWR);
		if (beep_fb < 0)
		{
			perror("open device leds fail");
		}
	}
}

TQBeep::~TQBeep()
{
	::close(beep_fb);
}
//设置水平滑竿大小
void TQBeep::setValue(int value)
{
	ui.horizontalSlider_beep->setValue(value);
}
//设置蜂鸣器频率
void TQBeep::setBeep(int value)
{
	ioctl(beep_fb, 1, ui.spinBox_val->value());
}
//开关蜂鸣器
void TQBeep::toggleBeep()
{
	if (ui.radioButton_off->isChecked())
	{
		ioctl(beep_fb, 0, 1);
		this->toggleSliderGroup(0);
	}
	else if (ui.radioButton_on->isChecked())
	{
		ioctl(beep_fb, 1, 1);
		this->toggleSliderGroup(1);
	}
}
void TQBeep::toggleSliderGroup(bool is_on)
{
	ui.spinBox_val->setEnabled(is_on);
	ui.dial_beep->setEnabled(is_on);
	ui.horizontalSlider_beep->setEnabled(is_on);
}
void TQBeep::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
void TQBeep::closeClicked()
{
	ioctl(beep_fb, 0, 1);//关闭蜂鸣器驱动
	close();
}
