#ifndef TQBEEP_H
#define TQBEEP_H

#include <QtGui/QWidget>
#include "ui_tqbeep.h"
#include <qprocess.h>

class TQBeep: public QWidget
{
Q_OBJECT

public:
	TQBeep(QWidget *parent = 0);
	~TQBeep();
	signals:
	void valueChanged(int value);//控制数值改变
public slots:
	void setValue(int value);//设置频率槽
	void setBeep(int value);//设置
	void toggleBeep();//
	void toggleSliderGroup(bool is_on);//开启
	void pbHelpClicked();
	void closeClicked();
private:
	Ui::TQBeepClass ui;
	QProcess process;

};

#endif // TQBEEP_H
