/*
 * MyLabel.cpp
 *
 *  Created on: 2011-4-22
 *      Author: lkppost
 */

#include "MyLabel.h"

MyLabel::MyLabel(QWidget *parent):QLabel(parent)
{

}

MyLabel::~MyLabel()
{
}

void MyLabel::mouseDoubleClickEvent ( QMouseEvent * event )
{
	emit lbDbClicked();
}
