/*
 * MyLabel.h
 *
 *  Created on: 2011-4-22
 *      Author: lkppost
 */

#ifndef MYLABEL_H_
#define MYLABEL_H_
#include <QLabel>
#include <QtGui/QWidget>
#include <QMouseEvent>
class MyLabel: public QLabel
{
Q_OBJECT
public:
	MyLabel(QWidget *parent = 0);
	virtual ~MyLabel();
	void mouseDoubleClickEvent(QMouseEvent * event);
signals:
	void lbDbClicked();
};

#endif /* MYLABEL_H_ */
