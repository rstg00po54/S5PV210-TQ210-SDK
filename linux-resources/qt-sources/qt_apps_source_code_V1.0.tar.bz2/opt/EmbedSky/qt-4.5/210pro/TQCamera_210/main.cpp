#include "tqcamera.h"

#include <QtGui>
#include <QApplication>

//#include "camera_test.c"
#include <iostream>
using namespace std;
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	
//	QFont font("wenquanyi", 6);
	bool showMethod = false;
	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "EmbedSky") == 0)
		{
			g_pTQCamera = new TQCamera(0, true);
			showMethod = true;
			break;
		}
	}
	if (!showMethod)
		g_pTQCamera = new TQCamera;
	g_pTQCamera->showFullScreen();
	return a.exec();
}
//int main(int argc, char *argv[])
//{
//	int v4l2_fd = -1;
//	int fb_fd = -1;
//	char *fbmem = NULL;
//	unsigned int fb_length = 0;
//
//	int preview_frames = 360;
//	int tmp;
//
//	printf("TQ2440 Camera Test Program, Start !\n");
//	if (argc > 1) {
//		if (sscanf(argv[1], "%d", &tmp) == 1)
//			preview_frames = tmp;
//	}
//
//	v4l2_fd = open(V4L2_DEV_NODE, O_RDWR);
//	if (v4l2_fd < 0) {
//		perror(V4L2_DEV_NODE);
//		goto out;
//	}
//
//
//	ioctl(v4l2_fd,CAMERA_SET_SIZE,CAMERA_SIZE_ARG);
//	ioctl(v4l2_fd,CAMERA_SET_FORMAT,CAMERA_FORMAT_ARG);
//
//
//	fb_fd = open(FB_DEV_NODE, O_RDWR);
//	if (fb_fd < 0) {
//		perror(FB_DEV_NODE);
//		goto out;
//	}
//
//	fflush(stdout);
//	if ((fb_length = fb_grab(fb_fd, &fbmem)) == 0)
//		goto out;
//
//
//	memset(fbmem, 0, fb_length);
//
//
//	printf("Press Ctrl+C to stop !\n");
//	fflush(stdout);
//
//	v4l2_show_on_fb(v4l2_fd, fbmem, preview_frames);
//
//	printf("\n");
//
//out:
//
//	if (v4l2_fd > 0)
//		close(v4l2_fd);
//
//	fb_ungrab(&fbmem, fb_length);
//
//	return 0;
//}
