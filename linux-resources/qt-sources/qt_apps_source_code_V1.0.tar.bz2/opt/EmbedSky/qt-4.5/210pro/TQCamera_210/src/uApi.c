/*
 * uApi.c
 *
 *  Created on: 2011-4-26
 *      Author: lkppost
 */

#include "uApi.h"
#include <stdio.h>
#include <stdlib.h>

#define	YCbCrtoR(Y,Cb,Cr)	(1000*Y + 1371*(Cr-128))/1000
#define	YCbCrtoG(Y,Cb,Cr)	(1000*Y - 336*(Cb-128) - 698*(Cr-128))/1000
#define	YCbCrtoB(Y,Cb,Cr)	(1000*Y + 1732*(Cb-128))/1000
#define	min(x1, x2)		(((x1)<(x2))?(x1):(x2))

long int crv_tab[256];
long int cbu_tab[256];
long int cgu_tab[256];
long int cgv_tab[256];
long int tab_76309[256];
unsigned char clp[1024];

#define CRGBY    65535
#define CRV        90111
#define CBU        114686
#define CGU        21504
#define CGV        45055

__u32 Conv_YCbCr_Rgb(__u8 y0, __u8 y1, __u8 cb0, __u8 cr0)
{
	// bit order is
	// YCbCr = [Cr0 Y1 Cb0 Y0], RGB=[R1,G1,B1,R0,G0,B0].

	int r0, g0, b0, r1, g1, b1;
	__u16 rgb0, rgb1;
	__u32 rgb;

#if 1 // 4 frames/s @192MHz, 12MHz ; 6 frames/s @450MHz, 12MHz
	r0 = YCbCrtoR(y0, cb0, cr0);
	g0 = YCbCrtoG(y0, cb0, cr0);
	b0 = YCbCrtoB(y0, cb0, cr0);
	r1 = YCbCrtoR(y1, cb0, cr0);
	g1 = YCbCrtoG(y1, cb0, cr0);
	b1 = YCbCrtoB(y1, cb0, cr0);
#endif

	if (r0 > 255)
		r0 = 255;
	if (r0 < 0)
		r0 = 0;
	if (g0 > 255)
		g0 = 255;
	if (g0 < 0)
		g0 = 0;
	if (b0 > 255)
		b0 = 255;
	if (b0 < 0)
		b0 = 0;

	if (r1 > 255)
		r1 = 255;
	if (r1 < 0)
		r1 = 0;
	if (g1 > 255)
		g1 = 255;
	if (g1 < 0)
		g1 = 0;
	if (b1 > 255)
		b1 = 255;
	if (b1 < 0)
		b1 = 0;

	// 5:6:5 16bit format
	rgb0 = (((__u16 ) r0 >> 3) << 11) | (((__u16 ) g0 >> 2) << 5)
			| (((__u16 ) b0 >> 3) << 0); //RGB565.
	rgb1 = (((__u16 ) r1 >> 3) << 11) | (((__u16 ) g1 >> 2) << 5)
			| (((__u16 ) b1 >> 3) << 0); //RGB565.

	rgb = (rgb1 << 16) | rgb0;

	return (rgb);
}

void YUVToRGB(int w, int h, unsigned char *src, unsigned char *dst)
{
	unsigned long rgb_data;
	unsigned char *src_y = src;
	unsigned char *src_cb = src_y + w * h;
	unsigned char *src_cr = src_cb + w * h / 2;
	//unsigned char *src_cr = src_y + (w * h * 3) / 2;
	//int palette = optional_image_format[image_format].palette;

	//	show_cam_img(fb_buf, buf, buf + g_wJpgW * g_wJpgH,
	//						buf + (g_wJpgW * g_wJpgH * 3) / 2);
	//
	//	static void show_cam_img(void *scr, __u8 *y_buf, __u8 *cb_buf, __u8 *cr_buf)
	/*for (i = 0; i < 4; i++)
	 { //0,1,2,3
	 if ((w >> i) <= fb_xres)
	 {
	 f = 0;
	 w = min(w>>i, fb_xres);
	 h = min(h>>i, fb_yres);
	 break;
	 }
	 if ((h >> i) <= fb_yres)
	 {
	 f = 1;
	 w = min(w>>i, fb_yres);
	 h = min(h>>i, fb_xres);
	 break;
	 }
	 }*/
#if 0
	short int x = 0, y = 0, i, f;
	f = 1;
	printf("i==%d\n", i);
	if (i >= 4)
	return;
	if (!f)
	{
		for (y = 0; y < h; y++)
		{
			for (x = 0; x < w; x += 2)
			{ //calculate 2 times
				if (i)
				{
					dst[x] = Conv_YCbCr_Rgb(src_y[x << i], src_y[(x << i) + 1],
							src_cb[(x << i) >> 1], src_cr[(x << i) >> 1]);
					dst[x + 1] = Conv_YCbCr_Rgb(
							src_y[(x << i) + yuv_interval[i]],
							src_y[(x << i) + 1 + yuv_interval[i]],
							src_cb[((x << i) + yuv_interval[i]) >> 1],
							src_cr[((x << i) + yuv_interval[i]) >> 1]);
				}
				else
				{
					rgb_data = Conv_YCbCr_Rgb(src_y[x << i],
							src_y[(x << i) + 1], src_cb[(x << i) >> 1],
							src_cr[(x << i) >> 1]);
					dst[x] = rgb_data;
					dst[x + 1] = rgb_data >> 16;
				}
			}
			dst += fb_xres;
			src_y += w << i;
			src_cb += (w << i) >> 1;
			src_cr += (w << i) >> 1;
		}
	}
	else
	{
		for (y = 0; y < h; y++)
		{
			for (x = 0; x < w; x += 2)
			{
				if (i)
				{
					dst[(fb_yres - x - 1) * fb_xres + y] = Conv_YCbCr_Rgb(
							src_y[x << i], src_y[(x << i) + 1],
							src_cb[(x << i) >> 1], src_cr[(x << i) >> 1]);
					dst[(fb_yres - x - 2) * fb_xres + y] = Conv_YCbCr_Rgb(
							src_y[(x << i) + yuv_interval[i]],
							src_y[(x << i) + 1 + yuv_interval[i]],
							src_cb[((x << i) + yuv_interval[i]) >> 1],
							src_cr[((x << i) + yuv_interval[i]) >> 1]);
				}
				else
				{
					rgb_data = Conv_YCbCr_Rgb(src_y[x << i],
							src_y[(x << i) + 1], src_cb[(x << i) >> 1],
							src_cr[(x << i) >> 1]);
					dst[(fb_yres - x - 1) * fb_xres + y] = rgb_data;
					dst[(fb_yres - x - 2) * fb_xres + y] = dst[x + 1]
					= rgb_data >> 16;
				}
			}
			src_y += w << i;
			src_cb += (w << i) >> 1;
			src_cr += (w << i) >> 1;
		}
	}
	return;
#endif
	//int y = 0, x = 0;
	int x, y;
	for (y = 0; y < h; y++)
	{
		for (x = 0; x < w; x++)
		{
			rgb_data = Conv_YCbCr_Rgb(src_y[y * w + x], src_y[y * w + x + 1],
					src_cb[(y * w + x) >> 1], src_cr[(y * w + x) >> 1]);
			dst[(y * w + x) * 3] = (rgb_data & 0xf800) >> 8;
			dst[(y * w + x) * 3 + 1] = (rgb_data & 0x07e0) >> 3;
			dst[(y * w + x) * 3 + 2] = (rgb_data & 0x001f) << 3;
			x++;
			dst[(y * w + x) * 3] = (rgb_data & 0xf8000000) >> 24;
			dst[(y * w + x) * 3 + 1] = (rgb_data & 0x07e00000) >> 19;
			dst[(y * w + x) * 3 + 2] = (rgb_data & 0x001f0000) >> 13;
		}
	}
}
void _initConvTab()
{
	static int finitTab = 0;

	long int crv, cbu, cgu, cgv;
	int i, ind;

	if (finitTab != 0)
		return;

	crv = CRV;
	cbu = CBU;
	cgu = CGU;
	cgv = CGV;

	for (i = 0; i < 256; i++)
	{
		crv_tab[i] = (i - 128) * crv;
		cbu_tab[i] = (i - 128) * cbu;
		cgu_tab[i] = (i - 128) * cgu;
		cgv_tab[i] = (i - 128) * cgv;
		tab_76309[i] = CRGBY * i;
	}

	for (i = 0; i < 384; i++)
		clp[i] = 0;
	ind = 384;
	for (i = 0; i < 256; i++)
		clp[ind++] = i;
	ind = 640;
	for (i = 0; i < 384; i++)
		clp[ind++] = 255;

	finitTab = 1;
}
void yuv420ToRgb565(unsigned char *p_lum, int w_src, int h_src,
		unsigned char *dest, int w_dst, int h_dst, int topdown)
{
	_initConvTab();
	int i, j;
	int y1, y2, u, v;
	unsigned char *py1, *py2, *pu, *pv;
	int c1, c2, c3, c4;
	unsigned short *d1, *d2;
	unsigned short *ptrarr[640];

	unsigned char r, g, b;

	int s_dw, s_dh, d_dw, d_dh;

	int width, height;

	width = ((w_src < w_dst) ? w_src : w_dst);
	height = ((h_src < h_dst) ? h_src : h_dst);

	if (w_src > w_dst)
	{
		s_dw = w_src - w_dst;
		d_dw = 0;
	}
	else
	{
		s_dw = 0;
		d_dw = w_dst - w_src;
	}
	if (h_src > h_dst)
	{
		s_dh = h_src - h_dst;
		d_dh = 0;
	}
	else
	{
		s_dh = 0;
		d_dh = h_dst - h_src;
	}

	//Initialization
	py1 = p_lum;
	py2 = py1 + w_src;
	pu = p_lum + w_src * h_src;
	pv = p_lum + w_src * h_src + h_src * h_src / 4;

	switch (topdown)
	{
	case 0: // Top -> Down
		ptrarr[0] = (unsigned short *) dest;
		for (j = 1; j < height; j++)
		{
			ptrarr[j] = ptrarr[j - 1] + w_dst;
		}
		break;

	default: // Down -> Top
		ptrarr[0] = ((unsigned short *) dest) + (w_dst * (h_dst - 1)); // �»��
		for (j = 1; j < height; j++)
		{
			ptrarr[j] = ptrarr[j - 1] - w_dst;
		}
		break;
	}

	for (j = 0; j < height; j += 2)
	{

		d1 = ptrarr[j];
		d2 = ptrarr[j + 1];

		for (i = 0; i < width; i += 2)
		{

			u = *pu++;
			v = *pv++;

			c1 = crv_tab[v];
			c2 = cgu_tab[u];
			c3 = cgv_tab[v];
			c4 = cbu_tab[u];

			//up-left
			y1 = tab_76309[*py1++];
			r = clp[384 + ((y1 + c1) >> 16)]; // R
			g = clp[384 + ((y1 - c2 - c3) >> 16)]; // G
			b = clp[384 + ((y1 + c4) >> 16)]; // B
			*d1++ = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);

			//up-right
			y1 = tab_76309[*py1++];
			r = clp[384 + ((y1 + c1) >> 16)]; // R
			g = clp[384 + ((y1 - c2 - c3) >> 16)]; // G
			b = clp[384 + ((y1 + c4) >> 16)]; // B
			*d1++ = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);

			//down-left
			y2 = tab_76309[*py2++];
			r = clp[384 + ((y2 + c1) >> 16)]; // R
			g = clp[384 + ((y2 - c2 - c3) >> 16)]; // G
			b = clp[384 + ((y2 + c4) >> 16)]; // B
			*d2++ = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);

			//down-right
			y2 = tab_76309[*py2++];
			r = clp[384 + ((y2 + c1) >> 16)]; // R
			g = clp[384 + ((y2 - c2 - c3) >> 16)]; // G
			b = clp[384 + ((y2 + c4) >> 16)]; // B
			*d2++ = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
		}
		py1 += (w_src + s_dw);
		py2 += (w_src + s_dw);
		pu += (s_dw >> 1);
		pv += (s_dw >> 1);
	}

}

int convert_yuv_to_rgb_pixel(int y, int u, int v)
{
	unsigned int pixel32 = 0;
	unsigned char *pixel = (unsigned char *) &pixel32;
	int r, g, b;
	r = y + (1.370705 * (v - 128));
	g = y - (0.698001 * (v - 128)) - (0.337633 * (u - 128));
	b = y + (1.732446 * (u - 128));
	if (r > 255)
		r = 255;
	if (g > 255)
		g = 255;
	if (b > 255)
		b = 255;
	if (r < 0)
		r = 0;
	if (g < 0)
		g = 0;
	if (b < 0)
		b = 0;
	pixel[0] = r * 220 / 256;
	pixel[1] = g * 220 / 256;
	pixel[2] = b * 220 / 256;
	return pixel32;
}
int YUYVToRGB(unsigned char *yuv, unsigned char *rgb, unsigned int width,
		unsigned int height)
{
	unsigned int in, out = 0;
	unsigned int pixel_16;
	unsigned char pixel_24[3];
	unsigned int pixel32;
	int y0, u, y1, v;
	for (in = 0; in < width * height * 2; in += 4)
	{
		pixel_16 = yuv[in + 3] << 24 | yuv[in + 2] << 16 | yuv[in + 1] << 8
				| yuv[in + 0];
		y0 = (pixel_16 & 0x000000ff);
		u = (pixel_16 & 0x0000ff00) >> 8;
		y1 = (pixel_16 & 0x00ff0000) >> 16;
		v = (pixel_16 & 0xff000000) >> 24;
		pixel32 = convert_yuv_to_rgb_pixel(y0, u, v);
		pixel_24[0] = (pixel32 & 0x000000ff);
		pixel_24[1] = (pixel32 & 0x0000ff00) >> 8;
		pixel_24[2] = (pixel32 & 0x00ff0000) >> 16;
		rgb[out++] = pixel_24[0];
		rgb[out++] = pixel_24[1];
		rgb[out++] = pixel_24[2];
		pixel32 = convert_yuv_to_rgb_pixel(y1, u, v);
		pixel_24[0] = (pixel32 & 0x000000ff);
		pixel_24[1] = (pixel32 & 0x0000ff00) >> 8;
		pixel_24[2] = (pixel32 & 0x00ff0000) >> 16;
		rgb[out++] = pixel_24[0];
		rgb[out++] = pixel_24[1];
		rgb[out++] = pixel_24[2];
	}
	return 0;
}

