/*
 * uApi.h
 *
 *  Created on: 2011-4-26
 *      Author: lkppost
 */

#ifndef UAPI_H_
#define UAPI_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <termios.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <fcntl.h>

#include <sys/time.h>

typedef unsigned char BYTE;

__u32 Conv_YCbCr_Rgb(__u8 y0, __u8 y1, __u8 cb0, __u8 cr0);
void YUVToRGB(int w, int h, BYTE *src, BYTE *dst);
int YUYVToRGB(BYTE *yuv, BYTE *rgb, unsigned int width, unsigned int height);
int convert_yuv_to_rgb_pixel(int y, int u, int v);
void yuv420ToRgb565(unsigned char *p_lum, int w_src, int h_src,
		unsigned char *dest, int w_dst, int h_dst, int topdown);
void _initConvTab();
#endif /* UAPI_H_ */
