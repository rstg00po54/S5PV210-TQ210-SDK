#include "uUsbCamera.h"
#include <QFile>
#include <iostream>
#include <assert.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <malloc.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
//#include <asm/types.h>            // for videodev2.h
#include <QColor>
#define CLEAR(x) memset (&(x), 0, sizeof (x))

typedef enum {
	IO_METHOD_READ, IO_METHOD_MMAP, IO_METHOD_USERPTR,
} io_method;

struct buffer {
	unsigned char * start;
	size_t length;
};

int fb_fd;
char *fbmem = NULL;
unsigned int fb_length = 0;

typedef struct fb_var_screeninfo F_VINFO;

char dev_name[100];
static io_method io = IO_METHOD_MMAP;
struct buffer * buffers = NULL;
static unsigned int n_buffers = 0;
struct v4l2_format fmt;
using namespace std;

bool g_bFdPreview;//是否预览到fb
static unsigned int fb_grab(int fd, char **fbmem)
{
	F_VINFO modeinfo;
	unsigned int length;

	if (ioctl(fd, FBIOGET_VSCREENINFO, &modeinfo) < 0)
	{
		perror("FBIOGET_VSCREENINFO");
		exit ( EXIT_FAILURE);
	}
	length = modeinfo.xres * modeinfo.yres * (modeinfo.bits_per_pixel >> 3);

	printf("fb memory info=xres (%d) x yres (%d), %d bpp\n", modeinfo.xres,
			modeinfo.yres, modeinfo.bits_per_pixel);
	*fbmem
			= (char *) mmap(0, length, PROT_READ | PROT_WRITE, MAP_SHARED, fd,
					0);
	if (*fbmem < 0)
	{
		perror("mmap()");
		length = 0;
	}

	return length;
}

static void errno_exit(const char * s) {
	fprintf(stderr, "%s error %d, %s\n", s, errno, strerror(errno));
	//exit ( EXIT_FAILURE);
}

#define CLEAR(x) memset (&(x), 0, sizeof (x))

/*typedef struct VideoBuffer
 {
 unsigned char *start;
 size_t offset;
 size_t length;
 } VideoBuffer;*/
//unsigned int numBufs;
//struct v4l2_capability cap; //获取摄像头的类型等参数

//struct v4l2_cropcap cropcap; //设置视频信号的边框
//struct v4l2_crop crop;
//struct v4l2_requestbuffers req; //申请帧缓冲
//struct v4l2_format fmt; //设置获取视频的格式
//VideoBuffer *buffers;// = (VideoBuffer *) calloc(req.count, sizeof(VideoBuffer)); //将VIDIOC_REQBUFS获取内存转为物理空间

//enum v4l2_buf_type type; //开始视频显示
//unsigned char *ptcur;

static int xioctl(int fd, int request, void * arg) {
	int r;
	do
		r = ioctl(fd, request, arg);
	while (-1 == r && EINTR == errno);

	return r;
}

using namespace std;

QUsbCamera::QUsbCamera(CameraType type, QString devname, int channel) {
	m_eType = type;
	m_strDevName = devname;
	m_iFd = -1;
	m_iChannel = channel;
	pixelformat = V4L2_PIX_FMT_YUYV;
	m_bDoCapture = false;
	m_bOk = false;
	memset(dev_name, 0x00, sizeof(dev_name));
	memcpy(dev_name, devname.toStdString().c_str(), devname.length());
}

QUsbCamera::~QUsbCamera() {
}
void QUsbCamera::SetImageSize(int iWidth, int iHeight) {
	m_iWidth = iWidth;
	m_iHeight = iHeight;
}
CameraErrorCode QUsbCamera::getLastErrorCode() {
	return m_eErrorCode;
}
bool QUsbCamera::OpenDevice() {
	if (open_device()) {
		//		cout << "设备打开成功" << endl;
		if (init_device()) {
			if (start_capturing())
				return true;
		}
	} else
		//		cout << "设备打开失败" << endl;
		return false;
}

void QUsbCamera::SetImageFormate(int formate)//0rgb,1yuyv
{

}
bool QUsbCamera::GetBuffer(unsigned char *image) {
	mainloop(image);

	if (g_bFdPreview)
	{
		//pixelformat == V4L2_PIX_FMT_YUV420
		/*if ((ret = read(m_iFd, fbmem, m_iWidth * m_iHeight * 3 / 2)) < 0)
		{
			m_eErrorCode =READFAIL;
			perror("read error");
			return false;
		}*/
		memcpy(fbmem,image, m_iWidth * m_iHeight * 3 / 2);
	}

	return true;
}
bool QUsbCamera::SaveImage(char *image, char *name, int quality) {
	unsigned char image_buffer[m_iWidth * m_iHeight * 3];
	for (int y = 0; y < m_iHeight; y++)
		for (int x = 0; x < m_iWidth; x++) {
			image_buffer[(y * m_iWidth + x) * 3] = (((__u16 *) image)[y
					* m_iWidth + x] & 0xf800) >> 8;
			image_buffer[(y * m_iWidth + x) * 3 + 1]
					= (((__u16 *) image)[y * m_iWidth + x] & 0x07e0) >> 3;
			image_buffer[(y * m_iWidth + x) * 3 + 2]
					= (((__u16 *) image)[y * m_iWidth + x] & 0x001f) << 3;
		}

	if (write_JPEG_file(m_iWidth, m_iHeight, name, image_buffer, quality) == 0)
	{
		//		printf("保存完成\n");
		return true;
	}
	return false;
}
bool QUsbCamera::GetDeviceStatus() {
	return m_iFd > 0 ? true : false;
}
void QUsbCamera::CloseDevice() {
	stop_capturing();
	uninit_device();
	close_device();
}
bool QUsbCamera::getMaxSize(int &width, int &height) {
	width = 1024;
	height = 768;
	return true;
}
bool QUsbCamera::open_device(void) {
	struct stat st;

	if (-1 == stat(dev_name, &st)) {
		fprintf(stderr, "Cannot identify '%s': %d, %s\n", dev_name, errno,
				strerror(errno));
		return false;
	}

	if (!S_ISCHR(st.st_mode)) {
		fprintf(stderr, "%s is no device\n", dev_name);
		return false;
	}

	m_iFd = open(dev_name, O_RDWR /* required */| O_NONBLOCK, 0);

	if (-1 == m_iFd) {
		m_eErrorCode = OPENFAIL;
		fprintf(stderr, "Cannot open '%s': %d, %s\n", dev_name, errno,
				strerror(errno));
		return false;
	}
	return true;
}
bool QUsbCamera::init_device(void) {
	struct v4l2_capability cap;
	struct v4l2_cropcap cropcap;
	struct v4l2_crop crop;
	unsigned int min;

	if (-1 == xioctl(m_iFd, VIDIOC_QUERYCAP, &cap)) {
		if (EINVAL == errno) {
			fprintf(stderr, "%s is no V4L2 device\n", dev_name);
			return false;
		} else {
			errno_exit("VIDIOC_QUERYCAP");
			return false;
		}
	}

	if (!(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)) {
		fprintf(stderr, "%s is no video capture device\n", dev_name);
		//		exit ( EXIT_FAILURE);
		return false;
	}

	switch (io) {
	case IO_METHOD_READ:
		if (!(cap.capabilities & V4L2_CAP_READWRITE)) {
			fprintf(stderr, "%s does not support read i/o\n", dev_name);
			return false;
		}
		break;
	case IO_METHOD_MMAP:
	case IO_METHOD_USERPTR:
		if (!(cap.capabilities & V4L2_CAP_STREAMING)) {
			fprintf(stderr, "%s does not support streaming i/o\n", dev_name);
			return false;
		}
		break;
	}

	v4l2_input input;
	memset(&input, 0, sizeof(struct v4l2_input));
	input.index = 0;
	int rtn = ioctl(m_iFd, VIDIOC_S_INPUT, &input);
	if (rtn < 0) {
		printf("VIDIOC_S_INPUT:rtn(%d)\n", rtn);
		return false;
	}


	/* Select video input, video standard and tune here. */CLEAR(cropcap);

	cropcap.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

	if (0 == xioctl(m_iFd, VIDIOC_CROPCAP, &cropcap)) {
		crop.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		crop.c = cropcap.defrect; /* reset to default */

		if (-1 == xioctl(m_iFd, VIDIOC_S_CROP, &crop)) {
			switch (errno) {
			case EINVAL:
				/* Cropping not supported. */
				break;
			default:
				/* Errors ignored. */
				break;
			}
		}
	} else {
		/* Errors ignored. */
	}

	struct v4l2_fmtdesc fmtdesc; //获取摄像头
	memset(&fmtdesc, 0, sizeof(fmtdesc));
	struct v4l2_format fmt; //设置获取视频的格式
	memset(&fmt, 0, sizeof(fmt));
	fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE; //视频数据流类型，永远都是V4L2_BUF_TYPE_VIDEO_CAPTURE
	//	fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG;			//视频源的格式为JPEG或YUN4:2:2或RGB
	fmt.fmt.pix.width = m_iWidth; //设置视频宽度
	fmt.fmt.pix.height = m_iHeight; //设置视频高度
	fmtdesc.index = 0;
	fmtdesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	if (-1 == ioctl(m_iFd, VIDIOC_ENUM_FMT, &fmtdesc))
		return false;
	//printf("VIDIOC_ENUM_FMT(%s, VIDEO_CAPTURE)\n", fmtdesc.description);

	if (strcmp((const char*) fmtdesc.description, "RGB565") == 0) {
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_RGB565;//V4L2_PIX_FMT_YUV420;//;
		pixelformat = V4L2_PIX_FMT_RGB565;
	} else if (strcmp((const char*) fmtdesc.description, "MJPEG") == 0) //视频源的格式为JPEG或YUN4:2:2或RGB
	{
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG; //视频源的格式为MJPEG
		pixelformat = V4L2_PIX_FMT_MJPEG;
	} else if (strcmp((const char*) fmtdesc.description, "JPEG") == 0) {
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG; //视频源的格式为MJPEG
		pixelformat = V4L2_PIX_FMT_MJPEG;
	} else if (strcmp((const char*) fmtdesc.description, "YUV 4:2:2 (YUYV)")
			== 0) {
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV; //视频源的格式为YUYV
		pixelformat = V4L2_PIX_FMT_YUYV;
	} else {
		fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUV420; //视频源的格式为JPEG或YUN4:2:2或RGB
		pixelformat = V4L2_PIX_FMT_YUV420;
	}
	if (ioctl(m_iFd, VIDIOC_S_FMT, &fmt) < 0) //使配置生效
	{
		printf("set format failed\n");
		return false;
	}

	setRotation(180);

	/*	CLEAR(fmt);

	 fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	 fmt.fmt.pix.width = 640;
	 fmt.fmt.pix.height = 480;
	 fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
	 fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;

	 if (-1 == xioctl(fd, VIDIOC_S_FMT, &fmt))
	 errno_exit("VIDIOC_S_FMT");*/

	/* Note VIDIOC_S_FMT may change width and height. */

	/* Buggy driver paranoia. */
	min = fmt.fmt.pix.width * 2;
	if (fmt.fmt.pix.bytesperline < min)
		fmt.fmt.pix.bytesperline = min;
	min = fmt.fmt.pix.bytesperline * fmt.fmt.pix.height;
	if (fmt.fmt.pix.sizeimage < min)
		fmt.fmt.pix.sizeimage = min;

	switch (io) {
	case IO_METHOD_READ:
		init_read(fmt.fmt.pix.sizeimage);
		break;

	case IO_METHOD_MMAP:
		init_mmap();
		break;

	case IO_METHOD_USERPTR:
		init_userp(fmt.fmt.pix.sizeimage);
		break;
	}

	if (g_bFdPreview)
	{
		fb_fd = open("/dev/fb0", O_RDWR);
		if (fb_fd < 0)
		{
			return false;
		}

		if ((fb_length = fb_grab(fb_fd, &fbmem)) == 0)
			cout << "fd mmap fail" << endl;

		memset(fbmem, 0, fb_length);
	}

	return true;
}
void QUsbCamera::init_read(unsigned int buffer_size) {
	buffers = (buffer *) calloc(1, sizeof(*buffers));

	if (!buffers) {
		fprintf(stderr, "Out of memory\n");
		exit ( EXIT_FAILURE);
	}

	buffers[0].length = buffer_size;
	buffers[0].start = (unsigned char *) malloc(buffer_size);

	if (!buffers[0].start) {
		fprintf(stderr, "Out of memory\n");
		exit ( EXIT_FAILURE);
	}
}

bool QUsbCamera::init_mmap(void) {
	struct v4l2_requestbuffers req;

	CLEAR(req);

	req.count = 1;
	req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	req.memory = V4L2_MEMORY_MMAP;

	if (-1 == xioctl(m_iFd, VIDIOC_REQBUFS, &req)) {
		if (EINVAL == errno) {
			fprintf(stderr, "%s does not support "
				"memory mapping\n", dev_name);
			return false;
		} else {
			errno_exit("VIDIOC_REQBUFS");
			return false;
		}
	}

	/*if (req.count < 2)
	 {
	 fprintf(stderr, "Insufficient buffer memory on %s\n", dev_name);
	 return false;
	 }*/

	buffers = (buffer *) calloc(req.count, sizeof(*buffers));

	if (!buffers) {
		fprintf(stderr, "Out of memory\n");
		return false;
	}

	for (n_buffers = 0; n_buffers < req.count; ++n_buffers) {
		struct v4l2_buffer buf;

		CLEAR(buf);

		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		buf.memory = V4L2_MEMORY_MMAP;
		buf.index = n_buffers;

		if (-1 == xioctl(m_iFd, VIDIOC_QUERYBUF, &buf)) {
			errno_exit("VIDIOC_QUERYBUF");
			return false;
		}

		buffers[n_buffers].length = buf.length;
		buffers[n_buffers].start = (unsigned char *) mmap(
				NULL /* start anywhere */, buf.length,
				PROT_READ | PROT_WRITE /* required */,
				MAP_SHARED /* recommended */, m_iFd, buf.m.offset);

		if (MAP_FAILED == buffers[n_buffers].start)
			return false;
	}
	return true;
}

void QUsbCamera::init_userp(unsigned int buffer_size) {
	struct v4l2_requestbuffers req;
	unsigned int page_size;

	page_size = getpagesize();
	buffer_size = (buffer_size + page_size - 1) & ~(page_size - 1);

	CLEAR(req);

	req.count = 1;
	req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	req.memory = V4L2_MEMORY_USERPTR;

	if (-1 == xioctl(m_iFd, VIDIOC_REQBUFS, &req)) {
		if (EINVAL == errno) {
			fprintf(stderr, "%s does not support "
				"user pointer i/o\n", dev_name);
			exit ( EXIT_FAILURE);
		} else {
			errno_exit("VIDIOC_REQBUFS");
		}
	}

	buffers = (buffer *) calloc(4, sizeof(*buffers));

	if (!buffers) {
		fprintf(stderr, "Out of memory\n");
		exit ( EXIT_FAILURE);
	}

	for (n_buffers = 0; n_buffers < 4; ++n_buffers) {
		buffers[n_buffers].length = buffer_size;
		buffers[n_buffers].start = (unsigned char *) memalign(
		/* boundary */page_size, buffer_size);

		if (!buffers[n_buffers].start) {
			fprintf(stderr, "Out of memory\n");
			exit ( EXIT_FAILURE);
		}
	}
}

int QUsbCamera::read_frame(unsigned char *image) {
	struct v4l2_buffer buf;
	unsigned int i;

	switch (io) {
	case IO_METHOD_READ:
		if (-1 == read(m_iFd, buffers[0].start, buffers[0].length)) {
			switch (errno) {
			case EAGAIN:
				return 0;

			case EIO:
				/* Could ignore EIO, see spec. */

				/* fall through */

			default:
				errno_exit("read");
			}
		}

		//process_image(buffers[0].start);

		break;

	case IO_METHOD_MMAP:
		CLEAR(buf);

		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		buf.memory = V4L2_MEMORY_MMAP;

		if (-1 == xioctl(m_iFd, VIDIOC_DQBUF, &buf)) {
			switch (errno) {
			case EAGAIN:
				return 0;

			case EIO:
				/* Could ignore EIO, see spec. */

				/* fall through */

			default:
				errno_exit("VIDIOC_DQBUF");
			}
		}

		assert(buf.index < n_buffers);

		process_image(buf, image);

		if (-1 == xioctl(m_iFd, VIDIOC_QBUF, &buf))
			errno_exit("VIDIOC_QBUF");

		break;

	case IO_METHOD_USERPTR:
		CLEAR(buf);

		buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
		buf.memory = V4L2_MEMORY_USERPTR;

		if (-1 == xioctl(m_iFd, VIDIOC_DQBUF, &buf)) {
			switch (errno) {
			case EAGAIN:
				return 0;

			case EIO:
				/* Could ignore EIO, see spec. */

				/* fall through */

			default:
				errno_exit("VIDIOC_DQBUF");
			}
		}

		for (i = 0; i < n_buffers; ++i)
			if (buf.m.userptr == (unsigned long) buffers[i].start && buf.length
					== buffers[i].length)
				break;

		assert(i < n_buffers);

		//process_image((void *) buf.m.userptr);

		if (-1 == xioctl(m_iFd, VIDIOC_QBUF, &buf))
			errno_exit("VIDIOC_QBUF");

		break;
	}

	return 1;
}

void QUsbCamera::mainloop(unsigned char *image) {
	//	unsigned int count;

	//	count = 1;

	//	while (count-- > 0)
	//	{

	fd_set fds;
	struct timeval tv;
	int r;

	FD_ZERO(&fds);
	FD_SET(m_iFd, &fds);

	//	Timeout.
	tv.tv_sec = 2;
	tv.tv_usec = 0;

	r = select(m_iFd + 1, &fds, NULL, NULL, &tv);

	if (-1 == r) {
		//if (EINTR == errno)
		//continue;

		errno_exit("select");
		//return false;
	}

	if (0 == r) {
		fprintf(stderr, "select timeout\n");
		exit ( EXIT_FAILURE);
	}
	read_frame(image);
	//	if (read_frame(image))
	//		break;

	/* EAGAIN - continue select loop. */

	//	}
}

void QUsbCamera::stop_capturing(void) {
	enum v4l2_buf_type type;

	switch (io) {
	case IO_METHOD_READ:
		/* Nothing to do. */
		break;

	case IO_METHOD_MMAP:
	case IO_METHOD_USERPTR:
		type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

		if (-1 == xioctl(m_iFd, VIDIOC_STREAMOFF, &type))
			errno_exit("VIDIOC_STREAMOFF");

		break;
	}
}

bool QUsbCamera::start_capturing(void) {
	unsigned int i;
	enum v4l2_buf_type type;

	switch (io) {
	case IO_METHOD_READ:
		/* Nothing to do. */
		break;

	case IO_METHOD_MMAP:
		for (i = 0; i < n_buffers; ++i) {
			struct v4l2_buffer buf;

			CLEAR(buf);

			buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
			buf.memory = V4L2_MEMORY_MMAP;
			buf.index = i;

			if (-1 == xioctl(m_iFd, VIDIOC_QBUF, &buf)) {
				errno_exit("VIDIOC_QBUF");
				return false;
			}
		}

		type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

		if (-1 == xioctl(m_iFd, VIDIOC_STREAMON, &type)) {
			errno_exit("VIDIOC_STREAMON");
			return false;
		}
		break;

	case IO_METHOD_USERPTR:
		for (i = 0; i < n_buffers; ++i) {
			struct v4l2_buffer buf;

			CLEAR(buf);

			buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
			buf.memory = V4L2_MEMORY_USERPTR;
			buf.index = i;
			buf.m.userptr = (unsigned long) buffers[i].start;
			buf.length = buffers[i].length;

			if (-1 == xioctl(m_iFd, VIDIOC_QBUF, &buf)) {
				errno_exit("VIDIOC_QBUF");
				return false;
			}
		}

		type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

		if (-1 == xioctl(m_iFd, VIDIOC_STREAMON, &type)) {
			errno_exit("VIDIOC_STREAMON");
			return false;
		}
		break;
	}
	return true;
}

void QUsbCamera::uninit_device(void) {
	unsigned int i;

	switch (io) {
	case IO_METHOD_READ:
		free(buffers[0].start);
		break;

	case IO_METHOD_MMAP:
		for (i = 0; i < n_buffers; ++i)
			if (-1 == munmap(buffers[i].start, buffers[i].length))
				errno_exit("munmap");
		break;

	case IO_METHOD_USERPTR:
		for (i = 0; i < n_buffers; ++i)
			free(buffers[i].start);
		break;
	}

	free(buffers);
}
void QUsbCamera::close_device(void) {
	if (-1 == close(m_iFd))
		errno_exit("close");
	m_iFd = -1;
}

/*short int yuv2rgb(int y, int u, int v)
 {
 int r1, g1, b1;
 int c = y - 16, d = u - 128, e = v - 128;

 r1 = (298 * c + 409 * e + 128) >> 8;
 g1 = (298 * c - 100 * d - 208 * e + 128) >> 8;
 b1 = (298 * c + 516 * d + 128) >> 8;

 // Even with proper conversion, some values still need clipping.

 if (r1 > 255)
 r1 = 255;
 if (g1 > 255)
 g1 = 255;
 if (b1 > 255)
 b1 = 255;
 if (r1 < 0)
 r1 = 0;
 if (g1 < 0)
 g1 = 0;
 if (b1 < 0)
 b1 = 0;

 return qRgb(r1, g1, b1);
 }
 void yuyv(__u32 data, int *y, int *u, int *y2, int *v)
 {
 *y = data & 0xff;
 *u = (data >> 8) & 0xff;
 *y2 = (data >> 16) & 0xff;
 *v = (data >> 24) & 0xff;
 }
 bool yuyv2Rgb(__u32 data, unsigned int *pixel1, unsigned int *pixel2)
 {
 int y, u, v, y2;

 yuyv(data, &y, &u, &y2, &v);

 *pixel1 = yuv2rgb(y, u, v); // 1st pixel
 *pixel2 = yuv2rgb(y2, u, v); // 2nd pixel

 return y == 255 && v == 128 && u == 128;
 }*/
bool QUsbCamera::process_image(v4l2_buffer buf, unsigned char *image) {
	unsigned char * ptcur = (unsigned char *) buffers[0].start; //开始霍夫曼解码

	int iImageSize = 0;
	if (pixelformat == V4L2_PIX_FMT_RGB565) {
		memcpy(image, ptcur, m_iWidth * m_iHeight * 2);
		return true;
	} else if (pixelformat == V4L2_PIX_FMT_YUYV) {
		//		YUYVToRGB(m_iWidth, m_iHeight, ptcur, image);

		//cout<<"==============="<<endl;
		YUYVToRGB(ptcur, image, m_iWidth, m_iHeight);
		//cout<<"---------------------"<<endl;
		if (m_bDoCapture) {
			write_JPEG_file(m_iWidth, m_iHeight,
					(char *) m_strImageName.toStdString().c_str(), image,
					m_iQuality);
		}
		return true;
	} else if (pixelformat == V4L2_PIX_FMT_JPEG || pixelformat
			== V4L2_PIX_FMT_MJPEG) {
		//解码成rgb
		unsigned int k;
		for (k = 0; k < buf.bytesused; k++) {
			if ((buffers[0].start[k] == 0x000000FF) && (buffers[0].start[k + 1]
					== 0x000000C4)) {
				break;
			}
		}
		if (k == buf.bytesused) {
			printf("huffman table don't exist! \n");
			return false;
		}
		unsigned int i;
		for (i = 0; i < buf.bytesused; i++) {
			if ((buffers[0].start[i] == 0x000000FF) && (buffers[0].start[i + 1]
					== 0x000000D8))
				break;
			ptcur++;
		}
		iImageSize = buf.bytesused - i;

		JPEGToRGB(ptcur, image, m_iWidth, m_iHeight, iImageSize);
	}
	return true;
}
void QUsbCamera::printVersion()//版本信息
{
	//	cout << "天嵌科技授权给，版本V1.0" << endl;
}
bool QUsbCamera::setRotation(int value) {
	struct v4l2_control ctrl;

	ctrl.id = V4L2_CID_ROTATION;
	ctrl.value = value;
	return ioctl(m_iFd, VIDIOC_S_CTRL, &ctrl) == 0 ? true : false;
}
