#ifndef UUSBCAMERA_H_
#define UUSBCAMERA_H_


#include <QString>
#include <linux/videodev2.h>

extern "C"
{
	#include "src/uApi.h"
	#include "tqjpeg.h"
}
typedef enum
{
	SUCCESS = 0,
	OPENFAIL,
	OVERSIZE,
	READFAIL,
	UNKNOWN
} CameraErrorCode;

typedef enum
{
	CAMERA_USB = 0,
	CAMERA_CMOS
} CameraType;


extern "C" int write_JPEG_file(int w, int h, char * filename, unsigned char *image_buffer,
		int quality);
extern "C" int JPEGToRGB(unsigned char *src, unsigned char *dst, int width, int height,
		int len);
#define V4L2_CID_ROTATION		(V4L2_CID_PRIVATE_BASE + 0)

#define TQ210

//#define QUALITY 60					//照片质量
class QUsbCamera
{
public:
	QUsbCamera(CameraType type, QString devname,int channel);
	virtual ~QUsbCamera();

	bool OpenDevice();//打开设备
	bool GetBuffer(unsigned char *buffer);//获取数据流
	bool SaveImage(char *buf, char *name, int quality);//保存成图片
	//bool write_JPEG_file(unsigned char *image_buffer, char * filename,
	//		int quality);
	bool GetDeviceStatus();
	bool GetImage();
	void CloseDevice();//关闭设备
	void SetImageFormate(int formate);//0rgb,1yuyv
	void printVersion();//版本信息
	bool getMaxSize(int &width,int &height);
	bool setRotation(int value);
	void SetImageSize(int iWidth, int iHeight);
	CameraErrorCode  getLastErrorCode();
private:
	int m_iFd;
	int m_iWidth;
	int m_iHeight;
	int m_iChannel;//通道号
	int pixelformat;
	CameraType m_eType;
	CameraErrorCode m_eErrorCode;//错误代码
	QString m_strDevName;//设备名
	bool m_bOk;
	int m_iQuality;//图像质量
	QString m_strImageName;//图片名称
	bool m_bDoCapture;//是否保存图片
	bool init_device(void);
	void init_read(unsigned int buffer_size);
	bool init_mmap(void);
	void init_userp(unsigned int buffer_size);
	void uninit_device(void);
	bool start_capturing(void);
	void stop_capturing(void);
	void mainloop(unsigned char *image);
	int read_frame(unsigned char *image);
	void close_device(void);
	bool open_device(void);
	bool process_image(v4l2_buffer buf,unsigned char *image);

};
extern bool g_bFdPreview;//是否预览到fb
#endif /*UUSBCAMERA_H_*/
