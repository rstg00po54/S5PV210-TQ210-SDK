#include "tqcamera.h"
#include <QTimer>
#include <QLabel>
#include <QPoint>
#include <QPainter>
#include <QDateTime>
#include <sys/ioctl.h>
#include <unistd.h>
#include <iostream>
#include <QApplication>
#include <QDesktopWidget>
#include <QMessageBox>
#include <QString>
#include <uSetCameraPara.h>
#include <pthread.h>
#include <QFile>
#include <QHostAddress>
#include <QSettings>
#include <QDir>
#include <QStringList>
#include <QFileDialog>
#include "uiInputFileName.h"

using namespace std;

#define QUALITY 70

QUsbCamera *g_pCamera;//摄相头
int g_iWidth;//宽
int g_iHeight;//高
int g_iImageWidth;//拍照宽
int g_iImageHeight;//拍照高
int g_iChannel;//通道号
int g_iCameraType;//摄相头类型
int g_iUse;//使用标志
unsigned char *g_pBuf;//图像数据
int g_iSize;
int g_iPort;//端口
QString g_strDevName;
int g_iSetParaPort;//参数设置端口
int g_iDataState;//数据模式,0预览,1数据传输
long int encoded_size = 0;
BYTE *preview_buf;
enum QImage::Format format;

TQCamera *g_pTQCamera;
TQCamera::TQCamera(QWidget *parent, bool showmethod) :
	QWidget(parent)//, Qt::FramelessWindowHint
{
	this->setWindowTitle(trUtf8("广州天嵌科技摄相头程序V1.0(www.EmbedSky.com)"));

	//	lbTitle = new QLabel(trUtf8("广州天嵌科技摄相头程序V1.0(www.EmbedSky.net)"));
	lbTitle = new QLabel(trUtf8("天嵌科技摄像头程序"));
	lbTitle->setAlignment(Qt::AlignCenter);
	QRect screen_size = QApplication::desktop()->screenGeometry();

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	//	this->setGeometry(0, 0, screen_size.width(), screen_size.height());

	m_strRootDir = "/opt";
	m_iWidth = screen_size.width();
	m_iHeight = screen_size.height();
	g_iDataState = 0;

	setGeometry(0, 0, m_iWidth, m_iHeight);

	//m_ifn = new QInputFileName();
	//connect(m_ifn, SIGNAL(ConfirmSignal()), this, SLOT(ConfirmSlot()));//CancelSignal
	//connect(m_ifn, SIGNAL(CancelSignal()), this, SLOT(CancelSlot()));//

	v4l2_fd = -1;

	//m_bSavePicture = false;
	m_bIsFullScreen = false;
	m_pTimer = new QTimer(this);
	connect(m_pTimer, SIGNAL(timeout()), this, SLOT(RefreshImage()));

	centralLayout = new QVBoxLayout;
	scroll = new QScrollArea;
	scroll->setWidgetResizable(true);
	scroll->setAlignment(Qt::AlignCenter);
	scroll->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
	m_plbImage = new MyLabel();
	scroll->setWidget(m_plbImage);
	ReadVideoPara();
	format = QImage::Format_RGB888;

	g_pBuf = (unsigned char *) malloc((1 * 1) << 1);
	preview_buf = (BYTE *) malloc(1 * sizeof(BYTE *));

	m_plbImage->setGeometry(0, 0, g_iWidth, g_iHeight);
	//StartCamera();
	funcLayout = new QHBoxLayout;

	QPixmap pix;
	m_pbHelp = new QPushButton(trUtf8("帮助"), this);
	m_pbHelp->setText("");
	m_pbHelp->setMaximumWidth(60);
	m_pbHelp->setMaximumHeight(32);
	m_pbHelp->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));

	m_pbKey = new QPushButton(tr("输入法"), this);
	m_pbKey->setText("");
	m_pbKey->setMaximumWidth(60);
	m_pbKey->setMaximumHeight(32);
	m_pbKey->setIconSize(QSize(60, 32));
	pix.load("/opt/PDA/app/images/key.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbKey->setIcon(QIcon(pix));

	connect(m_pbKey, SIGNAL(clicked()), this, SLOT(pbKeyShowHide()));

	m_pbSetPara = new QPushButton(trUtf8("参数设置"), this);
	m_pbSetPara->setText("");
	m_pbSetPara->setMaximumWidth(60);
	m_pbSetPara->setMaximumHeight(32);
	m_pbSetPara->setIconSize(QSize(60, 32));

	pix.load("/opt/PDA/app/images/setPara.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbSetPara->setIcon(QIcon(pix));

	m_pbStart = new QPushButton(trUtf8("开始"), this);
	m_pbStart->setText("");
	m_pbStart->setMaximumWidth(60);
	m_pbStart->setMaximumHeight(32);
	m_pbStart->setIconSize(QSize(60, 32));

	pix.load("/opt/PDA/app/images/start.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbStart->setIcon(QIcon(pix));

	m_pbSave = new QPushButton(trUtf8("保存图片"), this);
	m_pbSave->setText("");
	m_pbSave->setMaximumWidth(60);
	m_pbSave->setMaximumHeight(32);
	m_pbSave->setIconSize(QSize(60, 32));

	pix.load("/opt/PDA/app/images/save.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbSave->setIcon(QIcon(pix));

	m_pbStop = new QPushButton(trUtf8("停止"), this);
	m_pbStop->setText("");
	m_pbStop->setMaximumWidth(60);
	m_pbStop->setMaximumHeight(32);
	m_pbStop->setIconSize(QSize(60, 32));

	pix.load("/opt/PDA/app/images/pause.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbStop->setIcon(QIcon(pix));

	m_pbQuit = new QPushButton(trUtf8("退出"), this);
	m_pbQuit->setText("");
	m_pbQuit->setMaximumWidth(60);
	m_pbQuit->setMaximumHeight(32);
	m_pbQuit->setIconSize(QSize(60, 32));

	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbQuit->setIcon(QIcon(pix));

	//	funcLayout->addSpacing(20);
	funcLayout->addWidget(m_pbHelp);
	funcLayout->addWidget(m_pbKey);
	funcLayout->addWidget(m_pbSetPara);
	/*	funcLayout->addWidget(m_rbPreview);
	 funcLayout->addWidget(m_rbDataTransfer);*/
	funcLayout->addWidget(m_pbStart);
	funcLayout->addWidget(m_pbSave);
	funcLayout->addWidget(m_pbStop);
	funcLayout->addWidget(m_pbQuit);
	//	funcLayout->addSpacing(20);

	centralLayout->addWidget(lbTitle);
	centralLayout->addWidget(scroll);
	centralLayout->addLayout(funcLayout);

	centralLayout->setMargin(0);
	setLayout(centralLayout);
	//	centralLayout->setGeometry(QRect(0,0,1280,1024));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));
	connect(m_pbSetPara, SIGNAL(clicked()), this, SLOT(pbSetParaClicked()));
	connect(m_pbStart, SIGNAL(clicked()), this, SLOT(pbStartClicked()));
	connect(m_pbSave, SIGNAL(clicked()), this, SLOT(pbSaveClicked()));
	connect(m_pbStop, SIGNAL(clicked()), this, SLOT(pbStopClicked()));
	connect(m_pbQuit, SIGNAL(clicked()), this, SLOT(pbQuitClicked()));
	connect(m_plbImage, SIGNAL(lbDbClicked()), this, SLOT(lbDbClicked()));

	m_pbStop->setEnabled(false);
	m_bSavePicture = true;
	//m_pbSave->setEnabled(false);
	//m_pCamera = QCamera::GetInstance(g_iCameraType, g_strDevName);
	//this->showFullScreen();

	//g_bFdPreview = false;

	m_pServer = new QTcpServer;
	if (!m_pServer->listen(QHostAddress::Any, g_iSetParaPort))
	{
		QMessageBox::warning(this, trUtf8("提示"),
				trUtf8(("配置服务端口启动失败，请检查端口是否被占用！")), QMessageBox::Ok);
	}
	connect(m_pServer, SIGNAL(newConnection()), this, SLOT(ClientConnect()));

	bShowKey = true;
	m_bShowInputMethod = showmethod;
	if (showmethod)
	{
		im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(false);
	}
	//	StartCamera();
}

TQCamera::~TQCamera()
{
	m_pTimer->stop();
	delete m_pTimer;

	m_pServer->close();
	delete m_pServer;

	if (m_pClient)
		delete m_pClient;
	free(preview_buf);
	free(g_pBuf);
	if (g_pCamera)
	{
		if (g_pCamera->GetDeviceStatus())
			g_pCamera->CloseDevice();
		delete g_pCamera;
	}
	delete lbTitle;
	delete m_plbImage;
	delete m_pbStart;
	delete m_pbStop;
	delete m_pbSave;
	delete m_pbSetPara;
	delete m_pbQuit;
	delete scroll;
}
void TQCamera::pbQuitClicked()
{
	close();
}
//定时器刷新图像
void TQCamera::RefreshImage()
{
	if (g_pCamera->GetBuffer(preview_buf))
	{
		if (!g_bFdPreview)
		{

			QImage image;
			image = QImage((uchar *) preview_buf, g_iWidth, g_iHeight, format);//QImage::Format_RGB16

			QPixmap pixmap;
			pixmap = pixmap.fromImage(image);
			m_plbImage->setPixmap(pixmap);
			m_plbImage->setFixedSize(g_iWidth, g_iHeight);
		}
	}
	else
	{
		//		cout << "获取图像失败" << endl;
	}
}

void TQCamera::pbKeyShowHide()
{
	if (m_bShowInputMethod)
	{
		bShowKey = !bShowKey;
		if (bShowKey == false)
		{
			//		m_pbKey->setText(trUtf8("隐藏"));
			((TQInputMethod *) im)->setVisible(true);
		}
		else
		{
			//		m_pbKey->setText(trUtf8("键盘"));
			((TQInputMethod *) im)->setVisible(false);
		}
	}
}

//开始预览
void TQCamera::StartCamera()
{
	bool bOk = true;
	if (g_pCamera)
	{
		g_pCamera->SetImageSize(g_iWidth, g_iHeight);
		if (g_pCamera->OpenDevice())
		{
#ifdef TQ210
			if (g_strDevName.contains("video", Qt::CaseInsensitive))
#else
			if (g_strDevName.contains("camera",
							Qt::CaseInsensitive))
#endif
			{
				format = QImage::Format_RGB16;
			}
			else
				format = QImage::Format_RGB888;
			preview_buf = (BYTE *) malloc(
					g_iWidth * g_iHeight * 3 * sizeof(BYTE));
			g_pBuf = (unsigned char *) malloc((g_iWidth * g_iHeight) << 1);
			if (preview_buf == NULL)
			{
				//							cout << "分配内存失败" << endl;
				return;
			}
			m_pbStart->setEnabled(false);
			m_pbStop->setEnabled(true);
			m_pbSetPara->setEnabled(false);
			m_pTimer->start(1000 / 30);

		}
		else
		{
			if (g_pCamera->getLastErrorCode() == OPENFAIL)
			{
				QString str = "设备打开失败";
				QMessageBox::warning(this, trUtf8("提示"),
						trUtf8((str.toStdString().c_str())), QMessageBox::Ok);
			}
			else if (g_pCamera->getLastErrorCode() == OVERSIZE)
			{
				QMessageBox::warning(this, trUtf8("提示"), trUtf8("分辨率超过限制！"),
						QMessageBox::Ok);
			}
			else
			{
				QMessageBox::warning(this, trUtf8("提示"), trUtf8("摄相头初始化失败！"),
						QMessageBox::Ok);
			}
			bOk = false;
			m_pbStart->setEnabled(true);
			m_pbStop->setEnabled(false);
			m_pbSetPara->setEnabled(true);
		}
	}
	else
	{
		QMessageBox::warning(this, trUtf8("提示"), trUtf8("未知摄相头类型"),
				QMessageBox::Ok);
	}

	if (bOk)
	{
		m_pbStart->setEnabled(false);
		m_pbStop->setEnabled(true);
		m_pbSetPara->setEnabled(false);
	}
}
//开始预览
void TQCamera::pbStartClicked()
{
	repaint();
	m_plbImage->setFixedSize(480, 272);
	StartCamera();
}
//停止预览
void TQCamera::pbStopClicked()
{

	if (g_iUse == 1)
	{
		if (g_pCamera)
		{
			g_pCamera->CloseDevice();
		}
	}
	m_pTimer->stop();
	m_pbStop->setEnabled(false);
	//m_pbSave->setEnabled(false);
	m_pbStart->setEnabled(true);
	m_pbSetPara->setEnabled(true);
}

void TQCamera::pbSetParaClicked()
{
	QSetCameraPara *para = new QSetCameraPara(this);
	para->setGeometry(0, 0, m_iWidth, m_iHeight);
	para->showFullScreen();
}
//保存图片
void TQCamera::pbSaveClicked()
{
	ImageFileConfirm("");
}
void TQCamera::ImageFileConfirm(QString fileName)
{
	//m_pInputFileName->close();
	QString imageName = fileName;
	QFileDialog *fd = new QFileDialog(this);
	fd->setGeometry(0, 0, m_iWidth, m_iHeight);
	fd->setWindowTitle(trUtf8("请选择文件夹"));
	fd->setDirectory(m_strRootDir);
	//fd->setSaveFileName("");
	fd->setFilter("AllFiles (*.jpg *.jpeg)");
	//fd->setFileMode(QFileDialog::Directory);
	fd->setWindowModality(Qt::WindowModal);
	QString strImagePath = "";
	if (fd->exec() == QDialog::Accepted)
	{
		QString fileName = fd->selectedFiles()[0];// + "/" + imageName;
		m_strRootDir = fileName.mid(0, fileName.lastIndexOf('/'));
		if (!fileName.endsWith(".jpg") && !fileName.endsWith(".jpeg"))
			fileName += ".jpg";

		bool bStartTimer = false;
		m_pTimer->stop();
		if (g_pCamera->GetDeviceStatus())
		{
			m_pTimer->stop();
			BYTE imagebuf[g_iImageWidth * g_iImageHeight * 3];
			memset(imagebuf, 0x00, sizeof(imagebuf));

			g_pCamera->GetBuffer(imagebuf);
			g_pCamera->SaveImage((char *) imagebuf,
					(char *) fileName.toUtf8().data(), 70);

			QMessageBox::warning(this, trUtf8("提示"), trUtf8(("图片保存完成")),
					QMessageBox::Ok);
			m_pTimer->start();
			bStartTimer = true;
			return;
		}
		//大于640的抓图，AV摄相头采用yuv格式
		if (g_iImageWidth > 640)
			g_pCamera->SetImageFormate(1);
		else
			g_pCamera->SetImageFormate(0);

		g_pCamera->SetImageSize(g_iImageWidth, g_iImageHeight);
		if (g_pCamera->OpenDevice())
		{
			//cout << g_iImageWidth << endl;
			//cout << g_iImageHeight << endl;
			BYTE imagebuf[g_iImageWidth * g_iImageHeight * 3];
			memset(imagebuf, 0x00, sizeof(imagebuf));

			int j = 0;
			while (j++ < 60)//跳过前面不清晰的几帧
			{
				g_pCamera->GetBuffer(imagebuf);
			}

			g_pCamera->SaveImage((char *) imagebuf,
					(char *) fileName.toUtf8().data(), 70);

			QMessageBox::warning(this, trUtf8("提示"), trUtf8(("图片保存完成")),
					QMessageBox::Ok);
		}
		else
		{
			QString str = "设备打开失败";
			QMessageBox::warning(this, trUtf8("提示"),
					trUtf8((str.toStdString().c_str())), QMessageBox::Ok);
			return;
		}

		g_pCamera->CloseDevice();
		return;
	}
}
//双击图片
void TQCamera::lbDbClicked()
{
	m_pbStart->setVisible(m_bIsFullScreen);
	m_pbStop->setVisible(m_bIsFullScreen);
	m_pbSave->setVisible(m_bIsFullScreen);
	//	m_cbResolution->setVisible(m_bIsFullScreen);
	m_pbSetPara->setVisible(m_bIsFullScreen);
	m_pbQuit->setVisible(m_bIsFullScreen);
	lbTitle->setVisible(m_bIsFullScreen);
	m_pbKey->setVisible(m_bIsFullScreen);
	m_pbHelp->setVisible(m_bIsFullScreen);
	/*	m_rbDataTransfer->setVisible(m_bIsFullScreen);
	 m_rbPreview->setVisible(m_bIsFullScreen);*/
	m_bIsFullScreen = !m_bIsFullScreen;
}

//读取配置参数
void TQCamera::ReadVideoPara()
{
	QSettings settings("/opt/PDA/configs/EmbedSkyVideo.ini",
			QSettings::IniFormat);
	settings.beginGroup("Video1");
	QString strName = settings.value("name", "/dev/video0").toString();
	//	cout << strName.toStdString().c_str() << endl;
	QString strResolution = settings.value("resolution", "320x240").toString();
	int iChannel = settings.value("channel", "0").toInt();
	int iUse = settings.value("use", 0).toInt();
	int iPort = settings.value("port", 5001).toInt();

	QStringList list = strResolution.split('x');
	if (list.count() == 2)
	{
		g_iImageWidth = list.at(0).toInt();
		g_iImageHeight = list.at(1).toInt();
	}
	else
	{
		g_iImageWidth = 160;
		g_iImageHeight = 120;
	}
	g_iWidth = g_iImageWidth;
	g_iHeight = g_iImageHeight;
	g_strDevName = strName;
	g_iChannel = iChannel;
	g_iPort = iPort;
	g_iUse = iUse;

	settings.endGroup();

	settings.beginGroup("Para");
	g_bFdPreview = settings.value("usefb", 0).toInt() == 0 ? false : true;//默认不使用
	g_iSetParaPort = settings.value("port", 6001).toInt();
	g_iDataState = settings.value("datastate", 0).toInt();//默认预览
	settings.endGroup();

	g_bFdPreview = false;//暂不支持fb preview
	InitCamera();
}
void TQCamera::InitCamera()
{
	g_iCameraType = 0;
#ifndef TQ210
	if (g_strDevName.contains("video", Qt::CaseInsensitive))
#else
	if (g_strDevName.contains("camera", Qt::CaseInsensitive))
#endif
		g_iCameraType = 1;
	if (g_iCameraType == 0)//USB
		format = QImage::Format_RGB888;
	else
		format = QImage::Format_RGB16;//AV
	g_pCamera = new QUsbCamera(CAMERA_CMOS, g_strDevName, g_iChannel);
	if (g_iCameraType == 1)
	{
		int w = 0, h = 0;
		g_pCamera->getMaxSize(w, h);
	}
}
void TQCamera::ClientConnect()
{
	m_pClient = m_pServer->nextPendingConnection();
	connect(m_pClient, SIGNAL(readyRead()), this, SLOT(ReadClient()));
}
void TQCamera::ReadClient()
{
	char cData[1024];
	memset(cData, 0x00, sizeof(cData));
	if (m_pClient->read(cData, sizeof(cData)) > 0)
	{
		if (ResetCameraPara(QString(cData)))
		{
			m_pClient->write("OK", 2);
			m_pClient->close();
			disconnect(m_pClient, SIGNAL(readyRead()), this, SLOT(ReadClient()));
			m_pServer->close();
			if (!m_pServer->listen(QHostAddress::Any, g_iSetParaPort))
			{
				QMessageBox::warning(this, trUtf8("提示"),
						trUtf8(("配置服务端口启动失败，请检查端口是否被占用！")), QMessageBox::Ok);
			}
		}
		else
			m_pClient->write("ERROR", 5);
	}
}
bool TQCamera::ResetCameraPara(QString strPara)
{
	strPara = strPara.mid(0, strPara.length() - 1);//支掉结束的#
	QStringList list = strPara.split(';');
	QStringList listPara;
	listPara << "name" << "resolution" << "channel" << "port" << "use";
	QString str = "Video";

	int iCount = 5;
#ifdef ARM
	iCount = 2;
#endif
	//cout<<"count:"<<iCount<<endl;
	if (list.count() == iCount)
	{
		for (int i = 0; i < iCount; i++)
		{
			QStringList listDetail = list.at(i).split(',');
			if (i < iCount - 1)
			{
				if (listDetail.count() == 5)
				{
					str = "Video";
					str += QString::number(i + 1);
					for (int j = 0; j < 5; j++)
					{
						/*cout << str.toStdString().c_str() << " "
						 << listPara.at(j).toStdString().c_str() << " "
						 << listDetail.at(j).toStdString().c_str()
						 << endl;*/
						SetCameraPara(str, listPara.at(j), listDetail.at(j));
					}
				}
				else
				{
					return false;
				}
			}
			else
			{
				//其他参数
				if (listDetail.count() == 3)
				{
					SetCameraPara("Para", "datastate", listDetail.at(0));
					SetCameraPara("Para", "usefb", listDetail.at(1));
					SetCameraPara("Para", "port", listDetail.at(2));
				}
				else
				{
					return false;
				}
			}
		}
	}
	else
	{
		return false;
	}

	//重新加载参数
	bool bStart = m_pbStart->isEnabled();
	if (!bStart)
		pbStopClicked();
	ReadVideoPara();
	if (!bStart)
		pbStartClicked();
	return true;
}
bool TQCamera::SetCameraPara(QString strSection, QString strKEY,
		QString strValue)
{
	QSettings settings("/opt/PDA/configs/EmbedSkyVideo.ini",
			QSettings::IniFormat);
	settings.beginGroup(strSection);
	settings.setValue(strKEY, strValue);
	settings.endGroup();
	return true;
}
void TQCamera::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
