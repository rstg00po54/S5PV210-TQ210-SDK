#ifndef TQCAMERA_H
#define TQCAMERA_H

#include <QtGui/QWidget>
#include <QImage>
#include <QTimer>
#include <QLabel>
#include <QPaintEvent>
#include <QComboBox>
#include <QPushButton>
#include "MyLabel.h"
#include "src/uUsbCamera.h"
#include <QTcpSocket>
#include <QMutex>
#include <QRadioButton>
#include <QTcpServer>
#include <QScrollArea>
#include <QHBoxLayout>
#include <QVBoxLayout>

#include "TQInputMethod.h"
#include <QWSInputMethod>

#include"uiInputFileName.h"
#include <QProcess>
#define DEBUG

class TQCamera: public QWidget
{
Q_OBJECT

public:
	TQCamera(QWidget *parent = 0, bool showmethod = false);
	~TQCamera();
	void ReadVideoPara();

private:
	int v4l2_fd;
	QTimer *m_pTimer;
	MyLabel *m_plbImage;
	QPushButton *m_pbStart;
	QPushButton *m_pbStop;
	QPushButton *m_pbSave;
	QPushButton *m_pbSetPara;
	QPushButton *m_pbQuit;
	QPushButton *m_pbHelp;
	QLabel *lbTitle;
	QScrollArea *scroll;
	QVBoxLayout *centralLayout;
	QHBoxLayout *funcLayout;
	QInputFileName *m_pInputFileName;

	bool m_bShowInputMethod;
	bool m_bSavePicture;//是否保存图片
	bool m_bIsFullScreen;//是否全屏显示
	int m_iWidth;
	int m_iHeight;
	QString m_strRootDir;

	QTcpServer *m_pServer;
	QTcpSocket *m_pClient;

	QPushButton *m_pbKey;
	QWSInputMethod* im;
	bool bShowKey;
	QProcess process;
	//QInputFileName* m_ifn;

	void StartCamera();
	void write_JPEG_file(unsigned char *imagebuf, char * filename, int quality);//保存图片
	void InitCamera();
	bool ResetCameraPara(QString strPara);
	bool SetCameraPara(QString strSection, QString strKEY, QString strValue);
public slots:
	void RefreshImage();
	void pbStartClicked();
	void pbStopClicked();
	void pbSaveClicked();
	void pbSetParaClicked();
	void pbQuitClicked();
	void lbDbClicked();
	void ClientConnect();
	void ReadClient();
	void pbKeyShowHide();
	void pbHelpClicked();
	void ImageFileConfirm(QString);//图像名输入完成
};
extern TQCamera *g_pTQCamera;
extern QUsbCamera *g_pCamera;//摄相头
extern int g_iWidth;//预览宽
extern int g_iHeight;//预览高
extern int g_iImageWidth;//拍照宽
extern int g_iImageHeight;//拍照高
extern int g_iChannel;//通道号
extern int g_iCameraType;//0ＵＳＢ，１ＡＶ
extern unsigned char *g_pBuf;//图像数据
extern QString g_strDevName;//设备名
extern int g_iPort;//端口
extern int g_iUse;//使用标志

extern int g_iSetParaPort;//参数设置端口
extern int g_iDataState;//数据模式,0预览,1数据传输
#endif // TQCAMERA_H
