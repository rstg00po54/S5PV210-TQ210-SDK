int write_JPEG_file(int w, int h, char * filename, unsigned char *image_buffer,
						int quality);
int JPEGToRGB(unsigned char *src, unsigned char *dst, int width, int height,
		int len);
