/*
 * uSetCameraPara.cpp
 *
 *  Created on: 2011-4-26
 *      Author: lkppost
 */
#include "uSetCameraPara.h"
#include <QStringList>
#include <QApplication>
#include <QDesktopWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QMessageBox>
#include "tqcamera.h"
#include <QGroupBox>
#include <QStyle>
#include <QSettings>
#include <QDir>
//AV 640x480

//ov9650 1024x768 1280x1024

//usb
//#include <iostream>
//using namespace std;
QSetCameraPara::QSetCameraPara(QWidget *parent) :
	QDialog(parent)
{
	this->setWindowTitle(trUtf8("天嵌科技摄相头程序V1.0(www.EmbedSky.net)"));

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	//setGeometry(0, 0, 480, 272);

	this->setAutoFillBackground(true);

	QTabWidget *tab = new QTabWidget(this);
	tab->setAutoFillBackground(true);

	QGroupBox *groupBox1 = new QGroupBox(trUtf8(""), this);

	groupBox1->setAutoFillBackground(true);

	//g_iCameraType = 0;
	// TODO Auto-generated constructor stub
	QLabel *lb11 = new QLabel(trUtf8("设备名："), this);
	QLabel *lb12 = new QLabel(trUtf8("分辨率："), this);
	QLabel *lb13 = new QLabel(trUtf8("通道号："), this);
	QLabel *lb14 = new QLabel(trUtf8("端　口："), this);
	QLabel *lb15 = new QLabel(trUtf8("是否启用："), this);

	m_cbDevName1 = new QComboBox(this);
	//m_cbDevName1->setMaximumWidth(120);
	m_cbDevName1->addItem("/dev/camera");
	m_cbDevName1->addItem("/dev/AVcamera");
	m_cbDevName1->addItem("/dev/video0");
	m_cbDevName1->addItem("/dev/video1");
	m_cbDevName1->addItem("/dev/video2");
	m_cbDevName1->addItem("/dev/video3");
	m_cbDevName1->addItem("/dev/video4");
	m_cbDevName1->addItem("/dev/video5");
	m_cbDevName1->setCurrentIndex(m_cbDevName1->findText(g_strDevName));

	//m_cbDevName1->setMinimumWidth(120);


	m_cbResolution1 = new QComboBox(this);
	//m_cbResolution1->setMaximumWidth(120);
	m_cbResolution1->addItem("160x120");
	m_cbResolution1->addItem("176x144");
	m_cbResolution1->addItem("320x240");
	m_cbResolution1->addItem("352x288");
	m_cbResolution1->addItem("480x272");
	m_cbResolution1->addItem("640x480");
	m_cbResolution1->addItem("1280x960");
	m_cbResolution1->addItem("1600x1200");
	m_cbResolution1->setCurrentIndex(2);
	//m_cbResolution1->setMinimumWidth(110);


	m_cbChannel1 = new QComboBox(this);
	//m_cbChannel1->setMaximumWidth(60);
	m_cbChannel1->addItem("0");
	m_cbChannel1->addItem("1");
	m_cbChannel1->addItem("2");
	m_cbChannel1->addItem("3");
	m_cbChannel1->setCurrentIndex(0);
	m_cbChannel1->setMinimumWidth(60);
	m_cbChannel1->setEnabled(false);

	m_cbUse1 = new QCheckBox(trUtf8("启用"), this);
	m_cbUse1->setChecked(true);

	m_spPort1 = new QSpinBox(this);
	m_spPort1->setRange(3000, 65535);
	m_spPort1->setValue(5001);

	QVBoxLayout *vLayout1 = new QVBoxLayout;

	QHBoxLayout *devLayout1 = new QHBoxLayout;

	//devLayout->addSpacing(70);
	devLayout1->addStretch(1);
	devLayout1->addWidget(lb11);
	devLayout1->addWidget(m_cbDevName1);
	devLayout1->addStretch(1);

	QHBoxLayout *resLayout1 = new QHBoxLayout;

	resLayout1->addStretch(1);
	resLayout1->addWidget(lb12);
	resLayout1->addWidget(m_cbResolution1, 0, Qt::AlignLeft);
	resLayout1->addSpacing(25);
	resLayout1->addStretch(1);

	QHBoxLayout *channelayout1 = new QHBoxLayout;

	channelayout1->addStretch(1);
	channelayout1->addWidget(lb13);
	channelayout1->addWidget(m_cbChannel1);
	//channelayout1->addWidget(lb1);
	channelayout1->addSpacing(53);
	channelayout1->addStretch(1);

	QHBoxLayout *uselayout1 = new QHBoxLayout;

	uselayout1->addStretch(1);
	uselayout1->addWidget(lb15);
	uselayout1->addWidget(m_cbUse1);
	uselayout1->addSpacing(85);
	uselayout1->addStretch(1);

	QHBoxLayout *portlayout1 = new QHBoxLayout;

	portlayout1->addStretch(1);
	portlayout1->addWidget(lb14);
	portlayout1->addWidget(m_spPort1);
	portlayout1->addSpacing(55);
	portlayout1->addStretch(1);

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	QPushButton *pbCancel = new QPushButton(trUtf8("取消"), this);
	QPixmap pix;
	pbCancel->setText("");
	pbCancel->setMaximumWidth(60);
	pbCancel->setMaximumHeight(32);
	pbCancel->setIconSize(QSize(60, 32));

	pix.load("/opt/PDA/app/images/cancel.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	pbCancel->setIcon(QIcon(pix));

	QPushButton *pbConfirm = new QPushButton(trUtf8("确认"), this);
	pbConfirm->setMaximumWidth(60);
	pbConfirm->setText("");
	pbConfirm->setMaximumWidth(60);
	pbConfirm->setMaximumHeight(32);
	pbConfirm->setIconSize(QSize(60, 32));

	pix.load("/opt/PDA/app/images/confirm.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 32, Qt::IgnoreAspectRatio);//图片大小
	pbConfirm->setIcon(QIcon(pix));

	buttonLayout->addSpacing(60);
	buttonLayout->addWidget(pbCancel);
	buttonLayout->addSpacing(30);
	buttonLayout->addWidget(pbConfirm);
	buttonLayout->addSpacing(60);

	vLayout1->addLayout(uselayout1);
	vLayout1->addLayout(devLayout1);
	vLayout1->addLayout(resLayout1);
	vLayout1->addLayout(channelayout1);
	vLayout1->addLayout(portlayout1);


	groupBox1->setLayout(vLayout1);


	QGroupBox *groupBox5 = new QGroupBox(tr(""), this);

	groupBox5->setAutoFillBackground(true);
	QVBoxLayout *vLayout5 = new QVBoxLayout;
	QHBoxLayout *previewLayout = new QHBoxLayout;

	QLabel *lbPreview = new QLabel(trUtf8("模式选择："));
	m_rbPreview = new QRadioButton(trUtf8("预览"), this);
	m_rbPreview->setChecked(true);
	m_rbDataTransfer = new QRadioButton(trUtf8("数据传输"), this);

	previewLayout->addStretch(1);
	previewLayout->addWidget(lbPreview);
	previewLayout->addWidget(m_rbPreview);
	previewLayout->addWidget(m_rbDataTransfer);
	previewLayout->addStretch(1);

	vLayout5->addLayout(previewLayout);

	QHBoxLayout *fbLayout = new QHBoxLayout;
	QLabel *lbUseFb = new QLabel(trUtf8("是否使用fb："));
	m_cbUseFb = new QCheckBox(trUtf8("启用(只适用于7113和9650摄相头)"), this);

	fbLayout->addStretch(1);
	fbLayout->addWidget(lbUseFb);
	fbLayout->addWidget(m_cbUseFb);
	fbLayout->addSpacing(40);
	fbLayout->addStretch(1);

	vLayout5->addLayout(fbLayout);

	QHBoxLayout *SrvPortLayout = new QHBoxLayout;
	QLabel *lbSrvPort = new QLabel(trUtf8("服务端口："));
	m_spPort5 = new QSpinBox(this);
	m_spPort5->setRange(3000, 65535);
	m_spPort5->setValue(6001);

	SrvPortLayout->addStretch(1);
	SrvPortLayout->addWidget(lbSrvPort);
	SrvPortLayout->addWidget(m_spPort5);
	SrvPortLayout->addSpacing(63);
	SrvPortLayout->addStretch(1);

	vLayout5->addLayout(SrvPortLayout);

	groupBox5->setLayout(vLayout5);

	tab->addTab(groupBox1, trUtf8("视频1设置"));
	tab->addTab(groupBox5, trUtf8("其他参数设置"));

	QVBoxLayout *vLayout = new QVBoxLayout;
	vLayout->addWidget(tab);
	vLayout->addLayout(buttonLayout);
	setLayout(vLayout);

	connect(m_cbDevName1, SIGNAL(currentIndexChanged(int)), this,
			SLOT(cbDevNameChanged(int)));


	connect(pbCancel, SIGNAL(clicked()), this, SLOT(pbCancelClicked()));
	connect(pbConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));
	connect(m_cbUse1, SIGNAL(stateChanged(int)), this,
			SLOT(cbStateChanged(int)));


	connect(m_rbPreview, SIGNAL(clicked()), this, SLOT(rbPreviewClicked()));
	connect(m_rbDataTransfer, SIGNAL(clicked()), this,
			SLOT(rbDataTransferClicked()));

	ReadVideoPara();
}

QSetCameraPara::~QSetCameraPara()
{
	delete m_cbResolution1;
	delete m_cbDevName1;
	delete m_cbChannel1;
	delete m_cbUse1;
	delete m_spPort1;

	delete m_rbPreview;//预览
	delete m_rbDataTransfer;//数据传输

	delete m_cbUseFb;//是否使用fb
	delete m_spPort5;
}
//读取配置参数
void QSetCameraPara::ReadVideoPara()
{
	QSettings settings("/opt/PDA/configs/EmbedSkyVideo.ini",
			QSettings::IniFormat);
	settings.beginGroup("Video1");
	QString strName = settings.value("name", "/dev/video0").toString();
	QString strResolution = settings.value("resolution", "320x240").toString();
	int iChannel = settings.value("channel", "0").toInt();
	int iUse = settings.value("use", 0).toInt();
	int iPort = settings.value("port", 5001).toInt();

	m_cbDevName1->setCurrentIndex(m_cbDevName1->findText(strName));
	m_cbResolution1->setCurrentIndex(m_cbResolution1->findText(strResolution));
	m_cbChannel1->setCurrentIndex(
			m_cbChannel1->findText(QString::number(iChannel)));
	m_cbUse1->setChecked(iUse == 0 ? false : true);
	m_spPort1->setValue(iPort);
	if (m_cbDevName1->currentIndex() <= 1 && iUse == 1)
		m_cbChannel1->setEnabled(true);

	settings.endGroup();


	settings.beginGroup("Para");
	g_bFdPreview = settings.value("usefb", 0).toInt() == 1 ? true : false;//默认不使用
	g_iSetParaPort = settings.value("port", 6001).toInt();
	g_iDataState = settings.value("datastate", 0).toInt();//默认预览

	if (g_iDataState == 0)
		m_rbPreview->setChecked(true);
	else
		m_rbDataTransfer->setChecked(true);

	m_spPort5->setValue(g_iSetParaPort);
	if (g_bFdPreview)
		m_cbUseFb->setChecked(true);
	else
		m_cbUseFb->setChecked(false);

	settings.endGroup();

}
void QSetCameraPara::cbStateChanged(int iState)
{
	QCheckBox *cb = qobject_cast<QCheckBox *> (sender());
	bool bChecked = iState == Qt::Checked ? true : false;
	if (cb == m_cbUse1)
	{
		m_cbDevName1 ->setEnabled(bChecked);
		m_cbResolution1 ->setEnabled(bChecked);
		m_spPort1->setEnabled(bChecked);
		if (m_cbDevName1->currentIndex() <= 1 && bChecked)
			m_cbChannel1->setEnabled(true);
		else
			m_cbChannel1->setEnabled(false);
	}

}
void QSetCameraPara::cbDevNameChanged(int iIndex)
{
	QComboBox *cb = qobject_cast<QComboBox *> (sender());
	if (iIndex == 0 || iIndex == 1)
	{
		if (cb == m_cbDevName1)
		{
			m_cbResolution1->clear();
			if (iIndex == 0)//ov9650
			{
				m_cbResolution1->addItem("160x120");
				m_cbResolution1->addItem("176x144");
				m_cbResolution1->addItem("320x240");
				m_cbResolution1->addItem("352x288");
				m_cbResolution1->addItem("640x480");
				m_cbResolution1->addItem("1280x960");
				m_cbResolution1->addItem("1280x1024");
			}
			else
			{
				m_cbResolution1->addItem("160x120");
				m_cbResolution1->addItem("176x144");
				m_cbResolution1->addItem("320x240");
				m_cbResolution1->addItem("352x288");
				m_cbResolution1->addItem("640x480");
			}
		}

		if (cb == m_cbDevName1)
		{
			g_iCameraType = 1;
			m_cbChannel1->setEnabled(true);
		}

	}
	else
	{
		if (cb == m_cbDevName1)
		{
			g_iCameraType = 0;
			m_cbChannel1->setEnabled(false);
		}

	}
}
void QSetCameraPara::pbCancelClicked()
{
	this->done(-1);
}
void QSetCameraPara::pbConfirmClicked()
{
	QString str;
	QStringList list;
	g_iUse = 0;
	if (m_cbUse1->isChecked())
	{
		g_iUse = 1;
		str = m_cbResolution1->currentText();
		list = str.split('x');
		g_iImageWidth = list.at(0).toInt();
		g_iImageHeight = list.at(1).toInt();
		g_iWidth = g_iImageWidth;
		g_iHeight = g_iImageHeight;
		g_strDevName = m_cbDevName1->currentText();
		g_iChannel = m_cbChannel1->currentIndex();
		g_iPort = m_spPort1->value();//端口
		if (m_cbDevName1->currentIndex() > 0)//ov9650
		{
			if (g_iWidth > 640)
			{
				QMessageBox::warning(this, trUtf8("提示"),
						trUtf8(("视频１摄相头支持的最大分辨率为640x480,请重新选择！")),
						QMessageBox::Ok);
				return;
			}
		}
		if (m_cbDevName1->currentIndex() <= 1)
		{
			g_iCameraType = 1;
		}
		else
		{
			g_iCameraType = 0;
		}
	}
	if (m_cbUseFb->isChecked())
		g_bFdPreview = true;
	else
		g_bFdPreview = false;
	if (m_rbPreview->isChecked())
		g_iDataState = 0;
	else
		g_iDataState = 1;

	g_iSetParaPort = m_spPort5->value();
	SaveVideoPara();

	g_pTQCamera->ReadVideoPara();
	this->done(0);
}

void QSetCameraPara::SaveVideoPara()
{
	QSettings settings("/opt/PDA/configs/EmbedSkyVideo.ini",
			QSettings::IniFormat);
	settings.beginGroup("Video1");

	settings.setValue("name", m_cbDevName1->currentText());
	settings.setValue("resolution", m_cbResolution1->currentText());
	settings.setValue("channel", m_cbChannel1->currentText());
	settings.setValue("use", m_cbUse1->checkState() == Qt::Checked ? 1 : 0);
	settings.setValue("port", m_spPort1->value());

	settings.endGroup();


	settings.beginGroup("Para");
	settings.setValue("usefb", m_cbUseFb->isChecked() == true ? 1 : 0);
	settings.setValue("port", m_spPort5->value());
	settings.setValue("datastate", m_rbPreview->isChecked() == true ? 0 : 1);
	settings.endGroup();

}
//合法性判断
bool QSetCameraPara::IsInputValidate()
{
	int index1 = -1;
	if (m_cbUse1->isChecked())
		index1 = m_cbDevName1->currentIndex();
	return true;
}
void QSetCameraPara::rbPreviewClicked()
{
	g_iDataState = 0;
}
void QSetCameraPara::rbDataTransferClicked()
{
	g_iDataState = 1;
}

