/*
 * uSetCameraPara.h
 *
 *  Created on: 2011-4-26
 *      Author: lkppost
 */

#ifndef USETCAMERAPARA_H_
#define USETCAMERAPARA_H_
#include <QtGui/QDialog>
#include <QComboBox>
#include <QCheckBox>
#include <QSpinBox>
#include <QRadioButton>

class QSetCameraPara: public QDialog
{
Q_OBJECT
public:
	QSetCameraPara(QWidget *parent = 0);
	virtual ~QSetCameraPara();
private:
	QComboBox *m_cbResolution1;
	QComboBox *m_cbDevName1;
	QComboBox *m_cbChannel1;
	QCheckBox *m_cbUse1;
	QSpinBox  *m_spPort1;



	QRadioButton  *m_rbPreview;//预览
	QRadioButton  *m_rbDataTransfer;//数据传输

	QCheckBox     *m_cbUseFb;//是否使用fb
	QSpinBox  *m_spPort5;

	void ReadVideoPara();
	void SaveVideoPara();
	bool IsInputValidate();
public slots:
	void cbDevNameChanged(int iIndex);
	void pbCancelClicked();
	void pbConfirmClicked();
	void cbStateChanged(int iState);
	void rbPreviewClicked();
	void rbDataTransferClicked();

};

#endif /* USETCAMERAPARA_H_ */
