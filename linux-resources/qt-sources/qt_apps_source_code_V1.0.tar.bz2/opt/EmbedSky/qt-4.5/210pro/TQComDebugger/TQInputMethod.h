

#ifndef IMFRAME_H
#define IMFRAME_H

#define ARM
#ifdef ARM
#include <QWSInputMethod>


class TQInputMethod: public QWSInputMethod
{
	Q_OBJECT
public:
	TQInputMethod();
	~TQInputMethod();
	void setMicroFocus(int, int);
	void updateHandler(int);
	void setVisible(bool visible);
private:
	QString content;

private slots:
	void sendContent(const QString&);
	void confirmContent();
};

#endif
#endif
