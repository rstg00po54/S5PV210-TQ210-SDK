/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		串口测试程序
 *    文件名:     	comdebugger.cpp
 *    文件描述:  		主界面
 *    创建日期:      2011-07-08
 *    创 建 人:      lkp
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */

#include "comdebugger.h"
#include <QTextCursor>
#include <QVBoxLayout>
#include "src/widget/uiSetComPara.h"
#include <QMessageBox>
#include <QUrl>
#include <QDesktopWidget>
#include <iostream>
#include <QFileDialog>
#include <QTextStream>
//#include "src/armapi/uArm.h"
#include <ctype.h>
#include <QRegExpValidator>
#include<QPixmap>
//#include<QProcess>
#include <QApplication>

using namespace std;
ComDebugger *g_pComDebugger;
char cData[2048];
ComDebugger::ComDebugger(QWidget *parent, bool bKeyShow) :
	QWidget(parent)
{
	this->setWindowTitle(trUtf8("天嵌科技串口工具V1.0(www.EmbedSky.net)"));
	QRect screen_size = QApplication::desktop()->screenGeometry();
	m_iWidth = screen_size.width();
	m_iHeight = screen_size.height();

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	m_iRecvCount = 0;
	m_iSendCount = 0;
	iShowKey = true;

	m_strRootDir = "/home/sky/";
	m_pTimer = new QTimer(this);
	m_pAutoSend = new QTimer(this);
	connect(m_pAutoSend, SIGNAL(timeout()), this, SLOT(pbSendClicked()));

	//	m_pteDisplay = new MyTextEdit(this);
	m_pteDisplay = new QTextEdit(this);

	//connect(m_pteDisplay, SIGNAL(EnterPressed(QString)), this, SLOT(
	//	teDisplayTextChanged(QString)));

	QLabel *pteLabel = new QLabel(trUtf8("接\n收"), this);
	QHBoxLayout *pteLayout = new QHBoxLayout;
	pteLayout->addSpacing(3);
	pteLayout->addWidget(pteLabel);
	pteLayout->addWidget(m_pteDisplay);

	//	m_leSend = new MyTextEdit(this);
	m_leSend = new QTextEdit(this);
	m_leSend->setMinimumHeight(40);

	//	m_leSend->setText(trUtf8("科技"));
	QLabel *leLabel = new QLabel(trUtf8("发\n送"), this);
	QHBoxLayout *leLayout = new QHBoxLayout;
	leLayout->addSpacing(3);
	leLayout->addWidget(leLabel);
	leLayout->addWidget(m_leSend);

	QPixmap pix;

	m_pbSelect = new QPushButton(this);
	m_pbSelect->setFixedSize(60, 28);
	m_pbSelect->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/selectFile.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	m_pbSelect->setIcon(QIcon(pix));

	connect(m_pbSelect, SIGNAL(clicked()), this, SLOT(pbSelectClicked()));

	QHBoxLayout *controlsLayout = new QHBoxLayout;

	m_pbClearCount = new QPushButton(this);
	m_pbClearCount->setFixedSize(60, 28);
	m_pbClearCount->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/clearCount.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	m_pbClearCount->setIcon(QIcon(pix));

	m_pbSet = new QPushButton(this);
	m_pbSet->setFixedSize(60, 28);
	m_pbSet->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/setCom.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	m_pbSet->setIcon(QIcon(pix));

	m_pbSend = new QPushButton(this);
	m_pbSend->setFixedSize(60, 28);
	m_pbSend->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/send.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	m_pbSend->setIcon(QIcon(pix));

	m_pbKey = new QPushButton(this);
	m_pbKey->setFixedSize(60, 28);
	m_pbKey->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/key.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	m_pbKey->setIcon(QIcon(pix));
	m_pbKey->setEnabled(0);

	m_pbHelp = new QPushButton(this);
	m_pbHelp->setFixedSize(60, 28);
	m_pbHelp->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	QPushButton *pbClose = new QPushButton(this);
	pbClose->setFixedSize(82, 28);
	pbClose->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出案件图标
	pbClose->setIconSize(QSize(82, 28));

	pbClose->setFixedSize(60, 28);
	pbClose->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	pbClose->setIcon(QIcon(pix));

	connect(pbClose, SIGNAL(clicked()), this, SLOT(close()));

	connect(m_pbSend, SIGNAL(clicked()), this, SLOT(pbSendClicked()));
	connect(m_pbSet, SIGNAL(clicked()), this, SLOT(pbSetClicked()));
	//connect(m_leSend, SIGNAL(textChanged(QString)), this, SLOT(teTextChanged()));
	connect(m_pbClearCount, SIGNAL(clicked()), this,
			SLOT(pbClearCountClicked()));

	controlsLayout->addSpacing(3);
	controlsLayout->addWidget(m_pbKey);
	controlsLayout->addWidget(m_pbHelp);
	controlsLayout->addWidget(m_pbSet);
	controlsLayout->addWidget(m_pbClearCount);
	controlsLayout->addWidget(m_pbSelect);
	controlsLayout->addWidget(m_pbSend);
	controlsLayout->addWidget(pbClose);
	controlsLayout->addSpacing(3);

	//状态栏
	m_pBar = new QStatusBar(this);
	m_pBar->setMaximumHeight(25);
	m_plbUrl = new QLabel("www.EmbedSky.com", this);
	m_plbUrl->setFrameShape(QFrame::WinPanel);
	m_plbUrl->setFrameShadow(QFrame::Sunken);
	m_pBar->addWidget(m_plbUrl, 20);

	m_plbSend = new QLabel("S:0", this);
	m_plbSend->setFrameShape(QFrame::WinPanel);
	m_plbSend->setFrameShadow(QFrame::Sunken);
	m_pBar->addWidget(m_plbSend, 10);

	m_plbRecv = new QLabel("R:0", this);
	m_plbRecv->setFrameShape(QFrame::WinPanel);
	m_plbRecv->setFrameShadow(QFrame::Sunken);
	m_pBar->addWidget(m_plbRecv, 10);

	m_plbComStatus = new QLabel(trUtf8("ttyS1 已关闭 115200bps 8"), this);
	m_plbComStatus->setFrameShape(QFrame::WinPanel);
	m_plbComStatus->setFrameShadow(QFrame::Sunken);
	m_pBar->addWidget(m_plbComStatus, 50);

	m_pcbDisplay = new QCheckBox(trUtf8("Hex接收"), this);
	m_pcbDisplay->setMinimumWidth(8);
	connect(m_pcbDisplay, SIGNAL(stateChanged(int)), this,
			SLOT(cbDisplayStateChanged()));
	m_pcbSend = new QCheckBox(trUtf8("Hex发送"), this);

	m_pbSave = new QPushButton(this);
	m_pbSave->setFixedSize(60, 28);
	m_pbSave->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/save.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	m_pbSave->setIcon(QIcon(pix));
	connect(m_pbSave, SIGNAL(clicked()), this, SLOT(pbSaveClicked()));

	m_pbClearRecv = new QPushButton(this);
	m_pbClearRecv->setFixedSize(60, 28);
	m_pbClearRecv->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/clearRec.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	m_pbClearRecv->setIcon(QIcon(pix));
	connect(m_pbClearRecv, SIGNAL(clicked()), this, SLOT(pbClearRecvClicked()));

	m_pbClearSend = new QPushButton(this);
	m_pbClearSend->setFixedSize(60, 28);
	m_pbClearSend->setIconSize(QSize(60, 28));
	pix.load("/opt/PDA/app/images/clearSend.png", 0, Qt::AutoColor);
	pix = pix.scaled(60, 28, Qt::IgnoreAspectRatio);//图片大小
	m_pbClearSend->setIcon(QIcon(pix));

	connect(m_pbClearSend, SIGNAL(clicked()), this, SLOT(pbClearSendClicked()));

	m_pcbAutoSend = new QCheckBox(trUtf8("自动发送"));
	connect(m_pcbAutoSend, SIGNAL(clicked()), this, SLOT(cbAutoSendClicked()));

	m_pleTimeInterval = new QLineEdit();
	m_pleTimeInterval->setMaximumWidth(60);
	m_pleTimeInterval->setText("1000");
	m_pleTimeInterval->setMinimumWidth(40);

	QRegExp rx("-?\\d{0,9}");
	QRegExpValidator *exp = new QRegExpValidator(rx, this);
	m_pleTimeInterval->setValidator(exp);
	QLabel *lbInterval = new QLabel(trUtf8("ms"));

	QHBoxLayout *sendLayout = new QHBoxLayout;
	////////////
	sendLayout->addSpacing(22);

	sendLayout->addWidget(m_pcbDisplay);
	sendLayout->addWidget(m_pcbSend);

	sendLayout->addWidget(m_pcbAutoSend);
	sendLayout->addWidget(m_pleTimeInterval);

	sendLayout->addWidget(lbInterval);
	sendLayout->addWidget(m_pbSave);
	sendLayout->addWidget(m_pbClearRecv);
	sendLayout->addWidget(m_pbClearSend);
	sendLayout->addSpacing(7);
	/////////////////
	QVBoxLayout *centralLayout = new QVBoxLayout;
	//	centralLayout->addWidget(m_pcbDisplay);
	centralLayout->addLayout(pteLayout);
	centralLayout->addLayout(sendLayout);
	centralLayout->addLayout(leLayout);
	centralLayout->addLayout(controlsLayout);
	centralLayout->addWidget(m_pBar);
	centralLayout->setMargin(1);

	this->setLayout(centralLayout);

	m_pCom = new Posix_QextSerialPort("/dev/ttySAC1",QextSerialBase::Polling);

	QTimer::singleShot(100, this, SLOT(initCom()));
	m_pteDisplay->clear();
	connect(m_pTimer, SIGNAL(timeout()), this, SLOT(ShowComMsg()));

	if (bKeyShow)
	{
		m_pbKey->setEnabled(1);
		connect(m_pbKey, SIGNAL(clicked()), this, SLOT(pbKeyShowHide()));

#ifdef ARM
		im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(false);
#endif
	}

}

ComDebugger::~ComDebugger()
{
	m_pTimer->stop();
	delete m_pTimer;

	delete m_pAutoSend;

	m_pCom->close();
	delete m_pCom;
}
void ComDebugger::initCom()
{
	QFile f("/dev/ttySAC1");
	if (f.exists())
	{
		m_pCom = new Posix_QextSerialPort("/dev/ttySAC1",
				QextSerialBase::Polling);
		if (m_pCom->open(QIODevice::ReadWrite))//ttySAC1
		{
			m_pCom->setBaudRate(BAUD115200);
			m_pCom->setDataBits(DATA_8);
			m_pCom->setParity(PAR_NONE);
			m_pCom->setStopBits(STOP_1);
			m_pCom->setFlowControl(FLOW_OFF);
			m_pCom->setTimeout(10);
			m_plbComStatus->setText(trUtf8("ttySAC1 已打开 115200bps 8"));
			m_pTimer->start();
		}
		else
		{
			QMessageBox::warning(this, trUtf8("提示"), trUtf8("串口打开失败！"),
					QMessageBox::Ok);
		}
	}
	else
	{
//		sendLayout->addSpacing(7);
		QMessageBox::warning(this, trUtf8("提示"), trUtf8("串口不存在！"),
				QMessageBox::Ok);
	}
}
void ComDebugger::cbAutoSendClicked()
{
	if (m_pcbAutoSend->isChecked())
	{
		if (m_pleTimeInterval->text() != "")
		{
			m_pAutoSend->start(m_pleTimeInterval->text().toInt());
		}
	}
	else
		m_pAutoSend->stop();
}

//串口设置
void ComDebugger::pbSetClicked()
{
	//	((TQInputMethod*) im)->setVisible(false);

	m_pTimer->stop();
	uiSetComPara *para = new uiSetComPara();
	para->setWindowModality(Qt::WindowModal);
	para->exec();
	m_pTimer->start();
}
void ComDebugger::pbSelectClicked()
{
	QFileDialog *fd = new QFileDialog();
	fd->setGeometry(0, 0, m_iWidth, m_iHeight);
	fd->setWindowTitle(tr("Open File"));
	fd->setDirectory(m_strRootDir);
	fd->setFilter("AllFiles (*)");

	QString strImagePath = "";

	if (fd->exec() == QDialog::Accepted)
	//	fd->show();
	//	if(1)
	{
		strImagePath = fd->selectedFiles()[0];
		m_strRootDir = strImagePath.mid(0, strImagePath.lastIndexOf('/'));

		unsigned char cData[2000];
		int iReadLen = 0;

		QFile f(strImagePath);
		if (f.open(QIODevice::ReadOnly))
		{
			QString str = "";
			while ((iReadLen = f.read((char *) cData, sizeof(cData))) > 0)
			{

				m_leSend->setText(QString((char *) cData));

				//				int iSendLen = 0;
				//				while (true)
				//				{
				//					if (iSendLen + 256 < iReadLen)
				//					{
				//						m_pCom->write((char *) &cData[iSendLen], 256);
				//						iSendLen += 256;
				//						m_iSendCount++;
				//						str = "S:" + QString::number(m_iSendCount);
				//						m_leSend->setText(str);
				//					}
				//					else
				//					{
				//						m_pCom->write((char *) &cData[iSendLen],
				//								iReadLen - iSendLen);
				//						m_iSendCount++;
				//						str = "S:" + QString::number(m_iSendCount);
				//						m_leSend->setText(str);
				//						break;
				//					}
				//				}
			}
		}
	}
	delete fd;
}
//回车发送数据
void ComDebugger::teTextChanged()
{
	QString str;
	if (str.toUtf8().length() > 0 && str.endsWith('\n'))
	{
		if (m_pcbSend->isChecked())
		{
			char cData[2048];
			int iCount = str2Hex((unsigned char *) str.toStdString().c_str(),
					(unsigned char *) cData, str.toUtf8().length());
			m_pCom->write(cData, iCount);
		}
		else
		{
			m_pCom->write(str.toStdString().c_str(), str.toUtf8().length());
		}
		m_iSendCount++;
		str = "S:" + QString::number(m_iSendCount);
	}
}
//显示框输入回车
void ComDebugger::teDisplayTextChanged(QString str)
{
	m_pCom->write(str.toStdString().c_str(), str.toUtf8().length());
}
//发送
void ComDebugger::pbSendClicked()
{
	QString str = m_leSend->toPlainText();
	if (m_pcbSend->isChecked())
	{
		char cData[2048];
		str = str.remove(' ');
		int iCount = str2Hex((unsigned char *) str.toLocal8Bit().data(),
				(unsigned char *) cData, str.toUtf8().length());
		m_pCom->write(cData, iCount);
	}
	else
	{
		m_pCom->write(str.toUtf8().data(), str.toUtf8().length());
	}
	m_iSendCount++;
	str = "S:" + QString::number(m_iSendCount);
	m_plbSend->setText(str);
}

void ComDebugger::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
//显示串口信息
void ComDebugger::ShowComMsg()
{
	if (m_pCom->isOpen())
	{
		memset(cData, 0, sizeof(cData));
		int iLen = m_pCom->read(cData, sizeof(cData));
		if (iLen > 0)
		{
			if (m_pteDisplay->toPlainText().length() > 2000)
				m_pteDisplay->clear();

			if (m_pcbDisplay->isChecked())
			{
				char cTemp[6000];
				ByteToStr((const unsigned char*) cData, cTemp, iLen);
				m_pteDisplay->setText(
						m_pteDisplay->toPlainText() + QString(cTemp).mid(0,
								iLen * 3));
			}
			else
			{
				m_pteDisplay->setText(
						m_pteDisplay->toPlainText() + trUtf8(cData));
			}

			QTextCursor cursor = m_pteDisplay->textCursor();
			cursor.movePosition(QTextCursor::End);
			m_pteDisplay->setTextCursor(cursor);

			m_iRecvCount++;
			QString str = "R:" + QString::number(m_iRecvCount);
			m_plbRecv->setText(str);
		}
	}
}
//hex显示
void ComDebugger::cbDisplayStateChanged()
{
	m_pAutoSend->stop();

	if (!m_pcbDisplay->isChecked())
	{
		QString str = m_pteDisplay->toPlainText();
		str = str.remove(' ');
		char cData[str.toUtf8().length()];
		int iCount = str2Hex((unsigned char *) str.toUtf8().data(),
				(unsigned char *) cData, str.toUtf8().length());
		m_pteDisplay->clear();
		m_pteDisplay->setPlainText(
				trUtf8(QString(cData).mid(0, iCount).toStdString().c_str()));
	}
	else
	{
		//hex 显示
		QString str = m_pteDisplay->toPlainText();
		char cTemp[str.toUtf8().length() * 3];
		ByteToStr((const unsigned char*) str.toUtf8().data(), cTemp,
				str.toUtf8().length());
		m_pteDisplay->clear();
		m_pteDisplay->append(QString(cTemp).mid(0, str.toUtf8().length() * 3));
	}
	if (m_pcbAutoSend->isChecked())
		m_pAutoSend->start(m_pleTimeInterval->text().toInt());
}
void ComDebugger::pbSaveClicked()
{
	QFileDialog *fd = new QFileDialog();
	fd->setGeometry(0, 0, m_iWidth, m_iHeight);
	fd->setWindowTitle(tr("Open File"));
	fd->setDirectory(m_strRootDir);
	fd->setFilter("AllFiles (*)");

	QString strImagePath = "";
	fd->setWindowModality(Qt::WindowModal);
	if (fd->exec() == QDialog::Accepted)
	{
		strImagePath = fd->selectedFiles()[0];
		m_strRootDir = strImagePath.mid(0, strImagePath.lastIndexOf('/'));

		//		QFile f(QString::fromLocal8Bit(strImagePath.toStdString().c_str()));
		QFile f(strImagePath.toUtf8().data());

		bool bOk = true;
		if (f.exists())
		{
			QMessageBox box;
			((TQInputMethod *) im)->setVisible(false);
			box.addButton(new QPushButton(trUtf8("确认")), QMessageBox::YesRole);
			box.addButton(new QPushButton(trUtf8("取消")), QMessageBox::NoRole);
			box.setWindowTitle(trUtf8("确认"));
			box.setText(trUtf8("文件已存在，是否覆盖?"));
			bOk = box.exec() == 0 ? true : false;
		}
		if (bOk)
		{
			if (f.open(QIODevice::ReadWrite))
			{
				f.resize(0);
				//					f.write(fw->GetContent().toLatin1());
				f.write(m_pteDisplay->toPlainText().toUtf8().data());

				f.close();
			}
			else
			{
				QMessageBox::warning(this, trUtf8("警告"), trUtf8("保存失败！"),
						QMessageBox::Ok);
			}
		}

	}
	delete fd;
}
void ComDebugger::pbKeyShowHide()
{
	((TQInputMethod *) im)->setVisible(true);
}
//清空接收区
void ComDebugger::pbClearRecvClicked()
{
	m_pteDisplay->clear();
}
//清空发区
void ComDebugger::pbClearSendClicked()
{
	m_leSend->clear();
}
//清空计数器
void ComDebugger::pbClearCountClicked()
{
	m_iRecvCount = 0;
	m_iSendCount = 0;
	m_plbRecv->setText("R:0");
	m_plbSend->setText("S:0");
}
//设置串口信息
void ComDebugger::SetComStatus(QString str)
{
	m_plbComStatus->setText(trUtf8(str.toStdString().c_str()));
}
//字符转Hex
int ComDebugger::str2Hex(unsigned char *buf, unsigned char *hex, int sLen)
{
	unsigned char tHex = 0x00;
	unsigned char *tBuf = (unsigned char *) malloc(sizeof(unsigned char) * 8);
	memset(tBuf, '\0', 8);
	int i = 0;
	for (i = 0; i < sLen; i += 2)
	{
		memcpy(tBuf, &buf[i], 2);
		tHex = (unsigned char) strtol((char *) tBuf, NULL, 16);
		hex[i / 2] = tHex;
	}
	return sLen / 2;
}
char *ComDebugger::ByteToStr(const unsigned char *pIn, char *pOut, int len)
{
	char *pstr = pOut;
	unsigned char *p = (unsigned char *) pIn;

	int i = 0;
	for (i = 0; i < len; i++, pstr += 3)
		sprintf(pstr, "%02x ", *p++);

	return pOut;
}
