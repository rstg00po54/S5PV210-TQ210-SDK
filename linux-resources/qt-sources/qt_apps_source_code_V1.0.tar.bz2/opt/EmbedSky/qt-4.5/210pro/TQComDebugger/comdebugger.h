#ifndef COMDEBUGGER_H
#define COMDEBUGGER_H

#include <QtGui/QWidget>
#include <QTimer>
#include <QKeyEvent>
#include "src/armapi/posix_qextserialport.h"
#include "src/widget/MyTextEdit.h"
#include <QStatusBar>
#include <QCheckBox>
#include <QLabel>
#include <QLineEdit>
#include <qprocess.h>
#include <QPushButton>

#include "TQInputMethod.h"
#ifdef ARM
#include <QWSInputMethod>
#endif

class ComDebugger: public QWidget
{
	Q_OBJECT

public:
	ComDebugger(QWidget *parent = 0, bool bKeyShow = 0);
	~ComDebugger();
	Posix_QextSerialPort *m_pCom;
	void SetComStatus(QString str);public slots:
	void ShowComMsg();
	void pbSendClicked();
	void pbSetClicked();
	void teTextChanged();
	void teDisplayTextChanged(QString);
	void pbClearRecvClicked();
	void pbClearSendClicked();
	void pbClearCountClicked();
	void cbDisplayStateChanged();
	void pbSelectClicked();
	void cbAutoSendClicked();
	void pbHelpClicked();
	void pbSaveClicked();
	void pbKeyShowHide();
	void initCom();
private:
	QTimer *m_pTimer;//串口读取定时器
	QTextEdit *m_pteDisplay;
	QTextEdit *m_leSend;
	QString m_strDisplayInput;
	QStatusBar *m_pBar;//状态栏
	QCheckBox *m_pcbDisplay;//hex显示
	QCheckBox *m_pcbSend;//hex发送
	QCheckBox *m_pcbAutoSend;//自动发送
	QTimer *m_pAutoSend;
	QPushButton *m_pbHelp;
	QProcess process;

	QLineEdit *m_pleTimeInterval;//自动发送间隔
	QLabel *m_plbUrl;//网站
	QLabel *m_plbRecv;//接收
	QLabel *m_plbSend;//发送
	QLabel *m_plbComStatus;//串口状态
	QPushButton *m_pbClearRecv;//清空接收
	QPushButton *m_pbClearSend;//清空发送
	QPushButton *m_pbClearCount;//清空计数器
	QPushButton *m_pbSelect;//选择文件
	QPushButton *m_pbSet;//设置
	QPushButton *m_pbSend;//发送
	QString m_strRootDir;

	QPushButton *m_pbKey;

	QPushButton *m_pbSave;
	int m_iRecvCount;//接收数据包
	int m_iSendCount;//发送数据包
	int m_iWidth;
	int m_iHeight;

	QWSInputMethod* im;

	bool iShowKey;

	int str2Hex(unsigned char *buf, unsigned char *hex, int sLen);
	char *ByteToStr(const unsigned char *pIn, char *pOut, int len);
};
extern ComDebugger *g_pComDebugger;
#endif // COMDEBUGGER_H
