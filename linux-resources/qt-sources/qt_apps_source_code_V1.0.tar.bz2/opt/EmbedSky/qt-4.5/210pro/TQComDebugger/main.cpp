#include "comdebugger.h"

#include <QtGui>
#include <QApplication>
#include<QFont>
#include "comdebugger.h"
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	QTextCodec *codec = QTextCodec::codecForName("UTF-8");
	QTextCodec::setCodecForLocale(codec);
	QTextCodec::setCodecForCStrings(codec);
	QTextCodec::setCodecForTr(codec);

	QFont font("wenquanyi",15);

	bool bShowKey=false;

	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "EmbedSky") == 0)
		{
			g_pComDebugger = new ComDebugger(0, 1);
			bShowKey=true;
			break;
		}
	}
	if(!bShowKey)
		g_pComDebugger = new ComDebugger(0, 0);


	g_pComDebugger->setFont(font);
	g_pComDebugger->showFullScreen();
	return a.exec();
}
