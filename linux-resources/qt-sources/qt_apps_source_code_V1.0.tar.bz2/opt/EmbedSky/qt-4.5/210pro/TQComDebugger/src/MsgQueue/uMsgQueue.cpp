#include "uMsgQueue.h"
/*
 *     公司名:    	东莞市建邦计算机软件有限公司
 *     项目名:   		QMsgQueue
 *    文件名:     	uMsgQueue.cpp
 *     文件描述:   消息队列
 *    创建日期:     2009-09-07
 *    创 建 人:      lkp
 *     文档:
 *    运行平台:     linux
 *     其他:             无
 */

QMsgQueue::QMsgQueue()
{
}

QMsgQueue::~QMsgQueue()
{
	m_pTaskList.clear();
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：Clear
 ** 创建日期：2009-09-07
 ** 创 建 人： lkp
 ** 函数功能：发送报文
 ** 参    数：无
 ** 返    回：无
 ** 数 据 库：无
 ** 其它说明：无
 */
void QMsgQueue::Clear()
{
	m_pTaskList.clear();
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：Add
 ** 创建日期：2009-09-07
 ** 创 建 人： lkp
 ** 函数功能：添加数据到list中
 ** 参    数：
 * 					item[in]:待添加数据
 ** 返    回：无
 ** 数 据 库：无
 ** 其它说明：无
 */
void QMsgQueue::Add(RecvMsg *item)
{
	mutex.lock();
	m_pTaskList.append(item);
	mutex.unlock();
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：GetFirst
 ** 创建日期：2009-09-07
 ** 创 建 人： lkp
 ** 函数功能：添加数据到list中
 ** 参    数：
 * 					bRemove[in]:是否删除数据
 ** 返    回：第一条数据
 ** 数 据 库：无
 ** 其它说明：无
 */
RecvMsg *QMsgQueue::GetFirst(bool bRemove)
{
	mutex.lock();
	RecvMsg *p = NULL;
	if (m_pTaskList.count() > 0)
	{
		p = m_pTaskList.first();
		if (bRemove)
			m_pTaskList.removeFirst();
	}
	mutex.unlock();
	return p;
}
//---------------------------------------------------------------------------
/*
 ** 函数名称：Delete
 ** 创建日期：2009-09-07
 ** 创 建 人： lkp
 ** 函数功能：删除第一条数据
 ** 参    数：无
 ** 返    回：无
 ** 数 据 库：无
 ** 其它说明：无
 */
void QMsgQueue::Delete()
{
	mutex.lock();
	if (m_pTaskList.count() > 0)
		m_pTaskList.removeFirst();
	mutex.unlock();
}

