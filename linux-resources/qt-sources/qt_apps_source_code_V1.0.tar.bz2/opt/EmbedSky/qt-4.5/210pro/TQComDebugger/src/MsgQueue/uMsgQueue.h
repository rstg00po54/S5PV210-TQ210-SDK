#ifndef UMSGQUEUE_H_
#define UMSGQUEUE_H_
#include <QList>
#include <QMutex>
#include <string.h>
struct RecvMsg
{
	unsigned char _bBuf[2048];//接收到的的数据
	int _iMsgLen;//数据长度
	RecvMsg()
	{
		memset(_bBuf, 0, 2048);
		_iMsgLen = 0;
	}
};
class QMsgQueue // 任务消息队列类
{
public:
	QMsgQueue();
	~QMsgQueue();

	void Clear();
	void Add(RecvMsg *item);
	void Delete();
	int GetCount();
	RecvMsg *GetFirst(bool);
	RecvMsg *Search(int, bool);
protected:

private:
	QList<RecvMsg *> m_pTaskList;
	QMutex mutex;
};

#endif /*UMSGQUEUE_H_*/
