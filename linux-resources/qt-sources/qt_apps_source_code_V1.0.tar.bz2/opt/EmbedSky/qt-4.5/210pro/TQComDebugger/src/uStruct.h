#ifndef USTRUCT_H_
#define USTRUCT_H_
#include <string.h>

typedef unsigned char BYTE;
const int MAXBUF = 2048;//报文最大长度
//消费记录数据
struct RecordMsg
{
	BYTE _bBuf[500];
	int _iMsgLen;
	int _iRecordSize;
	RecordMsg()
	{
		memset(_bBuf, 0, 500);
		_iMsgLen = 0;
		_iRecordSize = 0;
	}
};
struct MergedMsg
{
	BYTE _bBuf[1500];
	int _iMsgLen;
	MergedMsg()
	{
		memset(_bBuf, 0, 1500);
		_iMsgLen = 0;
	}
};
//待发送数据
struct SendMsg
{
	BYTE _bBuf[1500];//要发送的数据
	BYTE _bAddress[2];//终端地址
	int _iMsgLen;//数据长度
	SendMsg()
	{
		memset(_bBuf, 0, 1500);
		memset(_bAddress, 0, 2);
		_iMsgLen = 0;
	}
};
#endif /*USTRUCT_H_*/
