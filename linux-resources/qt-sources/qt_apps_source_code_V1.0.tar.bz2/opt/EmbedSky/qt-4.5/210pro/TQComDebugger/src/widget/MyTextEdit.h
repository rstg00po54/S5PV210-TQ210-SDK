/*
 * MyTextEdit.h
 *
 *  Created on: 2011-4-12
 *      Author: lkp
 */

#ifndef MYTEXTEDIT_H_
#define MYTEXTEDIT_H_
#include <QTextEdit>
#include <QtGui/QWidget>
#include <QKeyEvent>
class MyTextEdit : public QTextEdit
{
Q_OBJECT
public:
	MyTextEdit(QWidget *parent=0);
	virtual ~MyTextEdit();
	QString m;
	void keyPressEvent( QKeyEvent * event);
private:
	QString m_strInput;
signals:
	void EnterPressed(QString str);
};

#endif /* MYTEXTEDIT_H_ */
