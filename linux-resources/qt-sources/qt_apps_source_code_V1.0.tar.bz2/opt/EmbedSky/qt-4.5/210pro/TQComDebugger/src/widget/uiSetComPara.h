#ifndef UISETCOMPARA_H
#define UISETCOMPARA_H

#include <QtGui/QDialog>
#include "ui_uiSetComPara.h"

class uiSetComPara : public QDialog
{
    Q_OBJECT

public:
    uiSetComPara(QWidget *parent = 0);
    ~uiSetComPara();
public slots:
	void pbCancelClicked();
	void pbConfirmClicked();

private:
    Ui::uiSetComParaClass ui;
};

#endif // UISETCOMPARA_H
