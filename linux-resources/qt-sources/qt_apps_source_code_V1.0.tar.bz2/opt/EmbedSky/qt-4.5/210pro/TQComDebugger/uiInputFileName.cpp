#include "uiInputFileName.h"
#include <QLabel>
#include <qlayout.h>
QInputFileName::QInputFileName(QWidget *parent) :
	QDialog(parent)
{
	setWindowTitle(trUtf8("请输入文件名"));
	setGeometry(100, 150, 300, 100);
	QLabel *lb = new QLabel(trUtf8("文件名："));

	m_pLeFileName = new QLineEdit(this);

	m_pCancel = new QPushButton(trUtf8("取消"));
	m_pConfirm = new QPushButton(trUtf8("确认"));

	m_pCancel->setMaximumWidth(60);
	m_pConfirm->setMaximumWidth(60);

	QHBoxLayout *nameLayout = new QHBoxLayout;
	nameLayout->addWidget(lb);
	nameLayout->addWidget(m_pLeFileName);

	QHBoxLayout *btnLayout = new QHBoxLayout;
	btnLayout->addWidget(m_pCancel);
	btnLayout->addWidget(m_pConfirm);

	QVBoxLayout *layout = new QVBoxLayout;
	layout->addLayout(nameLayout);
	layout->addLayout(btnLayout);

	setLayout(layout);
	connect(m_pCancel, SIGNAL(clicked()), this, SLOT(pbCancelClicked()));
	connect(m_pConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));
}

QInputFileName::~QInputFileName()
{

}

void QInputFileName::pbCancelClicked()
{
	done(-1);
}
void QInputFileName::pbConfirmClicked()
{
	QString str = m_pLeFileName->text();
	str = str.remove(' ');
	str = str.remove('\r');
	str = str.remove('\n');
	if (str != "")
		done(0);
}
QString QInputFileName::getText()
{
	return m_pLeFileName->text();
}
