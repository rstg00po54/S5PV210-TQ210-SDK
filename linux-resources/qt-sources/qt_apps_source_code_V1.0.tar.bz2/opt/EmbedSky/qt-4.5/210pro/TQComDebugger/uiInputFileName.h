#ifndef UIINPUTFILENAME_H
#define UIINPUTFILENAME_H

#include <QtGui/QDialog>
#include <QPushButton>
#include<QLineEdit>

class QInputFileName: public QDialog
{
Q_OBJECT

public:
	QInputFileName(QWidget *parent = 0);
	~QInputFileName();
	QString getText();
private:
	QLineEdit *m_pLeFileName;
	QPushButton *m_pCancel;
	QPushButton *m_pConfirm;
public slots:
	void pbCancelClicked();
	void pbConfirmClicked();
};

#endif // UIINPUTFILENAME_H
