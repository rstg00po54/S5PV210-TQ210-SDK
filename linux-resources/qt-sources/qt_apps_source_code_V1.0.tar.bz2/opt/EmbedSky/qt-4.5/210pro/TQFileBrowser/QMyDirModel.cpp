/*
 * QMyDirModel.cpp
 *
 *  Created on: May 7, 2011
 *      Author: root
 */

#include "QMyDirModel.h"

QMyDirModel::QMyDirModel():QDirModel()
{
	// TODO Auto-generated constructor stub

}

QMyDirModel::~QMyDirModel()
{
	// TODO Auto-generated destructor stub
}
QVariant QMyDirModel::headerData(int section, Qt::Orientation orientation, int role) const
    {
        if (orientation == Qt::Horizontal) {
            if (role != Qt::DisplayRole)
                return QVariant();
            switch (section) {
            case 0: return tr("名字");
            case 1: return tr("大小");
            case 2: return tr("类型");
    #ifdef Q_OS_MAC
                           tr("Kind", "Match OS X Finder");
    #else
                           tr("Type", "All other platforms");
    #endif
            // Windows   - Type
            // OS X      - Kind
            // Konqueror - File Type
            // Nautilus  - Type
            case 3: return tr("修改时间");
            default: return QVariant();
            }
        }
        return QAbstractItemModel::headerData(section, orientation, role);
    }
