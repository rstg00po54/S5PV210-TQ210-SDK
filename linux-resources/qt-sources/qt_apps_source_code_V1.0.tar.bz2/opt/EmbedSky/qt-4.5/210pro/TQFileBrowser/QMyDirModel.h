/*
 * QMyDirModel.h
 *
 *  Created on: May 7, 2011
 *      Author: root
 */

#ifndef QMYDIRMODEL_H_
#define QMYDIRMODEL_H_
#include<QDirModel>
class QMyDirModel: public QDirModel
{
public:
	QMyDirModel();
	virtual ~QMyDirModel();

	QVariant
			headerData(int section, Qt::Orientation orientation, int role) const;

};

#endif /* QMYDIRMODEL_H_ */
