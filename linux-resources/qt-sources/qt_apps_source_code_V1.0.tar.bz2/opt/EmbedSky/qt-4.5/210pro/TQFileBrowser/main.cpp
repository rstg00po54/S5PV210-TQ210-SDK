#include "usb_tree.h"
#include <usbwidget.h>
#include <QtGui>
#include <QApplication>

#include <stdio.h>
//#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
//#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <errno.h>

#include <qfont.h>
#include <qtooltip.h>

#include <linux/fb.h>
#include <iostream>

#include<QApplication>
#include<QDesktopWidget>

//#include<QFont>
//#include<QTextCodec>

static int usb_fd;
static int sd_fd;

static int usb_exist, sd_exist;
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));

	/*	QFont font;
	 font.setPointSize(12);
	 font.setFamily(("wenquanyi"));
	 a.setFont(font);*/

	usb_fd = open("/dev/sda", 0);
	if (usb_fd < 0)
	{
		//		perror("open usb device fails");
	}
	else
		usb_exist = 1;

	sd_fd = open("/dev/mmcblk0p1", 0);
	if (sd_fd < 0)
	{
		//		perror("open sd device fails");
	}
	else
		sd_exist = 1;

	QString string_path;
	if ((usb_exist == 1) && (sd_exist == 0))
		string_path = "/udisk";
	else if ((usb_exist == 0) && (sd_exist == 1))
		string_path = "/sd";
	else
		string_path = "/";

	usb_tree *w;
	bool bShowKey = false;
	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "EmbedSky") == 0)
		{
			w = new usb_tree(0, string_path, 1);
			bShowKey = true;
			break;
		}
	}
	if (!bShowKey)
		w = new usb_tree(0, string_path, 0);
	w->setWindowTitle("文件管理");

	QRect screen_size = QApplication::desktop()->screenGeometry();
	w->setGeometry(0, 0, screen_size.width(), screen_size.height());
	w->show();

	return a.exec();
}
