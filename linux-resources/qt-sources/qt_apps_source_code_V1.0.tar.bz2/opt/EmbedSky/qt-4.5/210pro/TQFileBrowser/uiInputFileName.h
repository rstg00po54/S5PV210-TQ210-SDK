#ifndef UIINPUTFILENAME_H
#define UIINPUTFILENAME_H

#include <QtGui/QDialog>
#include <QLineEdit>
#include <QPushButton>

class QInputFileName: public QWidget
{
Q_OBJECT

public:
	QInputFileName(QWidget *parent = 0);
	~QInputFileName();
	QString getText();
	QLineEdit *m_pLeFileName;
private:

	QPushButton *m_pCancel;
	QPushButton *m_pConfirm;

	signals:
	void ConfirmSignal();

public slots:
	void pbCancelClicked();
	void pbConfirmClicked();
};
#endif // UIINPUTFILENAME_H
