#include "usb_tree.h"
#include <QtGui>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <iostream>
#include<QProcess>
#include<QMessageBox>
#include <QFont>
#include"uiInputFileName.h"
#include<QTimer>
#include<QPixmap>
#include<QPalette>
using namespace std;
int m_dir_file;//要复制的是文件夹，该变量为1，负责为0
int m_cutFlag;//m_cutFlag==1表示按下了剪切键
usb_tree::usb_tree(QWidget *parent, QString string, bool bKeyShow) :
	QWidget(parent)
{
	ui.setupUi(this);

	m_bCopyCut = true;

	ifn = new QInputFileName();
	connect(ifn, SIGNAL(ConfirmSignal()), this, SLOT(ConfirmSlot()));

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	this->setPalette(palette);

	m_pbKey = new QPushButton(this);
	m_pbKey->setFixedSize(80, 27);
	m_pbKey->setIconSize(QSize(80, 27));
	QPixmap pix("/opt/PDA/app/images/key.png", 0, Qt::AutoColor);
	pix = pix.scaled(80, 27, Qt::IgnoreAspectRatio);//图片大小
	m_pbKey->setIcon(QIcon(pix));

	m_pbHelp = new QPushButton(this);
	m_pbHelp->setFixedSize(80, 27);
	m_pbHelp->setIconSize(QSize(80, 27));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(80, 27, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	QPushButton *pb_mkdir = new QPushButton(this);//创建新建按钮
	pb_mkdir->setFixedSize(80, 27);
	pb_mkdir->setIconSize(QSize(80, 27));
	pix.load("/opt/PDA/app/images/creator.png", 0, Qt::AutoColor);
	pix = pix.scaled(80, 27, Qt::IgnoreAspectRatio);//图片大小
	pb_mkdir->setIcon(QIcon(pix));

	QPushButton *pb_copy = new QPushButton(this);//创建复制按钮
	pb_copy->setFixedSize(80, 27);
	pb_copy->setIconSize(QSize(80, 27));
	pix.load("/opt/PDA/app/images/copy.png", 0, Qt::AutoColor);
	pix = pix.scaled(80, 27, Qt::IgnoreAspectRatio);//图片大小
	pb_copy->setIcon(QIcon(pix));

	pb_paste = new QPushButton(this);//创建复制按钮
	pb_paste->setFixedSize(80, 27);
	pb_paste->setIconSize(QSize(80, 27));
	pix.load("/opt/PDA/app/images/paste.png", 0, Qt::AutoColor);
	pix = pix.scaled(80, 27, Qt::IgnoreAspectRatio);//图片大小
	pb_paste->setIcon(QIcon(pix));
	pb_paste->setEnabled(0);

	QPushButton *pb_delete = new QPushButton(this);//创建删除按钮
	pb_delete->setFixedSize(80, 27);
	pb_delete->setIconSize(QSize(80, 27));
	pix.load("/opt/PDA/app/images/delete.png", 0, Qt::AutoColor);
	pix = pix.scaled(80, 27, Qt::IgnoreAspectRatio);//图片大小
	pb_delete->setIcon(QIcon(pix));

	QPushButton *pb_cut = new QPushButton(this);//创建剪贴按钮
	pb_cut->setFixedSize(80, 27);
	pb_cut->setIconSize(QSize(80, 27));
	pix.load("/opt/PDA/app/images/cut.png", 0, Qt::AutoColor);
	pix = pix.scaled(80, 27, Qt::IgnoreAspectRatio);//图片大小
	pb_cut->setIcon(QIcon(pix));

	QPushButton *pb_exit = new QPushButton(this);//创建剪贴按钮
	pb_exit->setFixedSize(80, 27);
	pb_exit->setIconSize(QSize(80, 27));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(80, 27, Qt::IgnoreAspectRatio);//图片大小
	pb_exit->setIcon(QIcon(pix));

	QHBoxLayout *hOperLayout1 = new QHBoxLayout;//水平layout用来放置新建、删除复制，粘贴、剪贴等按钮
	hOperLayout1->addStretch(22);
	hOperLayout1->addWidget(m_pbHelp);
	hOperLayout1->addWidget(pb_copy);
	hOperLayout1->addWidget(pb_paste);
	hOperLayout1->addWidget(pb_exit);
	hOperLayout1->addStretch(22);

	QHBoxLayout *hOperLayout2 = new QHBoxLayout;//水平layout用来放置新建、删除复制，粘贴、剪贴等按钮
	hOperLayout2->addStretch(22);
	hOperLayout2->addWidget(m_pbKey);
	hOperLayout2->addWidget(pb_mkdir); //layout添加新建按钮
	hOperLayout2->addWidget(pb_delete);
	hOperLayout2->addWidget(pb_cut);
	hOperLayout2->addStretch(22);

	connect(pb_delete, SIGNAL(clicked()), this, SLOT(pbDeleteClicked()));
	connect(pb_mkdir, SIGNAL(clicked()), this, SLOT(pbMkdirClicked()));
	connect(pb_copy, SIGNAL(clicked()), this, SLOT(pbCopyClicked()));
	connect(pb_paste, SIGNAL(clicked()), this, SLOT(pbPasteClicked()));
	connect(pb_cut, SIGNAL(clicked()), this, SLOT(pbCutClicked()));
	connect(pb_exit, SIGNAL(clicked()), this, SLOT(pbExitClicked()));

	model = new QMyDirModel;//创建QDirMode的一个对象
	model->setReadOnly(false);//对象可以修改
	model->setSorting(QDir::DirsFirst | QDir::IgnoreCase | QDir::Name);//排序原则：文件夹优先、忽略大小写、根据名字排序

	treeView = new QTreeView;//创建QTreeView实例

	index = model->index(string);//获取当前exe文件运行等路径位置，并显示当前路径
	QVBoxLayout *vLayout = new QVBoxLayout;//垂直layout
	vLayout->addLayout(hOperLayout1);
	vLayout->addLayout(hOperLayout2); //垂直layout添加水平layout
	vLayout->addWidget(treeView); //垂直leyout添加treeView

	this->setLayout(vLayout); //设置垂直layout为主layout

	m_pbKey->setEnabled(0);
	if (bKeyShow)
	{
		m_pbKey->setEnabled(1);
		connect(m_pbKey, SIGNAL(clicked()), this, SLOT(pbKeyShowHide()));

#ifdef ARM
		im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(false);
#endif
	}
}
usb_tree::~usb_tree()
{
	delete model;//声明model对象
	delete treeView;//声明QTreeView对象
	delete pb_paste;
	delete m_pbHelp;
}
void usb_tree::show()
{
	QWidget::show();
	QTimer::singleShot(100, this, SLOT(init()));
}
void usb_tree::init()
{
	treeView->setModel(model);//把model设为treeView实例
	treeView->header()->setStretchLastSection(true);//最后一列自动改变宽度以适应整个treeView的宽度
	treeView->header()->setSortIndicator(0, Qt::AscendingOrder);//设置按照那一列进行排序，第0列，即名字排序
	treeView->header()->setSortIndicatorShown(true);//显示列头上面的排序小箭头
	treeView->header()->setClickable(true);//允许点击列头

	treeView->expand(index);//展开这一路径
	treeView->scrollTo(index);//把试图等视口滚动到这个路径的位置
	treeView->resizeColumnToContents(0);//列头适应内容宽度
}
/*作用：删除文件或者文件夹
 * 参数：无
 * 时间：2011.4.21
 * 作者：郭
 * */
void usb_tree::pbExitClicked()
{
	close();
}
void usb_tree::pbDeleteClicked()
{
	QModelIndex index = treeView->currentIndex();//获取当前index
	QString str = model->filePath(index);
	if (!index.isValid())
	{ //默认是没有目录选择的，当前目录是非法的，为了避免异常，要有这个判断
		return;
	}

	QMessageBox msgBox;
	msgBox.setWindowTitle("警告");
	msgBox.setText("确定删除？");
	msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
	msgBox.setDefaultButton(QMessageBox::Yes);
	int ret = msgBox.exec();
	switch (ret)
	{
	case QMessageBox::Yes:
	{
		if (!system(("rm -rf " + str).toLocal8Bit().data())) //如果是文件，删除文件
		{
			QMessageBox::warning(this, trUtf8("提示"),
					trUtf8("删除成功"), QMessageBox::Ok);
			QModelIndex index_refresh = model->index("/");//设置index为home目录
			model->refresh(index_refresh);//刷新home下所有文件
			return;
		}
	}
	case QMessageBox::No:
	{
		return;
	}
	}

}
/*作用：创建文件夹
 * 参数：无
 * 时间：2011.4.21
 * 作者：gxx
 * */
void usb_tree::pbMkdirClicked()
{
	ifn->show();
}
void usb_tree::ConfirmSlot()
{
	QString str = ifn->getText();
	ifn->m_pLeFileName->clear();
	ifn->close();
	//	((TQInputMethod *) im)->setVisible(false);

	QModelIndex index = treeView->currentIndex();//获取当前index
	if (!index.isValid())
	{ //默认是没有目录选择的，当前目录是非法的，为了避免异常，要有这个判断
		return;
	}

	if (!model->mkdir(index, str).isValid())
	{ //创建文件夹，并判断，如果创建失败，提示失败
		QMessageBox::information(this, tr("Create Directory"),
				tr("Failed to create the directory"));
	}
	else
	{
		QMessageBox warn;
		warn.setWindowTitle(trUtf8("       提示    "));
		warn.setText(trUtf8("创建成功！"));
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0,
				Qt::AutoColor);
		QIcon icon(pix);
		warn .setWindowIcon(icon);
		warn.exec();
	}
}
void usb_tree::pbCopyClicked()//复制
{
	pb_paste->setEnabled(1);
	QModelIndex index = treeView->currentIndex();//获取当前index

	QString str = model->filePath(index);
	m_strCopyFrom = str;
	m_strCopyFrom_copy=m_strCopyFrom;
	m_bCopyCut = true;
}
void usb_tree::pbCutClicked()
{
	pb_paste->setEnabled(1);
	QModelIndex index = treeView->currentIndex();//获取当前index

	QString str = model->filePath(index);
	m_strCutFrom = str;
	m_bCopyCut = false;
}
void usb_tree::pbPasteClicked()//粘贴文件
{
	m_strCopyFrom=m_strCopyFrom_copy;
	QModelIndex index = treeView->currentIndex();//获取当前index
	QModelIndex index_parent = model->index(model->fileInfo(index).path(),
			0);//获取父文件夹等index
	if (!model->fileInfo(index).isDir()) //如果粘贴时点击的是文件
	{
		index = index_parent;
	}

	QString strPast = model->filePath(index);
	if (m_bCopyCut == true)
	{
		QString strCmd = "cp -rf " + m_strCopyFrom + " " + strPast;

		QString strCopyName = m_strCopyFrom.mid(0,
				m_strCopyFrom.lastIndexOf('/'));

		if (strCopyName.compare(strPast) == 0)
		{
			QMessageBox::warning(this, trUtf8("提示"),
					trUtf8("已存在同样文件"), QMessageBox::Ok);
			return;
		}

		strCopyName = m_strCopyFrom.remove(strCopyName).remove("/");

		QFile file(strPast + "/" + strCopyName);
		if (file.exists())
		{
			QMessageBox msgBox;
			msgBox.setWindowTitle("提示");
			msgBox.setText("此文件夹以包含该文件");
			msgBox.setInformativeText("是否替换？");
			msgBox.setStandardButtons(
					QMessageBox::Yes | QMessageBox::No);
			msgBox.setDefaultButton(QMessageBox::Yes);
			int ret = msgBox.exec();
			switch (ret)
			{
			case QMessageBox::Yes:
			{
				if (!system(strCmd.toLocal8Bit().data()))
				{
					QMessageBox::warning(this,
							trUtf8("提示"),
							trUtf8("复制粘贴成功"),
							QMessageBox::Ok);
					QModelIndex index_refresh =
							model->index("/");//设置index为home目录
					model->refresh(index_refresh);//刷新home下所有文件
					return;
				}
				else
				{
					QMessageBox::warning(this,
							trUtf8("提示"),
							trUtf8("复制粘贴失败"),
							QMessageBox::Ok);
					return;
				}
			}
				break;
			case QMessageBox::No:
				return;
				break;
			default:
				break;
			}
		}
		else
		{

			if (!system(strCmd.toLocal8Bit().data()))
			{
				QMessageBox::warning(this, trUtf8("提示"),
						trUtf8("复制粘贴成功"),
						QMessageBox::Ok);
				QModelIndex index_refresh = model->index("/");//设置index为home目录
				model->refresh(index_refresh);//刷新home下所有文件
				return;
			}
			else
			{
				QMessageBox::warning(this, trUtf8("提示"),
						trUtf8("复制粘贴失败"),
						QMessageBox::Ok);
				return;
			}
		}
	}
	else//cut
	{

		QString strCmd = "cp -rf " + m_strCutFrom + " " + strPast;
		QString strCmd2 = "rm -rf " + m_strCutFrom;

		QString strCutName = m_strCutFrom.mid(0,
				m_strCutFrom.lastIndexOf('/'));

		if (strCutName.compare(strPast) == 0)
		{
			QMessageBox::warning(this, trUtf8("提示"),
					trUtf8("已存在同样文件"),
					QMessageBox::Ok);
			return;
		}

		strCutName = m_strCutFrom.remove(strCutName).remove("/");

		QFile file(strPast + "/" + strCutName);

		if (file.exists())
		{
			QMessageBox msgBox;
			msgBox.setWindowTitle("提示");
			msgBox.setText("此文件夹以包含该文件");
			msgBox.setInformativeText("是否替换？");
			msgBox.setStandardButtons(
					QMessageBox::Yes | QMessageBox::No);
			msgBox.setDefaultButton(QMessageBox::Yes);
			int ret = msgBox.exec();
			switch (ret)
			{
			case QMessageBox::Yes:
			{
				if ((!system(strCmd.toLocal8Bit().data()))
						&& (!system(
								strCmd2.toLocal8Bit().data())))
				{

					QMessageBox::warning(this,
							trUtf8("提示"),
							trUtf8("剪切粘贴成功"),
							QMessageBox::Ok);
					QModelIndex index_refresh =
							model->index("/");//设置index为home目录
					pb_paste->setEnabled(0);
					return;
				}
				else
				{
					QMessageBox::warning(this,
							trUtf8("提示"),
							trUtf8("剪切粘贴失败"),
							QMessageBox::Ok);
					return;
				}
			}
				break;
			case QMessageBox::No:
				return;
				break;
			default:
				break;
			}
		}
		else
		{
			if ((!system(strCmd.toLocal8Bit().data())) && (!system(
					strCmd2.toLocal8Bit().data())))
			{
				QMessageBox::warning(this, trUtf8("提示"),
						trUtf8("剪切粘贴成功"),
						QMessageBox::Ok);
				QModelIndex index_refresh = model->index("/");//设置index为home目录
				model->refresh(index_refresh);//刷新home下所有文件
				pb_paste->setEnabled(0);
				return;
			}
			else
			{
				QMessageBox::warning(this, trUtf8("提示"),
						trUtf8("剪切粘贴失败"),
						QMessageBox::Ok);
				return;
			}
		}

	}
}
void usb_tree::pbKeyShowHide()
{
	((TQInputMethod *) im)->setVisible(true);
}
void usb_tree::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
