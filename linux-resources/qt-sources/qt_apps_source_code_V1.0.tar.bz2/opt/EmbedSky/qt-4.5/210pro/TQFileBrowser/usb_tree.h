#ifndef USB_TREE_H
#define USB_TREE_H

#include <QtGui/QTreeView>
#include "ui_usb_tree.h"
#include <QModelIndex>
#include <QDirModel>
#include <QTreeView>
#include<QtGui>
#include "QMyDirModel.h"
#include <QTimer>
#include <qprocess.h>
#include"uiInputFileName.h"

#include "TQInputMethod.h"
#ifdef ARM
#include <QWSInputMethod>
#endif

class usb_tree: public QWidget
{
	Q_OBJECT

public:
	usb_tree(QWidget *parent = 0, QString string = "",bool bKeyShow=0);
	~usb_tree();
	void show();

private:
	Ui::usb_treeClass ui;
	QMyDirModel *model;//声明model对象
	QTreeView *treeView;//声明QTreeView对象
	QFile m_file; //要粘贴的文件
	QString m_strSrcname;//源文件名
	QModelIndex m_indexCut;//剪切文件时，用来保存index
	QDir m_dirFrom;//复制文件夹的源路径
	QDir m_dirTo;//复制文件夹的目的路径
	QModelIndex m_indexDir;//拷贝文件夹时，用来保存index
	QPushButton *pb_paste;
	QModelIndex m_indexDelete;//用来保存要删除文件或文件夹的index
	QModelIndex index;
	QPushButton *m_pbKey;
	QPushButton *m_pbHelp;
	QProcess process;

	QInputFileName* ifn;
	QWSInputMethod* im;

	////////////
	QString m_strCopyFrom;
	QString m_strCopyFrom_copy;
	QString m_strCopyTo;
	QString m_strCutFrom;
	QString m_strCutTo;
	bool m_bCopyCut;
	/////////////


public slots:
	void pbExitClicked();
	void pbDeleteClicked();//删除信号
	void pbCopyClicked();//复制
	void pbMkdirClicked();//创建文件夹
	void pbPasteClicked();//粘贴
	void pbCutClicked();
	void init();
	void ConfirmSlot();
	void pbHelpClicked();
	void pbKeyShowHide();

};

#endif // USB_TREE_H
