/*
 * usbwidget.cpp
 *
 *  Created on: Apr 20, 2011
 *      Author: root
 */

#include "usbwidget.h"

#include <usb_tree.h>
usbwidget::usbwidget(QWidget *parent):QWidget(parent)
{
  // TODO Auto-generated constructor stub
  this->setGeometry(0,0,400,300);
  usb_tree *usb = new usb_tree();
  usb->show();
}

usbwidget::~usbwidget()
{
  // TODO Auto-generated destructor stub
}
