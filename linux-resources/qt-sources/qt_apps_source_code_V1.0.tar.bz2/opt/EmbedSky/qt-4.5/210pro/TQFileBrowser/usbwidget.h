/*
 * usbwidget.h
 *
 *  Created on: Apr 20, 2011
 *      Author: root
 */

#ifndef USBWIDGET_H_
#define USBWIDGET_H_
#include <QWidget>
class usbwidget : public QWidget
{
  Q_OBJECT
public:
  usbwidget(QWidget *parent=0);
  virtual
  ~usbwidget();
};

#endif /* USBWIDGET_H_ */
