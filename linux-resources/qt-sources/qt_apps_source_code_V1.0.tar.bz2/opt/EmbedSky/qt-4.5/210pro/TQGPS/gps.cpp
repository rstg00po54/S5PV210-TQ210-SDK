/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		gps应用程序
 *    文件名:             gps.cpp
 *    文件描述:  		主界面
 *    创建日期:      2011-07-08
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    数据库：gpsdata.db
 *    其他:             无
 */
#include "gps.h"
#include <QTextCursor>
#include <QVBoxLayout>
#include "src/widget/uiSetComPara.h"
#include "src/widget/fileView.h"
#include <QMessageBox>
#include <QUrl>
#include<stdio.h>
#include<stdlib.h>
#include <QSqlDatabase>
#include <QSqlQuery>
#include "src/thread/uGpsThread.h"

GPS *g_pComDebugger;//声明全局变量
QSqlDatabase g_Sql;//声明一个数据库全局变量,db

GPS::GPS(QWidget *parent) :
	QWidget(parent)
{
	ui.setupUi(this);

	setAttribute(Qt::WA_DeleteOnClose);

	this->setWindowTitle(trUtf8("天嵌科技GPS卫星导航"));

	g_Sql = QSqlDatabase::addDatabase("QSQLITE");
	g_Sql.setDatabaseName("/opt/PDA/lib/data/gpsdata.db");

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");//设置背景
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	m_iRecvCount = 0;
	m_iSendCount = 0;
	m_pTimer = new QTimer(this);
	m_laTitle = new QLabel(trUtf8("天嵌科技GPS卫星导航"), this);//标题
	m_laTitle->setAlignment(Qt::AlignCenter);

	m_numDisplay = new QTextEdit(this);//显示经纬度
	m_numDisplay->setFixedSize(150, 60);//设定文本框大小

	m_introDisplay = new QTextEdit(this);//显示地区简介
	m_introDisplay->setMaximumWidth(150);//设置最大宽度


	m_isStartGPS = true;//设置开始暂停GPS功能，初始化开始

	m_pbHelp = new QPushButton(this);
	m_pbHelp->setFixedSize(82, 32);
	m_pbHelp->setIconSize(QSize(82, 32));
	QPixmap pix("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	m_pbContrGPS = new QPushButton(this);
	m_pbContrGPS->setFixedSize(82, 32);
	m_pbContrGPS->setIcon(QIcon("/opt/PDA/app/images/pause.png"));//设置按键图标
	m_pbContrGPS->setIconSize(QSize(82, 32));
	connect(m_pbContrGPS, SIGNAL(clicked()), this, SLOT(pbContrGPSClicked()));//信号与槽关联

	m_pbImportGPSData = new QPushButton(this);
	m_pbImportGPSData->setFixedSize(82, 32);
	m_pbImportGPSData->setIcon(QIcon("/opt/PDA/app/images/addGpsData.png"));//设置按键图标
	m_pbImportGPSData->setIconSize(QSize(82, 32));
	connect(m_pbImportGPSData, SIGNAL(clicked()), this, SLOT(pbImportGPSData()));

	m_pbExit = new QPushButton(this);//退出按钮
	m_pbExit->setFixedSize(82, 32);
	m_pbExit->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出按键图标
	m_pbExit->setIconSize(QSize(82, 32));
	connect(m_pbExit, SIGNAL(clicked()), this, SLOT(pbExit()));

	QScrollArea *scroll = new QScrollArea;//图片显示浏览框
	scroll->setWidgetResizable(true);//
	scroll->setAlignment(Qt::AlignCenter);//
	scroll->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);//
	m_lbImage = new MyLabel();//显示图片的QLabel
	scroll->setWidget(m_lbImage);//设置图片显示再scroll上
	m_IsFullScreen = false;//设置全屏标志，开始图片不全屏
	connect(m_lbImage, SIGNAL(lbDbClicked()), this, SLOT(lbDoubleClicked()));//QLabel双击对应的槽

	QVBoxLayout *displayLayout = new QVBoxLayout;//显示经纬度和地区介绍的layout
	displayLayout->addWidget(m_numDisplay);//添加显示经纬度widget
	displayLayout->addWidget(m_introDisplay);//添加显示地区介绍的widget

	QHBoxLayout *middleLayout = new QHBoxLayout;//
	middleLayout->addWidget(scroll);
	middleLayout->addLayout(displayLayout);

	m_pbSet = new QPushButton();
	m_pbSet->setFixedSize(82, 32);
	m_pbSet->setIcon(QIcon("/opt/PDA/app/images/gpsRecData.png"));
	m_pbSet->setIconSize(QSize(82, 32));
	connect(m_pbSet, SIGNAL(clicked()), this, SLOT(pbSetClicked()));

	QHBoxLayout *controlsLayout = new QHBoxLayout;//GPS，开始暂停，退出的layout
	controlsLayout->addWidget(m_pbHelp);
	controlsLayout->addWidget(m_pbSet);
	controlsLayout->addWidget(m_pbContrGPS);
	controlsLayout->addWidget(m_pbImportGPSData);
	controlsLayout->addWidget(m_pbExit);

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addWidget(m_laTitle);
	mainLayout->addLayout(middleLayout);
	mainLayout->addLayout(controlsLayout);
	mainLayout->setMargin(0);
	this->setLayout(mainLayout);

	m_introDisplay->clear();
	m_introDisplay->clear();
	m_pTimer->start(100);

connect(g_Gps, SIGNAL(DoData(char *,int)), this,
		SLOT(ShowComMsg(char *,int)));//进程信号关联

}
// 析构函数
GPS::~GPS()
{
	m_pTimer->stop();
	delete m_pTimer;
	delete g_Gps;
	delete m_introDisplay;
	delete m_numDisplay;
	delete m_pbImportGPSData;
	delete m_pbContrGPS;
	delete m_pbExit;
	delete m_laTitle;
	delete m_lbImage;
}

//串口设置
void GPS::pbSetClicked()
{
	uiSetComPara *para = new uiSetComPara();
	para->showFullScreen();
}
//导入新的数据信息
void GPS::pbImportGPSData()
{
	fileView *import = new fileView;
	import->showFullScreen();
	//	import->show();
}
/*
 ** 函数名称：ShowComMsg
 ** 创建日期：2011-07-04
 ** 创 建 人： gxx
 ** 函数说明： 读取GPS数据，处理数据
 ** 参    数：cData，从 进程获取的数据，iLen数据长度
 ** 返    回：无
 ** 数 据 库：gpsdata.db
 ** 其它说明：无
 */
void GPS::ShowComMsg(char cData[2048], int iLen)
{
	QString str = QString(cData).mid(0, iLen);
	QString str_city;//声明城市名字QString
	QString str_WD, str_JD;//声明经度、纬度QString类型
	double dWD, dJD;//声明经度，纬度，double类型
	int iNS = 3, iWE = 3;//东经、西经标志，南纬、北纬标志
	if (memcmp(cData, "$GPGGA", 6) == 0)
	{
		int icount = 0;//读取到第几个逗号
		for (int n = 0; n < iLen; n++)
		{
			if (cData[n] == ',')// 读取到逗号
			{
				icount++;
			}
			if (icount == 2)//第2个逗号后面是纬度信息
			{
				str_WD.append(cData[n + 1]);
			}
			else if (icount == 3)//第三个逗号后面是北纬，南纬信息
			{
				if (cData[n + 1] == 'N')
					iNS = 1;
				else if (cData[n + 1] == 'S')
					iNS = 0;
			}
			else if (icount == 4)//第四个逗号后面是经度信息
			{
				str_JD.append(cData[n + 1]);

			}
			else if (icount == 5)//第五个逗号后面是东经西经信息
			{
				if (cData[n + 1] == 'W')
					iWE = 1;
				else if (cData[n + 1] == 'E')
					iWE = 0;
			}
		}
		str_WD.remove(QChar(','), Qt::CaseInsensitive);//去掉纬度里面逗号
		str_WD.remove(QChar('.'), Qt::CaseInsensitive);//去掉纬度里面句号（.）
		str_JD.remove(QChar(','), Qt::CaseInsensitive);
		str_JD.remove(QChar('.'), Qt::CaseInsensitive);

		if (iNS == 1)//如果gps信息是北纬
			str_city.append(trUtf8("北纬："));//
		else if (iNS == 0)//如果gps信息是南纬
			str_city.append(trUtf8("南纬："));
		str_WD.insert((str_WD.size() - 6), QString("."));//在数字倒数第六个数前加小数点，转化为实际数
		dWD = str_WD.toDouble();//转化为double类型
		str_city.append(str_WD);//显示信息加上城市名字
		str_city.append('\n');//

		if (iWE == 1)
			str_city.append(trUtf8("西经："));
		else if (iWE == 0)
			str_city.append(trUtf8("东经："));
		str_JD.insert((str_JD.size() - 6), QString("."));
		dJD = str_JD.toDouble();
		str_city.append(str_JD);

		str_city.append('\n');
		str_city.append("所在地：");

		QString strId, strName, strW, strE, strS, strN, str_info;//定义，从数据库读取到的最小经度，最大经度，最小纬度，最大纬度QString类型

		if (!g_Sql.open())
		{
			QMessageBox::critical(NULL, QObject::tr("无法打开数据库\n"),
					QObject::tr("退出清按Cancel键"), QMessageBox::Cancel,
					QMessageBox::NoButton);
		}
		QSqlQuery query("SELECT * FROM GPS");

		while (query.next())
		{
			strId = query.value(0).toString();
			strName = query.value(1).toString();
			strW = query.value(2).toString();
			strE = query.value(3).toString();
			strS = query.value(4).toString();
			strN = query.value(5).toString();
			str_info = query.value(6).toString();

			if ((dJD > strW.toDouble()) && (dJD < strE.toDouble())//如果gps获取的经纬度在当前获取的经纬度范围
					&& (dWD > strS.toDouble() && (dWD < strN.toDouble())))
			{
				m_numDisplay->setText(str_city + strName);//显示经纬度和城市s
				m_introDisplay->setText(str_info);//显示信息
				QString str_imagePath = "/opt/PDA/pic/gps_images/";//显示图片路径
				str_imagePath.append(strId);//添加具体城市序
				str_imagePath.append(".jpg");//
				QPixmap pixmap(str_imagePath);//
				m_lbImage->setPixmap(pixmap);//显示图片
			}
		}
	}
}

//开始暂停处理
void GPS::pbContrGPSClicked()
{
	m_isStartGPS = !m_isStartGPS;
	if (m_isStartGPS == true)
	{
		g_Gps->m_pCom->open(QIODevice::ReadWrite);
		m_pbContrGPS->setFixedSize(82, 32);
		m_pbContrGPS->setIcon(QIcon("/opt/PDA/app/images/pause.png"));//设置退出案件图标
		m_pbContrGPS->setIconSize(QSize(82, 32));
	}
	else
	{
		g_Gps->m_pCom->close();
		m_pbContrGPS->setFixedSize(82, 32);
		m_pbContrGPS->setIcon(QIcon("/opt/PDA/app/images/start.png"));//设置退出案件图标
		m_pbContrGPS->setIconSize(QSize(82, 32));
	}

}
void GPS::pbExit()
{
	exit(1);
}
//双击图片全屏
void GPS::lbDoubleClicked()//双击图片
{
	m_laTitle->setVisible(m_IsFullScreen);
	m_introDisplay->setVisible(m_IsFullScreen);
	m_numDisplay->setVisible(m_IsFullScreen);
	m_pbContrGPS->setVisible(m_IsFullScreen);
	m_pbExit->setVisible(m_IsFullScreen);
	m_pbSet->setVisible(m_IsFullScreen);
	m_pbImportGPSData->setVisible(m_IsFullScreen);
	m_pbHelp->setVisible(m_IsFullScreen);
	m_IsFullScreen = !m_IsFullScreen;
	printf("adafef");

}
void GPS::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
