#include <QtGui>
#include <QApplication>
#include "gps.h"
#include"src/thread/uGpsThread.h"

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));

	g_Gps = new GpsThread();
	g_Gps->start();

	g_pComDebugger = new GPS();
	g_pComDebugger->showFullScreen();

	return a.exec();
}
