/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		GpsThread
 *    文件名:     	 GpsThread.cpp
 *    文件描述:  		gps读取数据线程
 *    创建日期:      2011-06-27
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */
#include "uGpsThread.h"
#include<QSettings>
#include "src/armapi/qextserialbase.h"
GpsThread *g_Gps;
int iBaudRate, iDataBits, iStopBits;
GpsThread::GpsThread()
{
	ReadBaudRate();
	QSettings
			settings("/opt/PDA/configs/EmbedSkyGPS.ini", QSettings::IniFormat);///读串口配置参数
	settings.beginGroup("GPSUart");
	QString str_Com = settings.value("Com", "ttySAC3").toString();
	settings.endGroup();

	QFile f("/dev/" + str_Com);
	if (f.exists())//判断驱动文件存在
	{
		m_pCom = new Posix_QextSerialPort("/dev/" + str_Com,
				QextSerialBase::Polling);//定义串口
		if (m_pCom->open(QIODevice::ReadWrite))//打开串口
		{
			m_pCom->setBaudRate(BaudRateType(iBaudRate));
			m_pCom->setDataBits(DataBitsType(iDataBits));
			m_pCom->setParity(PAR_NONE);
			m_pCom->setStopBits(StopBitsType(iStopBits));
			m_pCom->setFlowControl(FLOW_OFF);
			m_pCom->setTimeout(10);
		}
	}
}
GpsThread::~GpsThread()
{
	delete m_pCom;
}
//线程函数
void GpsThread::run()
{
	char cData[2048];
	int iLen;
	while (1)
	{
		if (m_pCom->isOpen())//打开串口
		{
			iLen = m_pCom->read(cData, sizeof(cData));//读串口信息
			if (iLen > 0)
			{
				emit DoData(cData, iLen);//
			}
		}
		sleep(1);
	}
	exec();
}

void GpsThread::ReadBaudRate()
{
	QSettings
			settings("/opt/PDA/configs/EmbedSkyGPS.ini", QSettings::IniFormat);///读串口配置参数
	settings.beginGroup("GPSUart");
	QString str_Com = settings.value("Com", "ttySAC3").toString();
	QString str_Rate = settings.value("Rate", "9600").toString();
	QString str_DataBit = settings.value("DataBit", "8").toString();
	QString str_StopBit = settings.value("StopBit", "1").toString();
	QString str_CheckBit = settings.value("CheckBit", "None").toString();

	settings.endGroup();

	switch (str_Rate.toInt(0, 10))
	{
	case 110:
		iBaudRate = 2;
		break;
	case 300:
		iBaudRate = 6;
		break;
	case 600:
		iBaudRate = 7;
		break;
	case 1200:
		iBaudRate = 8;
		break;
	case 2400:
		iBaudRate = 10;
		break;
	case 4800:
		iBaudRate = 11;
		break;
	case 9600:
		iBaudRate = 12;
		break;
	case 14400:
		iBaudRate = 13;
		break;
	case 19200:
		iBaudRate = 15;
		break;
	case 38400:
		iBaudRate = 16;
		break;
	case 56000:
		iBaudRate = 18;
		break;
	case 57600:
		iBaudRate = 19;
		break;
	case 115200:
		iBaudRate = 22;
		break;
	case 256000:
		iBaudRate = 24;
		break;
	default:
		break;
	}
	switch (str_DataBit.toInt(0, 10))
	{
	case 5:
		iDataBits = 0;
		break;
	case 6:
		iDataBits = 1;
		break;
	case 7:
		iDataBits = 2;
		break;
	case 8:
		iDataBits = 3;
		break;
	default:
		break;
	}//iStopBits
	if (str_DataBit == "1")
		iStopBits = 0;
	else if (str_DataBit == "1.5")
		iStopBits = 1;
	else if (str_DataBit == "2")
		iStopBits = 2;
}
