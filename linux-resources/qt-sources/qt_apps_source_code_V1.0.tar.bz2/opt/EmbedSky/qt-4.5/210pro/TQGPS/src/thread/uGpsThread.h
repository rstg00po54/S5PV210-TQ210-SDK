/*
 * uIDReaderThread.h
 *
 *  Created on: 2011-6-27
 *      Author: root
 */

#ifndef UIDREADERTHREAD_H_
#define UIDREADERTHREAD_H_
#include <QThread>
#include <QObject>
#include "src/armapi/posix_qextserialport.h"
class GpsThread: public QThread
{
	Q_OBJECT
public:
	GpsThread();
	virtual ~GpsThread();
	void run();
	Posix_QextSerialPort *m_pCom;
	void ReadBaudRate();

	signals:
	void DoData(char *,int );

};
extern GpsThread *g_Gps;
#endif /* UIDREADERTHREAD_H_ */
