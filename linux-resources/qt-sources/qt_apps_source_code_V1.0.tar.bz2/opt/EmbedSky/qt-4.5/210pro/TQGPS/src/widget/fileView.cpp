/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		gps应用程序
 *    文件名:             fileView.cpp
 *    文件描述:  		主界面
 *    创建日期:      2011-07-08
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    数据库：gpsdata.db
 *    其他:             无
 */

#include "fileView.h"
#include <QVBoxLayout>
#include<QFile>
#include<QString>
#include<QPicture>
#include <QByteArray>
#include"gps.h"
int iUpdata = 0;
QString str_picPath = "/opt/PDA/pic/gps_images/";

fileView::fileView(QDialog *parent) :
	QDialog(parent)
{
	ui.setupUi(this);

	setAttribute(Qt::WA_DeleteOnClose);

	this->setAutoFillBackground(true);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	QLabel *labelTitle = new QLabel(trUtf8("文件浏览器"), this);
	labelTitle->setAlignment(Qt::AlignCenter);

	model = new QDirModel;//创建QDirMode的一个对象
	model->setReadOnly(false);//对象可以修改
	model->setSorting(QDir::DirsFirst | QDir::IgnoreCase | QDir::Name);//排序原则：文件夹优先、忽略大小写、根据名字排序

	treeView = new QTreeView(this);//创建QTreeView实例
	treeView->setModel(model);//把model设为treeView实例
	treeView->header()->setStretchLastSection(true);//最后一列自动改变宽度以适应整个treeView的宽度
	treeView->header()->setSortIndicator(0, Qt::AscendingOrder);//设置按照那一列进行排序，第0列，即名字排序
	treeView->header()->setSortIndicatorShown(true);//显示列头上面的排序小箭头
	treeView->header()->setClickable(true);//允许点击列头
	treeView->hideColumn(1);
	treeView->hideColumn(2);
	treeView->hideColumn(3);
	treeView->setBaseSize(400, 300);
	QModelIndex index = model->index("/home");//获取当前exe文件运行等路径位置，并显示当前路径
	treeView->expand(index);//展开这一路径
	treeView->scrollTo(index);//把试图等视口滚动到这个路径的位置
	treeView->resizeColumnToContents(0);//列头适应内容宽度

	pbConfirm = new QPushButton(this);
	pbConfirm->setFixedSize(82, 32);
	pbConfirm->setIcon(QIcon("/opt/PDA/app/images/confirm.png"));//设置退出案件图标
	pbConfirm->setIconSize(QSize(82, 32));
	connect(pbConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));

	pbCancel = new QPushButton(this);
	pbCancel->setFixedSize(82, 32);
	pbCancel->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出案件图标
	pbCancel->setIconSize(QSize(82, 32));
	connect(pbCancel, SIGNAL(clicked()), SLOT(pbCancleClicked()));

	QVBoxLayout *rightLayout = new QVBoxLayout;
	rightLayout->addWidget(pbConfirm);
	rightLayout->addWidget(pbCancel);

	QHBoxLayout *middleLayout = new QHBoxLayout;
	middleLayout->addWidget(treeView);
	middleLayout->addLayout(rightLayout);

	QVBoxLayout *mainLayout = new QVBoxLayout;
	mainLayout->addWidget(labelTitle);
	mainLayout->addLayout(middleLayout);
	this->setLayout(mainLayout);
}

fileView::~fileView()
{
	delete model;//声明model对象
	delete treeView;//声明QTreeView对象
	delete pbConfirm;
	delete pbCancel;
	//	g_Sql.open()
}
// 确认键
void fileView::pbConfirmClicked()
{
	QFile file;
	int iAll = 0, iCurrent = 0;
	QString strCity, strLongMin, strLongMax, strLatMin, strLatMax, strInfo;//读取的城市名字，最小纬度，最大纬度，最大经度，最小经度，城市简介
	QString str_imagePathTo;///opt/PDA/pic/gpsimages.存放gps城市图片路径
	QModelIndex index = treeView->currentIndex();//获取当前index
	if (!index.isValid())//选择文件路径无效
	{ //默认是没有目录选择的，当前目录是非法的，为了避免异常，要有这个判断
		QMessageBox warn;
		warn.setWindowTitle(trUtf8("        错误   "));
		warn.setText(trUtf8("请选择文件！"));
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
		QIcon icon(pix);
		warn .setWindowIcon(icon);
		warn.exec();
		return;
	}
	QModelIndex index_parent = model->index(model->fileInfo(index).path(), 0);//获取父index

	if (model->fileInfo(index).isDir())//选择文件件，路径无效
	{
		QMessageBox warn;
		warn.setWindowTitle(trUtf8("       错误    "));
		warn.setText(trUtf8("请选择文件！"));
		QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
		QIcon icon(pix);
		warn .setWindowIcon(icon);
		warn.exec();
		return;
	}
	else
	{
		file.setFileName(model->filePath(index));//设置传递文件路径
		if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
			return;

		QByteArray line = file.readLine();//逐行读信息
		line = file.readLine();
		strCity.append(line);
		strCity.remove('\n');

		line = file.readLine();
		line = file.readLine();
		strLongMin.append(line);
		strLongMin.remove("最小值：");
		strLongMin.remove('\n');

		line = file.readLine();
		strLongMax.append(line);
		strLongMax.remove("最大值：");
		strLongMax.remove('\n');

		line = file.readLine();
		line = file.readLine();
		strLatMin.append(line);
		strLatMin.remove("最小值：");
		strLatMin.remove('\n');

		line = file.readLine();
		strLatMax.append(line);
		strLatMax.remove("最大值：");
		strLatMax.remove('\n');

		line = file.readLine();
		line = file.readLine();
		strInfo.append(line);
		strInfo.remove('\n');
	}

	if (!g_Sql.open())//打开数据库
	{
		QMessageBox::critical(NULL, QObject::tr("无法打开数据库\n"),
				QObject::tr("退出清按Cancel键"), QMessageBox::Cancel,
				QMessageBox::NoButton);
	}

	iUpdata = 0;
	QSqlQuery query("SELECT * FROM GPS");
	QString strName;
	while (query.next())//读取数据库信息
	{
		iAll++;
		strName = query.value(1).toString();
		if (strcmp(strName.toUtf8().data(), strCity.toUtf8().data()) == 0)//要导入的城市是否已存在数据库中，如果存在
		{
			iUpdata = 1;//标记导入
			iCurrent = query.value(0).toInt();//设置id号
		}
	}

	if (iUpdata == 0)//添加
	{
		query.clear();
		query.prepare(
				"INSERT INTO GPS (num,city,longmin,longmax,latmax,latmin,info) "
					"VALUES (?,?,?,?,?,?,?)");
		query.addBindValue(iAll + 1);
		query.addBindValue(strCity.toUtf8().data());
		query.addBindValue(strLongMin);
		query.addBindValue(strLongMax);
		query.addBindValue(strLatMin);
		query.addBindValue(strLatMax);
		query.addBindValue(strInfo.toUtf8().data());
		if (query.exec())
		{
			QMessageBox warn;
			warn.setWindowTitle(trUtf8("提示"));
			warn.setText(trUtf8("导入成功！"));
			warn.setStandardButtons(QMessageBox::Ok);
			QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
			QIcon icon(pix);
			warn .setWindowIcon(icon);
			warn.exec();
		}
		else
		{
			QMessageBox warn;
			warn.setWindowTitle(trUtf8("提示"));
			warn.setText(trUtf8("导入失败！"));
			warn.setStandardButtons(QMessageBox::Ok);
			QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
			QIcon icon(pix);
			warn .setWindowIcon(icon);
			warn.exec();
		}

		QString str_imagePath = model->filePath(index_parent) + "/" + strCity
				+ ".jpg";
		QModelIndex index_Pic = model->index(str_imagePath, 0);
		if (index_Pic.isValid())
		{
			str_imagePath = model->filePath(index_parent) + "/" + strCity
					+ ".jpg";
		}
		else
		{
			QMessageBox warn;
			warn.setWindowTitle(trUtf8("提示"));
			warn.setText(trUtf8("不存在图片！"));
			warn.setStandardButtons(QMessageBox::Ok);
			QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
			QIcon icon(pix);
			warn .setWindowIcon(icon);
			warn.exec();
		}

		str_imagePathTo = "/opt/PDA/pic/gps_images";
		QString str_sql = "cp -rf " + str_imagePath + " " + str_imagePathTo;
		QByteArray bba = str_sql.toUtf8();
		char *cCity = bba.data();
		system(cCity);
	}
	else//更新数据
	{
		query.clear();
		query.prepare(
				"update GPS set city=?,LongMin=?,LongMax=?,LatMin=?,LatMax=?,info=? where num=?");
		query.bindValue(0, strCity.toUtf8().data());
		query.bindValue(1, strLongMin);
		query.bindValue(2, strLongMax);
		query.bindValue(3, strLatMin);
		query.bindValue(4, strLatMax);
		query.bindValue(5, strInfo.toUtf8().data());
		query.bindValue(6, iCurrent);
		if (query.exec())
		{
			QMessageBox warn;
			warn.setWindowTitle(trUtf8("提示"));
			warn.setText(trUtf8("更新成功！"));
			warn.setStandardButtons(QMessageBox::Ok);
			QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
			QIcon icon(pix);
			warn .setWindowIcon(icon);
			warn.exec();
		}
		else
		{
			QMessageBox warn;
			warn.setWindowTitle(trUtf8("提示"));
			warn.setText(trUtf8("更新失败！"));
			warn.setStandardButtons(QMessageBox::Ok);
			QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
			QIcon icon(pix);
			warn .setWindowIcon(icon);
			warn.exec();
		}

		QString str_imagePath = model->filePath(index_parent) + "/" + strCity
				+ ".jpg";
		QModelIndex index_Pic = model->index(str_imagePath, 0);
		if (index_Pic.isValid())
		{
			str_imagePath = model->filePath(index_parent) + "/" + strCity
					+ ".jpg";
		}
		else
		{
			QMessageBox warn;
			warn.setWindowTitle(trUtf8("提示"));
			warn.setText(trUtf8("不存在图片！"));
			warn.setStandardButtons(QMessageBox::Ok);
			QPixmap pix("/opt/PDA/app/images/EmbedSky.png", 0, Qt::AutoColor);
			QIcon icon(pix);
			warn .setWindowIcon(icon);
			warn.exec();
		}

		str_imagePathTo = "/opt/PDA/pic/gps_images";
		QString str_sql = "rm -rf " + str_imagePathTo + "/iCurrent.jpg";
		QByteArray bba = str_sql.toUtf8();
		char *cCity = bba.data();
		if (iUpdata == 1)
			system(cCity);

		str_sql = "cp -rf " + str_imagePath + " " + str_imagePathTo;
		bba = str_sql.toUtf8();
		cCity = bba.data();
		system(cCity);
	}
}
//退出
void fileView::pbCancleClicked()
{
	close();
}

