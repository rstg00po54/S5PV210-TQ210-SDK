#ifndef FILEVIEW_H
#define FILEVIEW_H

#include <QtGui/QDialog>
#include "ui_fileView.h"
#include <QModelIndex>
#include <QDirModel>
#include<QtGui>

class fileView: public QDialog
{
	Q_OBJECT

public:
	fileView(QDialog *parent = 0);
	~fileView();public slots:
	void pbConfirmClicked();
	void pbCancleClicked();

private:
	Ui::fileViewClass ui;

	int num;//导入城市序号
	int numinput;

	QDirModel *model;//声明model对象
	QTreeView *treeView;//声明QTreeView对象


	QPushButton *pbConfirm;
	QPushButton *pbCancel;
};

#endif // FILEVIEW_H
