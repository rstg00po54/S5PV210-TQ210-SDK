/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		uiSetComPara
 *    文件名:     	 uiSetComPara
 *    文件描述:  	串口设置
 *    创建日期:      2011-06-27
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */

#include "uiSetComPara.h"
#include <QVBoxLayout>
#include "gps.h"
#include <QMessageBox>
#include<QSettings>
#include"src/thread/uGpsThread.h"

uiSetComPara::uiSetComPara(QDialog *parent) :
	QDialog(parent)
{
	ui.setupUi(this);

	setAttribute(Qt::WA_DeleteOnClose);

	this->setWindowTitle(trUtf8("天嵌科技串口工具V1.0"));
	this->setAutoFillBackground(true);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	ui.label->setAlignment(Qt::AlignHCenter);
	ui.label->setAlignment(Qt::AlignCenter);

	ui.pbConfirm->setFixedSize(82, 32);
	ui.pbConfirm->setIcon(QIcon("/opt/PDA/app/images/confirm.png"));//设置图表
	ui.pbConfirm->setIconSize(QSize(82, 32));

	ui.pbCancel->setFixedSize(82, 32);
	ui.pbCancel->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出图标
	ui.pbCancel->setIconSize(QSize(82, 32));

	QStringList list;
	list.append("ttySAC0");
	list.append("ttySAC1");
	list.append("ttySAC2");
	list.append("ttySAC3");
	ui.cbCom->addItems(list);
	ui.cbCom->setCurrentIndex(1);
	//波特率
	list.clear();
	list = (QStringList() << "110" << "300" << "600" << "1200" << "2400"
			<< "4800" << "9600");
	list += (QStringList() << "14400" << "19200" << "38400" << "56000"
			<< "57600" << "115200" << "256000");
	ui.cbRate->addItems(list);
	ui.cbRate->setCurrentIndex(6);
	//数据位
	list.clear();
	list = (QStringList() << "5" << "6" << "7" << "8");
	ui.cbDataBit->addItems(list);
	ui.cbDataBit->setCurrentIndex(3);
	//停止位
	list.clear();
	list = (QStringList() << "1" << "1.5" << "2");
	ui.cbStopBit->addItems(list);
	ui.cbStopBit->setCurrentIndex(0);
	//校验位
	list.clear();
	list = (QStringList() << "None" << "Odd" << "Even" << "Mark" << "Space");
	ui.cbCheckBit->addItems(list);
	ui.cbCheckBit->setCurrentIndex(0);
	//流控制
	list.clear();
	list = (QStringList() << "HardWare" << "SoftWare" << "None");
	ui.cbFlowControl->addItems(list);
	ui.cbFlowControl->setCurrentIndex(2);

	QSettings
			settings("/opt/PDA/configs/EmbedSkyGPS.ini", QSettings::IniFormat);
	settings.beginGroup("GPSUart");
	ui.cbCom->setCurrentIndex(
			ui.cbCom->findText(settings.value("Com", "ttySAC3").toString()));
	ui.cbRate->setCurrentIndex(
			ui.cbRate->findText(settings.value("Rate", "9600").toString()));
	ui.cbDataBit->setCurrentIndex(
			ui.cbDataBit->findText(settings.value("DataBit", "8").toString()));
	ui.cbStopBit->setCurrentIndex(
			ui.cbStopBit->findText(settings.value("StopBit", "1").toString()));
	ui.cbCheckBit->setCurrentIndex(
			ui.cbCheckBit->findText(
					settings.value("CheckBit", "None").toString()));
	ui.cbFlowControl->setCurrentIndex(
			ui.cbFlowControl->findText(
					settings.value("FlowControl", "None").toString()));
	settings.endGroup();

	QHBoxLayout *comLayOut = new QHBoxLayout;
	comLayOut->addSpacing(140);
	comLayOut->addWidget(ui.lbCom);
	comLayOut->addWidget(ui.cbCom);
	comLayOut->addSpacing(140);

	ui.cbCom->setMinimumWidth(108);
	ui.cbRate->setMinimumWidth(108);
	ui.cbDataBit->setMinimumWidth(108);
	ui.cbStopBit->setMinimumWidth(108);
	ui.cbCheckBit->setMinimumWidth(108);
	ui.cbFlowControl->setMinimumWidth(108);

	QHBoxLayout *rateLayOut = new QHBoxLayout;
	rateLayOut->addSpacing(140);
	rateLayOut->addWidget(ui.lbRate);
	rateLayOut->addWidget(ui.cbRate);
	rateLayOut->addSpacing(140);

	QHBoxLayout *dataLayOut = new QHBoxLayout;
	dataLayOut->addSpacing(140);
	dataLayOut->addWidget(ui.lbDataBit);
	dataLayOut->addWidget(ui.cbDataBit);
	dataLayOut->addSpacing(140);

	QHBoxLayout *stopLayOut = new QHBoxLayout;
	stopLayOut->addSpacing(140);
	stopLayOut->addWidget(ui.lbStopBit);
	stopLayOut->addWidget(ui.cbStopBit);
	stopLayOut->addSpacing(140);

	QHBoxLayout *checkLayOut = new QHBoxLayout;
	checkLayOut->addSpacing(140);
	checkLayOut->addWidget(ui.lbCheckBit);
	checkLayOut->addWidget(ui.cbCheckBit);
	checkLayOut->addSpacing(140);

	QHBoxLayout *flowLayOut = new QHBoxLayout;
	flowLayOut->addSpacing(140);
	flowLayOut->addWidget(ui.lbFlowControl);
	flowLayOut->addWidget(ui.cbFlowControl);
	flowLayOut->addSpacing(140);

	QHBoxLayout *bottomLayOut = new QHBoxLayout;
	bottomLayOut->addSpacing(140);
	bottomLayOut->addWidget(ui.pbCancel);
	bottomLayOut->addSpacing(30);
	bottomLayOut->addWidget(ui.pbConfirm);
	bottomLayOut->addSpacing(140);

	QVBoxLayout *centralLayOut = new QVBoxLayout;
	centralLayOut->addWidget(ui.label);
	centralLayOut->addLayout(comLayOut);
	centralLayOut->addLayout(rateLayOut);
	centralLayOut->addLayout(dataLayOut);
	centralLayOut->addLayout(stopLayOut);
	centralLayOut->addLayout(checkLayOut);
	centralLayOut->addLayout(flowLayOut);
	centralLayOut->addLayout(bottomLayOut);
	centralLayOut->addSpacing(20);

	connect(ui.pbCancel, SIGNAL(clicked()), this, SLOT(pbCancelClicked()));
	connect(ui.pbConfirm, SIGNAL(clicked()), this, SLOT(pbConfirmClicked()));
}

uiSetComPara::~uiSetComPara()
{

}
void uiSetComPara::pbCancelClicked()
{
	close();
}
//确定按钮
void uiSetComPara::pbConfirmClicked()
{
	g_Gps->terminate();
	g_Gps->m_pCom->close();

	if (g_Gps->m_pCom->open(QIODevice::ReadWrite))
	{
		QString str = ui.cbCom->currentText() + " 已打开";

		switch (ui.cbCom->currentIndex())
		{
		case 0:
			g_Gps->m_pCom->setPort("/dev/ttySAC0");
			break;
		case 1:
			g_Gps->m_pCom->setPort("/dev/ttySAC1");
			break;
		case 2:
			g_Gps->m_pCom->setPort("/dev/ttySAC2");
			break;
		case 3:
			g_Gps->m_pCom->setPort("/dev/ttySAC3");
			break;
		default:
			break;
		}

		switch (ui.cbRate->currentIndex())
		{
		case 0:
			g_Gps->m_pCom->setBaudRate(BAUD110);
			str += " 110";
			break;
		case 1:
			g_Gps->m_pCom->setBaudRate(BAUD300);
			str += " 300";
			break;
		case 2:
			g_Gps->m_pCom->setBaudRate(BAUD600);
			str += " 600";
			break;
		case 3:
			g_Gps->m_pCom->setBaudRate(BAUD1200);
			str += " 1200";
			break;
		case 4:
			g_Gps->m_pCom->setBaudRate(BAUD2400);
			str += " 2400";
			break;
		case 5:
			g_Gps->m_pCom->setBaudRate(BAUD4800);
			str += " 4800";
			break;
		case 6:
			g_Gps->m_pCom->setBaudRate(BAUD9600);
			str += " 9600";
			break;
		case 7:
			g_Gps->m_pCom->setBaudRate(BAUD14400);
			str += " 14400";
			break;
		case 8:
			g_Gps->m_pCom->setBaudRate(BAUD19200);
			str += " 19200";
			break;
		case 9:
			g_Gps->m_pCom->setBaudRate(BAUD38400);
			str += " 38400";
			break;
		case 10:
			g_Gps->m_pCom->setBaudRate(BAUD56000);
			str += " 56000";
			break;
		case 11:
			g_Gps->m_pCom->setBaudRate(BAUD57600);
			str += " 57600";
			break;
		case 12:
			g_Gps->m_pCom->setBaudRate(BAUD115200);
			str += " 11520";
			break;
		case 13:
			g_Gps->m_pCom->setBaudRate(BAUD256000);
			str += " 256000";
			break;
		default:
			break;
		}

		switch (ui.cbDataBit->currentIndex())
		{
		case 0:
			g_Gps->m_pCom->setDataBits(DATA_5);
			str += " 5";
			break;
		case 1:
			g_Gps->m_pCom->setDataBits(DATA_6);
			str += " 6";
			break;
		case 2:
			g_Gps->m_pCom->setDataBits(DATA_7);
			str += " 7";
			break;
		case 3:
			g_Gps->m_pCom->setDataBits(DATA_8);
			str += " 8";
			break;
		default:
			break;
		}

		switch (ui.cbStopBit->currentIndex())
		{
		case 0:
			g_Gps->m_pCom->setStopBits(STOP_1);
			break;
		case 1:
			g_Gps->m_pCom->setStopBits(STOP_1_5);
			break;
		case 2:
			g_Gps->m_pCom->setStopBits(STOP_2);
			break;
		default:
			break;
		}

		switch (ui.cbCheckBit->currentIndex())
		{
		case 0:
			g_Gps->m_pCom->setParity(PAR_NONE);
			break;
		case 1:
			g_Gps->m_pCom->setParity(PAR_ODD);
			break;
		case 2:
			g_Gps->m_pCom->setParity(PAR_EVEN);
			break;
		case 3:
			g_Gps->m_pCom->setParity(PAR_MARK);
			break;
		case 4:
			g_Gps->m_pCom->setParity(PAR_SPACE);
			break;
		default:
			break;
		}

		switch (ui.cbFlowControl->currentIndex())
		{
		case 0:
			g_Gps->m_pCom->setFlowControl(FLOW_HARDWARE);
			break;
		case 1:
			g_Gps->m_pCom->setFlowControl(FLOW_XONXOFF);
			break;
		case 2:
			g_Gps->m_pCom->setFlowControl(FLOW_OFF);
			break;
		default:
			break;
		}
	}
	else
	{
		QMessageBox::warning(this, trUtf8("提示"), trUtf8("串口打开失败！"),
				QMessageBox::Ok);
	}

	g_Gps->start();
	g_Gps->m_pCom->open(QIODevice::ReadWrite);

	pbCancelClicked();
	//////////////保存设置参数到文件
	QSettings
			settings("/opt/PDA/configs/EmbedSkyGPS.ini", QSettings::IniFormat);
	settings.beginGroup("GPSUart");
	settings.setValue("Com", ui.cbCom->currentText());
	settings.setValue("Rate", ui.cbRate->currentText());
	settings.setValue("DataBit", ui.cbDataBit->currentText());
	settings.setValue("StopBit", ui.cbStopBit->currentText());
	settings.setValue("CheckBit", ui.cbCheckBit->currentText());
	settings.setValue("FlowControl", ui.cbFlowControl->currentText());
	settings.endGroup();
}

