/*
 *    公司名:    	广州天嵌科技有限公司
 *    项目名:   		adc应用程序
 *    文件名:     	ledtst.cpp
 *    文件描述:  		led测试程序主界面
 *    创建日期:      2011-06-28
 *    创 建 人:      gxx
 *    文档:
 *    运行平台:      linux
 *    其他:             无
 */

#include "ledtest.h"
#include <sys/ioctl.h>
#include<stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include<QTimer>
static int fb;
ledtest::ledtest(QWidget *parent) :
	QWidget(parent)
{
	ui.setupUi(this);

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

	fb = open("/dev/led", QIODevice::ReadWrite);//打开设备
	if (fb < 0)
	{
		perror("open device leds fail");
	}

	ui.pbHelp->setFixedSize(82, 32);
	ui.pbHelp->setIconSize(QSize(82, 32));
	QPixmap pix("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(82, 32, Qt::IgnoreAspectRatio);//图片大小
	ui.pbHelp->setIcon(QIcon(pix));
	connect(ui.pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	ui.uipbExit->setFixedSize(82, 32);
	ui.uipbExit->setIcon(QIcon("/opt/PDA/app/images/exit.png"));//设置退出案件图标
	ui.uipbExit->setIconSize(QSize(82, 32));

	connect(ui.uipbExit, SIGNAL(clicked()), this, SLOT(close()));//退出按钮建立关联
	QTimer *timer = new QTimer(parent);//定时器
	connect(timer, SIGNAL(timeout()), this, SLOT(oper()));//定时器关联
	timer->start(44);//开启定时器
}

ledtest::~ledtest()
{

}
//控制主函数
void ledtest::oper()
{
	if (ui.uiCb0->isChecked())//如果选中，checkbox0
		ioctl(fb, 1, 1);//控制灯亮
	else
		ioctl(fb, 0, 1);

	if (ui.uiCb1->isChecked())//如果选中，checkbox1
		ioctl(fb, 1, 2);//
	else
		ioctl(fb, 0, 2);//
}
void ledtest::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
