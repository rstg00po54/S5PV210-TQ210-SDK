#ifndef LEDTEST_H
#define LEDTEST_H

#include <QtGui/QWidget>
#include "ui_ledtest.h"
#include <qprocess.h>

class ledtest: public QWidget
{
Q_OBJECT

public:
	ledtest(QWidget *parent = 0);
	~ledtest();
public slots:
	void oper();//对led灯操作主函数
	void pbHelpClicked();

private:
	Ui::ledtestClass ui;
	QProcess process;
};

#endif // LEDTEST_H
