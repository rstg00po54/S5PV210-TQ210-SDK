#include "ledtest.h"

#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	ledtest w;
	QRect screen_size = QApplication::desktop()->screenGeometry();
	w.setGeometry(0, 0, screen_size.width(), screen_size.height());
	w.show();
	return a.exec();
}
