/********************************************************************************
** Form generated from reading ui file 'ledtest.ui'
**
** Created: Mon Jul 23 18:21:06 2012
**      by: Qt User Interface Compiler version 4.5.0
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_LEDTEST_H
#define UI_LEDTEST_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ledtestClass
{
public:
    QCheckBox *uiCb0;
    QCheckBox *uiCb1;
    QLabel *labelTitle;
    QPushButton *uipbExit;
    QPushButton *pbHelp;

    void setupUi(QWidget *ledtestClass)
    {
        if (ledtestClass->objectName().isEmpty())
            ledtestClass->setObjectName(QString::fromUtf8("ledtestClass"));
        ledtestClass->resize(400, 300);
        uiCb0 = new QCheckBox(ledtestClass);
        uiCb0->setObjectName(QString::fromUtf8("uiCb0"));
        uiCb0->setGeometry(QRect(110, 120, 81, 22));
        uiCb1 = new QCheckBox(ledtestClass);
        uiCb1->setObjectName(QString::fromUtf8("uiCb1"));
        uiCb1->setGeometry(QRect(220, 120, 71, 21));
        labelTitle = new QLabel(ledtestClass);
        labelTitle->setObjectName(QString::fromUtf8("labelTitle"));
        labelTitle->setGeometry(QRect(150, 30, 151, 21));
        uipbExit = new QPushButton(ledtestClass);
        uipbExit->setObjectName(QString::fromUtf8("uipbExit"));
        uipbExit->setGeometry(QRect(340, 200, 41, 31));
        pbHelp = new QPushButton(ledtestClass);
        pbHelp->setObjectName(QString::fromUtf8("pbHelp"));
        pbHelp->setGeometry(QRect(230, 200, 101, 27));

        retranslateUi(ledtestClass);

        QMetaObject::connectSlotsByName(ledtestClass);
    } // setupUi

    void retranslateUi(QWidget *ledtestClass)
    {
        ledtestClass->setWindowTitle(QApplication::translate("ledtestClass", "ledtest", 0, QApplication::UnicodeUTF8));
        uiCb0->setText(QApplication::translate("ledtestClass", "LED1", 0, QApplication::UnicodeUTF8));
        uiCb1->setText(QApplication::translate("ledtestClass", "LED2", 0, QApplication::UnicodeUTF8));
        labelTitle->setText(QApplication::translate("ledtestClass", "\345\244\251\345\265\214\347\247\221\346\212\200\344\272\214\346\236\201\347\256\241\346\265\213\350\257\225\347\250\213\345\272\217", 0, QApplication::UnicodeUTF8));
        uipbExit->setText(QString());
        pbHelp->setText(QString());
        Q_UNUSED(ledtestClass);
    } // retranslateUi

};

namespace Ui {
    class ledtestClass: public Ui_ledtestClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LEDTEST_H
