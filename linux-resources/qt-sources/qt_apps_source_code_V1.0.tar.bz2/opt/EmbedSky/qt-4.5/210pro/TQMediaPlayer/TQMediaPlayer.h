#ifndef __PLAYER_H_
#define __PLAYER_H_

#include <QWidget>
#include <QProcess>

QT_BEGIN_NAMESPACE
class QString;
class QPushButton;
class QProcess;
QT_END_NAMESPACE
#include <QAction>
#include <QPushButton>
#include <QSlider>
#include <QLCDNumber>
#include <QTimer>
#include <QGroupBox>
#include <QPoint>
#include "src/ThreadProc/uTQProcess.h"
class TQMediaPlayer: public QWidget
{
Q_OBJECT

public:
	TQMediaPlayer(QWidget * parent = 0);
	~TQMediaPlayer();

	void play(const QString &fileName);
	void controlCmd(const QString &cmd);

private slots:
	void play();
	void pause();
	void stop();
	void selectFile();
	void slotBackMessage();
	void finished(int exitCode, QProcess::ExitStatus exitStatus);
	void error(QProcess::ProcessError error);
	void start();
	void readyReadStandardOutput();
	void fileLength(int);
	void volumeChanged();
	void progressChanged(int);
	void setProgess();
protected:
	void resizeEvent(QResizeEvent * event);

private:
	QGroupBox *renderTarget;
	QProcess *mplayerProcess;
	QTimer m_Timer;

	QAction *m_pPlayAction;//播放
	QAction *m_pPauseAction;//暂停
	QAction *m_pStopAction;//停止
	QAction *m_pbDirAction;//添加文件
	QAction *m_pbQuitAction;//退出

	QSlider *m_pSlider;//声音
	QSlider *m_pProgessSlider;//声音
	QTQProcess *m_pProcess;
	QString m_strName;

	bool m_bPause;
	int m_iLastValue;//
	void setActions();

	int indexfile;
	int m_bFirst;
	unsigned char m_cData[80000];
	int m_iReadCount;
	QPoint p;
};

#endif // __PLAYER_H_
