#include "TQMediaPlayer.h"

#include <QtGui>
#include <QApplication>
#include <iostream>
using namespace std;
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
	TQMediaPlayer w;
	w.showFullScreen();
	return a.exec();
}
