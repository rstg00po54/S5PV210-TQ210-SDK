/*
 * uTQSound.cpp
 *
 *  Created on: 2011-6-8
 *      Author: lkp
 */

#include "uTQProcess.h"
#include <stdio.h>
#include <stdlib.h>
#include <linux/soundcard.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
//#include <arpa/inet.h>
#include <iostream>
#include <QFile>

using namespace std;
/*QTQProcess *g_pSound;
 QTQProcess *QTQProcess::getInstance(QProcess ps)
 {
 if (g_pSound == NULL)
 g_pSound = new QTQProcess(ps);
 return g_pSound;
 }*/
QTQProcess::QTQProcess(QProcess *ps)
{
	m_bIsOK = true;
	process = ps;
}

QTQProcess::~QTQProcess()
{
	//	delete g_pSound;
	//	g_pSound = NULL;
}
void QTQProcess::play(QString file)
{
	m_strFile = file;
	if (isRunning())
		terminate();
	run();
}
void QTQProcess::stop()
{
	terminate();
}
bool QTQProcess::isFinished()
{
	return isRunning() == true ? false : true;
}
//设备是否可用
bool QTQProcess::isAvailable()
{
	return m_bIsOK;
}
void QTQProcess::run()
{
	while (1/*process->canReadLine()*/)
	{
		QString message(process->readLine());
		// message 即为读取的信息，我们可以根据需要取我们要的信息如：
		// 文件总时间为：ANS_LENGTH=23.00
		// 当前时间为：ANS_TIME_POSITION=23.00
		//qDebug() << message;
		if (message.length() > 0)
		{
//			cout << message.toStdString().c_str() << endl;
			if (message.contains("ANS_LENGTH"))
			{
				int index = message.indexOf("ANS_LENGTH");
				QString strLength = message.mid(index + sizeof("ANS_LENGTH"),
						message.length() - index - 1);
				int iFileLength
						= strLength.mid(0, strLength.indexOf('.')).toInt();
				emit fileLength(iFileLength);
				break;
				//g_pPlayer->setMp3Length(g_iFileLength);
			}
		}
	}
}
