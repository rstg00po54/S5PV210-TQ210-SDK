/*
 * uTQSound.h
 *
 *  Created on: 2011-6-8
 *      Author: lkp
 */

#ifndef UTQSOUND_H_
#define UTQSOUND_H_

#include <QThread>
#include <QProcess>
class QTQProcess:public QThread
{
Q_OBJECT
public:
//	static QTQProcess *getInstance(QProcess);
	QTQProcess(QProcess *);
	virtual ~QTQProcess();
	void setFileName(QString);
	bool isFinished();
	bool isAvailable();
	void play(QString);
	void stop();
	void run();
	QProcess *process;
private:
	int m_iFd;
	QString m_strFile;
	bool m_bIsFinished;
	bool m_bIsOK;
signals:
	void fileLength(int);

};
//extern QTQProcess *g_pSound;
#endif /* UTQSOUND_H_ */
