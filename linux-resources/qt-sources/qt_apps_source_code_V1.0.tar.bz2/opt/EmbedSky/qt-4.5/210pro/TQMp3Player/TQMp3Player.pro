TEMPLATE = app
TARGET = tqmp3player
QT += core \
    gui \
    sql
HEADERS += src/ThreadProc/uTQProcess.h \
    tqmp3player.h
SOURCES += src/ThreadProc/uTQProcess.cpp \
    main.cpp \
    tqmp3player.cpp
FORMS += 
RESOURCES += 
