#include "tqmp3player.h"

#include <QtGui>
#include <QApplication>
#include <QSound>
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
	QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
	g_pPlayer = new TQMp3Player;
	g_pPlayer->show();
	//QSound::play("1.mp3");*/
	//	QSound bells("1.mp3");
	//	bells.play();
	/*g_pSound = QTQSound::getInstance();
	 if (g_pSound->isAvailable())
	 g_pSound->play("/usr/share/sounds/pop.wav");//opt/EmbedSky/workspace/TQMp3Player/1.mp3*/
	return a.exec();
}
