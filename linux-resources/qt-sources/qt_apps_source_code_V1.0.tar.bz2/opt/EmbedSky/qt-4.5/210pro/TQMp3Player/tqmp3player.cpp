#include "tqmp3player.h"
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<errno.h>
#include<fcntl.h>
#include<string.h>
#include <QToolBar>
#include <QHBoxLayout>
#include <QLabel>
#include <QFileDialog>
#include <iostream>
#include <QMessageBox>
using namespace std;
//#define FIFO "/tmp/fifo"
//int g_iFileLength;//文件长度
//int m_iFd;//
//int pipedes[2];
TQMp3Player *g_pPlayer;
TQMp3Player::TQMp3Player(QWidget *parent) :
	QWidget(parent)
{
	m_bPause = false;
	this->setGeometry(0, 0, 480, 272);
	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

//	setAttribute(Qt::WA_DeleteOnClose);
	QLabel *logo = new QLabel(trUtf8("天嵌科技mp3播放器(www.EmbedSky.net)"));
	logo->setAlignment(Qt::AlignCenter);

	m_iRowCount = 0;
	m_iLastValue = 0;
	m_pMp3Table = new QTableWidget;
	m_pMp3Table->setAutoFillBackground(true);
	//	m_pMp3Table->setEnabled(false);
	m_pMp3Table->setRowCount(1);
	m_pMp3Table->setColumnCount(2);
	m_pMp3Table->setColumnWidth(0, 430);
	/*m_pMp3Table->setColumnWidth(1, 105);
	 m_pMp3Table->setColumnWidth(2, 110);
	 m_pMp3Table->setColumnWidth(3, 110);*/
	m_pMp3Table->setColumnWidth(1, 0);

	QStringList header;
	header.append(trUtf8("音乐列表"));
	/*header.append(trUtf8("音乐家"));
	 header.append(trUtf8("唱片"));
	 header.append(trUtf8("发行日期"));*/
	header.append(trUtf8("文件路径"));

	m_pMp3Table->setHorizontalHeaderLabels(header);

	setActions();
	QToolBar *bar = new QToolBar;
	bar->setIconSize(QSize(50, 20));
	//	bar->setStyleSheet("background-color: rgb(0, 170, 0);");
	bar->addAction(m_pPlayAction);
	bar->addAction(m_pPauseAction);
	bar->addAction(m_pStopAction);
	bar->addAction(m_pbDirAction);
	bar->addAction(m_pbQuitAction);

	m_pPlayAction->setIcon(QIcon("/opt/PDA/app/images/mediaplay.png"));
	m_pPauseAction->setIcon(QIcon("/opt/PDA/app/images/mediapause.png"));
	m_pStopAction->setIcon(QIcon("/opt/PDA/app/images/mediastop.png"));
	m_pbDirAction->setIcon(QIcon("/opt/PDA/app/images/dir.png"));
	m_pbQuitAction->setIcon(QIcon("/opt/PDA/app/images/quit.png"));

	m_pSlider = new QSlider;
	m_pSlider->setMaximumWidth(100);
	m_pSlider->setOrientation(Qt::Horizontal);
	m_pSlider->setMinimum(1);
	m_pSlider->setMaximum(100);
	m_pSlider->setSingleStep(1);
	m_pSlider->setValue(100);

	m_pProgessSlider = new QSlider;
	//	m_pProgessSlider->setMaximumWidth(100);
	m_pProgessSlider->setOrientation(Qt::Horizontal);
	m_pProgessSlider->setMinimum(0);
	//	m_pProgessSlider->setMaximum(100);

	palette.setBrush(QPalette::Light, Qt::darkGray);

	m_pLcd = new QLCDNumber;
	m_pLcd->setPalette(palette);
	m_pLcd->display("00:00");

	QLabel *volumeLabel = new QLabel;
	volumeLabel->setPixmap(QPixmap("/opt/PDA/app/images/volume.png"));

	QHBoxLayout *hLayout = new QHBoxLayout;
	hLayout->addWidget(bar);
	hLayout->addStretch();
	hLayout->addWidget(m_pSlider);
	hLayout->addWidget(volumeLabel);

	QHBoxLayout *progessLayout = new QHBoxLayout;
	progessLayout->addWidget(m_pProgessSlider);
	progessLayout->addWidget(m_pLcd);

	QVBoxLayout *vLayout = new QVBoxLayout;

	vLayout->addWidget(logo);
	vLayout->addWidget(m_pMp3Table);
	vLayout->addLayout(progessLayout);
	vLayout->addLayout(hLayout);
	setLayout(vLayout);

	mplayerProcess = new QProcess(this);
	connect(mplayerProcess, SIGNAL(started()), this, SLOT(start()));
	connect(mplayerProcess, SIGNAL(error(QProcess::ProcessError)), this,
			SLOT(error(QProcess::ProcessError)));
	connect(mplayerProcess, SIGNAL(finished(int, QProcess::ExitStatus)), this,
			SLOT(finished(int, QProcess::ExitStatus)));
	connect(mplayerProcess, SIGNAL(readyReadStandardOutput()), this,
			SLOT(readyReadStandardOutput()));

	m_pProcess = new QTQProcess(mplayerProcess);
	connect(m_pProcess, SIGNAL(fileLength(int)), this, SLOT(setMp3Length(int)));

	getMp3File("/root/Documents");
	/*	unlink(FIFO);//如果管道存在，先删除
	 if (mkfifo(FIFO, O_CREAT | O_EXCL) == -1)//创建有名管道
	 {
	 perror("mkfifo");
	 exit(1);
	 }
	 if ((m_iFd = open(FIFO, O_RDWR)) == -1)
	 {
	 perror("open");
	 }

	 if (pipe(pipedes) == -1)//创建无名管道用于从mplayer读取歌曲信息
	 {
	 perror("pipe");
	 exit(1);
	 }*/

	connect(&m_Timer, SIGNAL(timeout()), this, SLOT(setProgess()));

	connect(m_pSlider, SIGNAL(valueChanged(int)), this, SLOT(volumeChanged()));
	connect(m_pProgessSlider, SIGNAL(valueChanged(int)), this,
			SLOT(progressChanged(int)));
	//m_Timer->start(1000);

	/*	pthread_t thread;
	 int fd = m_iFd;
	 if (pthread_create(&thread, NULL, readPipe, (void *) &fd) == 0)
	 {
	 perror("create thread");
	 }*/
}

TQMp3Player::~TQMp3Player()
{
	//	::close(m_iFd);
	delete m_pMp3Table;
	delete m_pPlayAction;//播放
	delete m_pPauseAction;//暂停
	delete m_pStopAction;//停止
	delete m_pbDirAction;//添加文件
	delete m_pbQuitAction;//退出

	delete m_pSlider;//声音
	delete m_pProgessSlider;//声音
	delete m_pLcd;
}
void TQMp3Player::pbCloseClicked()
{
	if (m_pProcess->isRunning())
	{
		m_pProcess->terminate();
	}
	close();
}
void TQMp3Player::setActions()
{
	m_pPlayAction = new QAction(style()->standardIcon(QStyle::SP_MediaPlay),
			trUtf8("播放"), this);
	m_pPlayAction->setShortcut(tr("Crl+P"));
	//	m_pPlayAction->setDisabled(true);

	m_pPauseAction = new QAction(style()->standardIcon(QStyle::SP_MediaPause),
			trUtf8("暂停"), this);
	m_pPauseAction->setShortcut(tr("Ctrl+A"));
	m_pPauseAction->setDisabled(true);

	m_pStopAction = new QAction(style()->standardIcon(QStyle::SP_MediaStop),
			trUtf8("停止"), this);
	m_pStopAction->setShortcut(tr("Ctrl+S"));
	m_pStopAction->setDisabled(true);

	m_pbDirAction = new QAction(style()->standardIcon(QStyle::SP_DirIcon),
			trUtf8("选择目录"), this);
	m_pbDirAction->setShortcut(tr("Ctrl+O"));
	//	m_pbDirAction->setDisabled(true);

	m_pbQuitAction
			= new QAction(style()->standardIcon(QStyle::SP_DialogCloseButton),
					tr("退出"), this);
	m_pbQuitAction->setShortcut(tr("Ctrl+q"));
	//	m_pbQuitAction->setDisabled(true);

	connect(m_pPlayAction, SIGNAL(triggered()), this, SLOT(play()));
	connect(m_pPauseAction, SIGNAL(triggered()), this, SLOT(pause()));
	connect(m_pStopAction, SIGNAL(triggered()), this, SLOT(stop()));
	connect(m_pbDirAction, SIGNAL(triggered()), this, SLOT(selectFile()));
	connect(m_pbQuitAction, SIGNAL(triggered()), this, SLOT(pbCloseClicked()));
}
void TQMp3Player::setMp3Length(int length)
{
	m_pProgessSlider->setMaximum(length);
	/*m_Timer->start(1000);
	 m_pPlayAction->setEnabled(false);*/
}
//进度
void TQMp3Player::progressChanged(int value)
{
	if (value > m_iLastValue + 1 || value < m_iLastValue)
	{
		QString progress;
		progress = QString::number(value * 100 / m_pProgessSlider->maximum());
		m_iLastValue = m_pProgessSlider->value();
		sendCmd(("seek " + progress + " 100\n"));
	}
}
//音量
void TQMp3Player::volumeChanged()
{
	QString volume = QString::number(m_pSlider->value());
	sendCmd(("volume " + volume + " 1\n"));
}
void TQMp3Player::setProgess()
{
	m_pProgessSlider->setValue(m_pProgessSlider->value() + 1);
	int length = m_pProgessSlider->value();
	m_iLastValue = length;
	QString min = QString::number(length / 60);
	while (min.length() < 2)
		min = "0" + min;
	QString sec = QString::number(length - (length / 60) * 60);
	while (sec.length() < 2)
		sec = "0" + sec;
	m_pLcd->display(min + ":" + sec);

	//播放结束
	if (m_pProgessSlider->value() == m_pProgessSlider->maximum())
	{
		m_pPlayAction->setEnabled(true);
		m_pProgessSlider->setValue(0);
		m_pLcd->display("00:00");
	}
}
void TQMp3Player::play()
{
	if (m_bPause)
	{
		sendCmd("pause\n");
		m_Timer.start(1000);
		m_bPause = false;
		m_pPauseAction->setEnabled(true);
		m_pPlayAction->setEnabled(false);
		return;
	}
	m_pProgessSlider->setValue(0);
	m_pLcd->display("00:00");
	if (m_iRowCount > 0 && m_pMp3Table->currentRow() < m_iRowCount)
	{
		//		m_pMp3Table->cellWidget(m_pMp3Table->currentRow(), 4)->text();
		QString mp3 = m_pMp3Table->item(m_pMp3Table->currentRow(), 1)->text();

		if (mp3.length() > 0)
		{
			QFile f(mp3);
			if (f.exists())
			{
				QString common = "mplayer -slave -quiet -ac mad -slave -quiet "
						+ mp3;
				mplayerProcess->start(common);
				sendCmd("get_time_length\n");
				/*QTimer::singleShot(1000, this, SLOT(getMp3Length()));
				 int pid = 0;
				 if ((pid = fork()) == -1)
				 {
				 perror("fork");

				 exit(1);
				 }
				 else if (pid == 0)//在子进程中播放歌曲

				 {
				 ::close(pipedes[0]);
				 dup2(pipedes[1], 1);
				 char song[100] =
				 { "/donotcry.mp3" };
				 memcpy(song, mp3.toStdString().c_str(), mp3.length());
				 song[mp3.length()] = 0x00;
				 execlp("mplayer", "", "-ac", "mad", "-slave", "-quiet",
				 "-input", "file=/tmp/fifo", song, NULL);
				 }*/
			}
			else
			{
				QMessageBox dg;
				dg.setWindowTitle(trUtf8("信息"));
				dg.addButton(new QPushButton(trUtf8("确认")),
						QMessageBox::YesRole);
				dg.setText(trUtf8("文件不存在！"));
				dg.exec();
			}
		}
	}
}
void TQMp3Player::pause()
{
	m_pPauseAction->setEnabled(false);
	m_pPlayAction->setEnabled(true);
	sendCmd("pause\n");
	m_bPause = true;
	if (m_Timer.isActive())
	{
		m_Timer.stop();
	}
}
void TQMp3Player::stop()
{
	system("killall mplayer");
	mplayerProcess->terminate();
	m_bPause = false;
	m_pPauseAction->setEnabled(false);
	m_pPlayAction->setEnabled(true);
	m_Timer.stop();
	m_pProgessSlider->setValue(0);
	m_pLcd->display("00:00");
}

void TQMp3Player::start()
{
	//	cout << "mplayer started ..."<<endl;
	m_pProcess->start();
	m_Timer.start(1000);
	m_pStopAction->setEnabled(true);
	m_pPlayAction->setEnabled(false);
	m_pPauseAction->setEnabled(true);
}

void TQMp3Player::error(QProcess::ProcessError)
{
	//	cout << "player error.";
	stop();
}
void TQMp3Player::finished(int, QProcess::ExitStatus)
{
	//	cout << "mplayer finished.";
	m_pPlayAction->setEnabled(true);
	m_pStopAction->setEnabled(false);
	m_pPauseAction->setEnabled(false);
	m_Timer.stop();
	m_pProgessSlider->setValue(0);
	m_pLcd->display("00:00");
}

void TQMp3Player::readyReadStandardOutput()
{

}

void TQMp3Player::sendCmd(QString cmd)
{
	mplayerProcess->write(cmd.toLatin1());
	/*if ((write(m_iFd, cmd, strlen(cmd))) != strlen(cmd))
	 {
	 perror("write cmd");
	 }*/
}
/*void *readPipe(void *fd)
 {
 int iFd = 0;
 memcpy(&iFd, fd, sizeof(int));
 char data[100];
 int iLen = 0;
 memset(data, 0x00, sizeof(data));
 while (1)
 {
 if ((iLen = read(pipedes[0], data, sizeof(data))) > 0)
 {
 data[iLen] = 0x00;
 QString str = QString(data);
 if (str.contains("ANS_LENGTH"))
 {
 int index = str.indexOf("ANS_LENGTH");
 QString strLength = str.mid(index + sizeof("ANS_LENGTH"),
 str.length() - index - 1);
 g_iFileLength
 = strLength.mid(0, strLength.indexOf('.')).toInt();
 g_pPlayer->setMp3Length(g_iFileLength);
 }
 }
 }
 return NULL;
 }*/
void TQMp3Player::selectFile()
{
	QFileDialog *fd = new QFileDialog(this);
	fd->setGeometry(0, 0, 480, 272);
	fd->setWindowTitle(trUtf8("请选择文件夹"));
	fd->setDirectory("/");
	fd->setFileMode(QFileDialog::Directory);
	QString strFilePath = "";
	if (fd->exec() == QDialog::Accepted)
	{
		QString path = fd->selectedFiles()[0];
		getMp3File(path);
		//		cout << path.toStdString().c_str() << endl;
	}
	delete fd;
}
void TQMp3Player::getMp3File(QString path)
{
	QDir dir(path);
	QFileInfoList list = dir.entryInfoList(QDir::Files);
	QFileInfo info;
	foreach(info,list)
		{
			if (info.fileName().endsWith(".mp3", Qt::CaseInsensitive))
			{
				m_pMp3Table->setItem(
						m_iRowCount,
						0,
						new QTableWidgetItem(
								trUtf8(info.fileName().toStdString().c_str())));
				m_pMp3Table->setItem(m_iRowCount, 1,
						new QTableWidgetItem(info.filePath()));
				m_iRowCount++;
				m_pMp3Table->setRowCount(m_iRowCount + 1);
			}
		}
}
