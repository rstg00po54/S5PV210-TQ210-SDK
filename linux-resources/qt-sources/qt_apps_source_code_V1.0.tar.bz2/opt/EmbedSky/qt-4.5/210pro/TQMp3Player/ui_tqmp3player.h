/********************************************************************************
** Form generated from reading ui file 'tqmp3player.ui'
**
** Created: Wed Jun 8 09:16:58 2011
**      by: Qt User Interface Compiler version 4.5.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_TQMP3PLAYER_H
#define UI_TQMP3PLAYER_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TQMp3PlayerClass
{
public:

    void setupUi(QWidget *TQMp3PlayerClass)
    {
        if (TQMp3PlayerClass->objectName().isEmpty())
            TQMp3PlayerClass->setObjectName(QString::fromUtf8("TQMp3PlayerClass"));
        TQMp3PlayerClass->resize(400, 300);

        retranslateUi(TQMp3PlayerClass);

        QMetaObject::connectSlotsByName(TQMp3PlayerClass);
    } // setupUi

    void retranslateUi(QWidget *TQMp3PlayerClass)
    {
        TQMp3PlayerClass->setWindowTitle(QApplication::translate("TQMp3PlayerClass", "TQMp3Player", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(TQMp3PlayerClass);
    } // retranslateUi

};

namespace Ui {
    class TQMp3PlayerClass: public Ui_TQMp3PlayerClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TQMP3PLAYER_H
