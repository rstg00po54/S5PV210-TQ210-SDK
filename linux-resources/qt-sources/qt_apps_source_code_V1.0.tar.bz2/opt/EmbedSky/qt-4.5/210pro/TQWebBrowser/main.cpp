#include "webbrowser.h"

#include <QtGui>
#include <QApplication>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);

	WebBrowser * w;
	bool bShowKey = false;
	for (int i = 0; i < argc; i++)
	{
		if (strcmp(argv[i], "EmbedSky") == 0)
		{
			w = new WebBrowser(0, 1);
			bShowKey = true;
			break;
		}
	}
	if (!bShowKey)
		w = new WebBrowser(0, 0);
	w->showFullScreen();

	return a.exec();
}
