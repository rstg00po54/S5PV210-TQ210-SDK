#include "webbrowser.h"
#include <QHBoxLayout>
#include <QLabel>
#include <QVBoxLayout>
#include <QScrollArea>
#include <QFileDialog>
#include <QtGlobal>
#include <QApplication>
#include <QDesktopWidget>
#include<QTimer>
#include <QUrl>
//#include <iostream>
#include <QWebFrame>
#include <QWebView>
#include <QPushButton>
//using namespace std;

WebBrowser::WebBrowser(QWidget *parent, bool bKeyShow) :
	QWidget(parent)
{
	//	setAttribute(Qt::WA_DeleteOnClose);

	this->setWindowTitle(trUtf8("天嵌科技网页浏览器V1.0(www.EmbedSky.net)"));
	QRect screen_size = QApplication::desktop()->screenGeometry();

	QPixmap pixmap("/opt/PDA/app/images/background.jpg");
	QPalette palette;
	palette.setBrush(backgroundRole(), QBrush(pixmap));
	setPalette(palette);

//	QLabel *labelTitle = new QLabel(trUtf8("天嵌科技网页浏览程序"), this);
//	labelTitle->setAlignment(Qt::AlignCenter);

	QHBoxLayout *headLayout = new QHBoxLayout;
	QLabel *lb = new QLabel(trUtf8("网址："), this);
	m_pleUrl = new QLineEdit(this);
    m_pleUrl->setText("http://www.embedsky.com");

	m_pbKey = new QPushButton(this);
	m_pbKey->setFixedSize(55,26);
	m_pbKey->setIconSize(QSize(55,26));
	QPixmap pix("/opt/PDA/app/images/key.png", 0, Qt::AutoColor);
	pix = pix.scaled(55,26, Qt::IgnoreAspectRatio);//图片大小
	m_pbKey->setIcon(QIcon(pix));

	QPushButton *pbRefresh = new QPushButton(this);
	pbRefresh->setFixedSize(55,26);
	pbRefresh->setIconSize(QSize(55,26));
	pix.load("/opt/PDA/app/images/flush.png", 0, Qt::AutoColor);
	pix = pix.scaled(55,26, Qt::IgnoreAspectRatio);//图片大小
	pbRefresh->setIcon(QIcon(pix));

	m_pbHelp = new QPushButton();
	m_pbHelp->setFixedSize(55,26);
	m_pbHelp->setIconSize(QSize(55,26));
	pix.load("/opt/PDA/app/images/help.png", 0, Qt::AutoColor);
	pix = pix.scaled(55,26, Qt::IgnoreAspectRatio);//图片大小
	m_pbHelp->setIcon(QIcon(pix));
	connect(m_pbHelp, SIGNAL(clicked()), this, SLOT(pbHelpClicked()));

	QPushButton *pbExit = new QPushButton(this);
	pbExit->setFixedSize(55,26);
	pbExit->setIconSize(QSize(55,26));
	pix.load("/opt/PDA/app/images/exit.png", 0, Qt::AutoColor);
	pix = pix.scaled(55,26, Qt::IgnoreAspectRatio);//图片大小
	pbExit->setIcon(QIcon(pix));
	connect(pbExit, SIGNAL(clicked()), this, SLOT(close()));

	headLayout->addWidget(lb);
	headLayout->addWidget(m_pleUrl);
	headLayout->addWidget(m_pbKey);
	headLayout->addWidget(pbRefresh);
	headLayout->addWidget(m_pbHelp);
	headLayout->addWidget(pbExit);

	QWebView* Webview = new QWebView(this);
	m_pWebpage = new QWebPage(this);
	Webview -> setPage(m_pWebpage);
	QVBoxLayout *vLayout = new QVBoxLayout;
//	vLayout->addWidget(labelTitle);
	vLayout->addLayout(headLayout);
	vLayout->addWidget(Webview);
	setLayout(vLayout);
	connect(pbRefresh, SIGNAL(clicked()), this, SLOT(pbRefreshClicked()));
	connect(m_pleUrl, SIGNAL(returnPressed()), this, SLOT(leReturnPressed()));

	connect(m_pWebpage,SIGNAL(loadFinished(bool)),this,SLOT(showWeb(bool)));

	m_pbKey->setEnabled(0);
	if (bKeyShow)
	{
		m_pbKey->setEnabled(1);
		connect(m_pbKey, SIGNAL(clicked()), this, SLOT(pbKeyShowHide()));

#ifdef ARM
		im = new TQInputMethod;
		QWSServer::setCurrentInputMethod(im);
		((TQInputMethod *) im)->setVisible(false);
#endif
	}
}
WebBrowser::~WebBrowser()
{
	delete m_pleUrl;
	delete m_pWebpage;
	delete m_pbHelp;
}
void WebBrowser::show()
{
	QWidget::show();
	QTimer::singleShot(100, this, SLOT(init()));
}
void WebBrowser::init()
{
	m_pWebpage->mainFrame()->load(QUrl("http://www.baidu.com"));
	connect(m_pWebpage, SIGNAL(loadStarted()), this, SLOT(UarlChanged()));
}
void WebBrowser::pbRefreshClicked()
{
	QString str = m_pleUrl->text();
	if (!str.startsWith("http://"))
		str = "http://" + str;
	m_pWebpage->mainFrame()->load(QUrl(str));

}
void WebBrowser::leReturnPressed()
{
	QString str = m_pleUrl->text();
	if (str.length() > 0)
	{
		pbRefreshClicked();
	}
}
void WebBrowser::UarlChanged()
{
	m_pleUrl->setText(m_pWebpage->currentFrame()->url().toString(QUrl::None));
}
void WebBrowser::showWeb(bool bOK)
{
	if (bOK == 1)
	{
		QString str = m_pWebpage->currentFrame()->url().toString(QUrl::None);
		m_pleUrl->setText(str);
	}
}
void WebBrowser::pbKeyShowHide()
{
	((TQInputMethod *) im)->setVisible(true);
}
void WebBrowser::pbHelpClicked()
{
	QStringList list;
	list << "-appname=" + QApplication::applicationFilePath();
	process.start("/opt/PDA/bin/tqhelp", list);
}
