#ifndef WEBBROWSER_H
#define WEBBROWSER_H

#include <QtGui/QWidget>
#include <QLineEdit>
#include <QWebPage>
#include <qprocess.h>
#include<QPushButton>

#include "TQInputMethod.h"
#ifdef ARM
#include <QWSInputMethod>
#endif

class WebBrowser: public QWidget
{
	Q_OBJECT

public:
	WebBrowser(QWidget *parent = 0,bool bKeyShow=0);
	~WebBrowser();
	void show();

private:
	QLineEdit *m_pleUrl;
	QWebPage *m_pWebpage;
	QProcess process;
	QPushButton *m_pbHelp;
	QWSInputMethod * im;
	QPushButton *m_pbKey;

public slots:
	void pbRefreshClicked();
	void leReturnPressed();
	void init();
	void pbHelpClicked();
	void UarlChanged();
	void showWeb(bool);
	void pbKeyShowHide();

};

#endif // WEBBROWSER_H
